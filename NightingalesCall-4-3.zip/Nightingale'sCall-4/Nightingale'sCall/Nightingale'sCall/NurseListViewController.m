//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "NurseListViewController.h"

@interface NurseListViewController ()

@end

@implementation NurseListViewController {
    NSMutableArray * nurseList;
    AppDelegate * ad;
}

@synthesize nurseOnCallTableView;
@synthesize activity;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"nurse on call");
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    [self initVariables];
    
    [NSTimer scheduledTimerWithTimeInterval:0 target:self selector:@selector(event) userInfo:nil repeats:NO];
}

-(void)event {
    ad.fakeEvent = 1;
    [self loadData];
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(load) userInfo:nil repeats:NO];
    [activity startAnimating];
}

-(void)load {
    if (ad.loadFinished) {
        //NSLog(@"stop");
        [activity stopAnimating];
        [nurseOnCallTableView reloadData];
        ad.loadFinished=0;
    }
}

-(void)loadData {
    [nurseList removeAllObjects];
    NSLog(@"nurse on call data");
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:[NSNumber numberWithInt:ad.wardID] forKey:@"id"];
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/user_log.php", ad.host];
    [manager POST:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        //NSLog(@"Dictionary %@", [json valueForKey:@"data"]);
        for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
            NSMutableDictionary * response = [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
            
            NSMutableDictionary * temp = [[NSMutableDictionary alloc] init];
            [temp setObject:[response valueForKey:@"id"] forKey:@"id"];
            [temp setObject:[response valueForKey:@"name"] forKey:@"name"];
            [temp setObject:[response valueForKey:@"picture"] forKey:@"picture"];
            [temp setObject:[response valueForKey:@"login_time"] forKey:@"login_time"];
            [temp setObject:[response valueForKey:@"distance"] forKey:@"distance"];
            [nurseList addObject:[temp mutableCopy]];
        }
        NSLog(@"nurseList=%@",nurseList);
        ad.loadFinished=1;
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Connection Failed"
                              message:@"Please Check Your Server IP"
                              delegate:self
                              cancelButtonTitle:nil
                              otherButtonTitles:@"OK",nil];
        alert.tag = 2;
        [alert show];
    }];
}

-(void)initVariables {
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    nurseList = [[NSMutableArray alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [nurseList count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"NurseListDataCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    //cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self showData:cell indexPath:indexPath];
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * user = (UILabel *)[cell viewWithTag:1];
    UILabel * distance = (UILabel *)[cell viewWithTag:2];
    UIImageView * profilePic = (UIImageView *)[cell viewWithTag:3];
    
    user.text =[NSString stringWithFormat:@"%@",[[nurseList objectAtIndex:indexPath.row] objectForKey:@"name"]];
    
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/picture/user/%@", ad.host, [[nurseList objectAtIndex:indexPath.row] objectForKey:@"picture"]];
    UIImage * image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:url]]];
    profilePic.layer.cornerRadius = 20;
    profilePic.layer.masksToBounds = YES;
    profilePic.contentMode = UIViewContentModeScaleAspectFit;
    profilePic.image = image;
    
    distance.text =[NSString stringWithFormat:@"%@",[[nurseList objectAtIndex:indexPath.row] objectForKey:@"distance"]];
}

@end
