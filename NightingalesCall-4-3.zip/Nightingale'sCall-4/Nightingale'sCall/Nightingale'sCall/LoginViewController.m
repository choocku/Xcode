//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"
#import "WardListViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController {
    AppDelegate * ad;
    UITextField * activeField;
}

@synthesize loginButton;
@synthesize usnTextField;
@synthesize pwdTextField;
@synthesize imageView;
@synthesize bottomLabel;
@synthesize NameLabel;
@synthesize mHealthLabel;
@synthesize myScrollView;

// add Price of Book
-(void)setText:(UILabel *)uiLabel text:(NSString *)str fontSize:(CGFloat)fontSize frame:(CGRect)frame fontStyle:(NSString *)fontStyle{
    uiLabel.frame = frame;
    uiLabel.lineBreakMode = NSLineBreakByWordWrapping;
    NSString* uiLabelString = str;
    NSMutableParagraphStyle *uiLabelStyle  = [[NSMutableParagraphStyle alloc] init];
    uiLabelStyle.minimumLineHeight = fontSize;
    uiLabelStyle.maximumLineHeight = fontSize;
    NSDictionary *PriceAttributtes = @{NSParagraphStyleAttributeName : uiLabelStyle,};
    uiLabel.attributedText = [[NSAttributedString alloc] initWithString : uiLabelString
                                                                 attributes:PriceAttributtes];
    uiLabel.textAlignment=NSTextAlignmentCenter;
    [uiLabel setTextColor: [UIColor whiteColor]];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [UAPush shared].pushNotificationDelegate = self;
    // Do any additional setup after loading the view, typically from a nib.
    [myScrollView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"tabBarBackground3.png"]]];
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [self registerForKeyboardNotifications];
    //create alert view
//    if (!ad.connect) {
//        [self connectServerAlertView];
//    }
    
    // App image
    UIImage *image = [UIImage imageNamed:@"nightingaleCall.png"];
    imageView.image = image;
    usnTextField.text = @"peeranon";
    pwdTextField.text = @"12345678";
    [loginButton addTarget:self action:@selector(login:) forControlEvents:UIControlEventTouchUpInside];

    
    self.navigationController.navigationBarHidden=YES;
}

-(void)viewDidAppear:(BOOL)animated {
    self.navigationController.navigationBarHidden=YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)connectServerAlertView {
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Server IP"
                          message:@"Insert Your Server IP"
                          delegate:self
                          cancelButtonTitle:@"Cancel"
                          otherButtonTitles:@"OK",nil];
    alert.tag = 1;
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField* tf = [alert textFieldAtIndex:0];
    tf.keyboardType = UIKeyboardTypeNumberPad;
    tf.text = ad.host;
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1 && alertView.tag == 1) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        ad.host = textfield.text;
        NSLog(@"host=%@",ad.host);
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        //        NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
        NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/event.php", ad.host];
        [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
//            ad.connect = 1;
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
}



-(void)login:(id)sender {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:usnTextField.text forKey:@"username"];
    [parameters setObject:pwdTextField.text forKey:@"password"];
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/signin.php", ad.host];
    [manager POST:url parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        //NSLog(@"Dictionary %@", [json objectForKey:@"state"]);
        
        if ([[[json valueForKey:@"data"] valueForKey:@"state"] isEqualToString:@"success"]) {
            NSLog(@"login success");
            ad.login = 1;
            ad.userID = [[[json valueForKey:@"data"] valueForKey:@"id"] intValue];
            NSLog(@"userID=%d",ad.userID);
            WardListViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"WardListViewController"];
            [self.navigationController pushViewController:controller animated:YES];
        }
        else {
//            NSLog(@"login failed");
            UIAlertView *alert = [[UIAlertView alloc]
                                  initWithTitle:@"Login Failed"
                                  message:@"Invalid username or password"
                                  delegate:self
                                  cancelButtonTitle:nil
                                  otherButtonTitles:@"OK",nil];
            alert.tag = 1;
            [alert show];
        }

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Connection Failed"
                              message:@""
                              delegate:self
                              cancelButtonTitle:nil
                              otherButtonTitles:@"OK",nil];
        alert.tag = 1;
        [alert show];
    }];
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == pwdTextField) {
        [textField resignFirstResponder];
        [self login:nil];
    } else if (textField == usnTextField) {
        [pwdTextField becomeFirstResponder];
    }
    return YES;
}

// Call this method somewhere in your view controller setup code.
- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
}

// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    myScrollView.contentInset = contentInsets;
    myScrollView.scrollIndicatorInsets = contentInsets;
    
    // If active text field is hidden by keyboard, scroll it so it's visible
    // Your application might not need or want this behavior.
    CGRect aRect = self.view.frame;
    aRect.size.height -= kbSize.height;
    if (!CGRectContainsPoint(aRect, activeField.frame.origin) ) {
        CGPoint scrollPoint = CGPointMake(0.0, activeField.frame.origin.y-kbSize.height);
        CGSize scrollViewContentSize = CGSizeMake(([UIScreen mainScreen].applicationFrame.size.width), 460);
        [myScrollView setContentSize:scrollViewContentSize];
        [myScrollView setContentOffset:scrollPoint animated:YES];
    }
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification

{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    myScrollView.contentInset = contentInsets;
    myScrollView.scrollIndicatorInsets = contentInsets;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

@end