//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "MapViewController.h"
#import "AppDelegate.h"

@interface MapViewController ()

@end

@implementation MapViewController {
    AppDelegate * ad;
    int w;
    int h;
}

@synthesize wardMap;
@synthesize activity;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self initVariables];
    [self configureNavBarAndTabBar];
    [self setWardImage];
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapScreen:)];
    [self.view addGestureRecognizer:tapGestureRecognizer];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(event) userInfo:nil repeats:NO];
}

-(void)viewDidAppear:(BOOL)animated {
    for (UIView * view in self.view.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            [view removeFromSuperview];
        }
    }
    [self viewDidLoad];
}

-(void)event {
    ad.fakeEvent = 1;
    [ad listenEvent];
    
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(load) userInfo:nil repeats:NO];
    [activity startAnimating];
}

-(void)load {
    if (ad.loadFinished) {
        //NSLog(@"stop");
        [activity stopAnimating];
        [self createEventImage];
    }
}

-(void)press:(id)sender {
    NSLog(@"press room %@",((UIButton *)sender).titleLabel.text);
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:[ad.profile objectForKey:@"id"] forKey:@"id"];
    [parameters setObject:((UIButton *)sender).titleLabel.text forKey:@"room"];
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/user_log.php", ad.host];
    [manager POST:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        //NSLog(@"Dictionary %@", json);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Connection Failed"
                              message:@"Please Check Your Server IP"
                              delegate:self
                              cancelButtonTitle:nil
                              otherButtonTitles:@"OK",nil];
        alert.tag = 2;
        [alert show];
    }];
    
//    int x1 = [[[ad.data objectAtIndex:0] objectForKey:@"position_x"] intValue];
//    int y1 = [[[ad.data objectAtIndex:0] objectForKey:@"position_y"] intValue];
//    int x2 = [[[ad.data objectAtIndex:1] objectForKey:@"position_x"] intValue];
//    int y2 = [[[ad.data objectAtIndex:1] objectForKey:@"position_y"] intValue];
//    
//    UIImage *image = [UIImage imageNamed:@"fern.jpg"];
//    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
//    imageView.backgroundColor = [UIColor clearColor];
//    imageView.contentMode = UIViewContentModeScaleAspectFit;
//    imageView.frame = CGRectMake(x1+30, y1-15, w,  h);
//    imageView.layer.cornerRadius = w / 2;
//    imageView.layer.masksToBounds = YES;
//    [self.view addSubview: imageView];
}

-(void)tapScreen:(UITapGestureRecognizer *)tapGestureRecognizer {
    CGPoint touchLocation = [tapGestureRecognizer locationInView:self.view];
    NSLog(@"tapScreen %f, %f",touchLocation.x,touchLocation.y);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initVariables {
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    w = 40;
    h = 40;
}

-(void)configureNavBarAndTabBar {
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.topItem.title = ad.wardName;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    // config ward
    UITabBarItem * wardTabBar = [self.tabBarController.tabBar.items objectAtIndex:0];
    [wardTabBar setTitle:@"Ward"];
    UIImage * mapUnselectedImage = [UIImage imageNamed:@"map-unSelected.png"];
    UIImage *mapSelectedImage = [UIImage imageNamed:@"map-selected.png"];
    [wardTabBar setImage:[mapUnselectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [wardTabBar setSelectedImage:mapSelectedImage];
    // config waiting list
    UITabBarItem * waitingListTabBar = [self.tabBarController.tabBar.items objectAtIndex:1];
    [waitingListTabBar setTitle:@"Waiting List"];
    UIImage * w8UnselectedImage = [UIImage imageNamed:@"w8-unselected.png"];
    UIImage *w8SelectedImage = [UIImage imageNamed:@"w8-selected.png"];
    [waitingListTabBar setImage:[w8UnselectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [waitingListTabBar setSelectedImage:w8SelectedImage];
    // config nurse list
    UITabBarItem * nurseListTabBar = [self.tabBarController.tabBar.items objectAtIndex:2];
    [nurseListTabBar setTitle:@"Nurse On Call"];
    UIImage * nurseUnselectedImage = [UIImage imageNamed:@"nurse-unselected.png"];
    UIImage *nurseSelectedImage = [UIImage imageNamed:@"nurse-selected.png"];
    [nurseListTabBar setImage:[nurseUnselectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [nurseListTabBar setSelectedImage:nurseSelectedImage];
}

-(void)setWardImage {
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/picture/ward/ward.jpg", ad.host];
    UIImage * image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:url]]];
    CGSize imageSize = image.size;
    wardMap.contentMode = UIViewContentModeScaleAspectFit;
    int difference = imageSize.width - wardMap.bounds.size.width;
    // orientation
    if (difference > 100) {
        UIImage* flippedImage = [UIImage imageWithCGImage:image.CGImage
                                                    scale:image.scale
                                              orientation:UIImageOrientationRight];
        CGSize flippedImageSize = flippedImage.size;
        
        wardMap.frame = CGRectMake(0.0, 0.0, flippedImageSize.width,  flippedImageSize.height);
        wardMap.image = flippedImage;
        //NSLog(@"flip %f,%f",flippedImageSize.width, flippedImageSize.height);
    }
    else {
        wardMap.frame = CGRectMake(0.0, 0.0, imageSize.width,  imageSize.height);
        wardMap.image = image;
    }
}

-(void)createEventImage {
    if ([ad.data count] != 0) {
        for (int i=0; i<[ad.data count]; i++) {
            int x = [[[ad.data objectAtIndex:i] objectForKey:@"position_x"] intValue];
            int y = [[[ad.data objectAtIndex:i] objectForKey:@"position_y"] intValue];
            
            
            UIButton * dot = [[UIButton alloc] initWithFrame:CGRectMake(x,y,w,h)];
            dot.titleLabel.text = [[ad.data objectAtIndex:i] objectForKey:@"room"];
            [dot addTarget:self action:@selector(press:) forControlEvents:UIControlEventTouchUpInside];
            // select image
            if ([[[ad.data objectAtIndex:i] objectForKey:@"event"] isEqual:@"Emergency"]) {
                [dot setBackgroundImage:[UIImage imageNamed:@"emergencyCall2.png"] forState:UIControlStateNormal];
                
            }
            else {
                [dot setBackgroundImage:[UIImage imageNamed:@"generalCall2.png"] forState:UIControlStateNormal];
            }
            
            [self.view addSubview:dot];
            
            dot.alpha = 1.0f;
            [UIView animateWithDuration:0.6f
                                  delay:0.0f
                                options:UIViewAnimationOptionRepeat | UIViewAnimationOptionAllowUserInteraction
                             animations:^ {
                                 //[UIView setAnimationRepeatCount:10.0f/2.0f];
                                 dot.alpha = 0.1f;
                             } completion:^(BOOL finished) {
                                 dot.alpha = 1.0f;
                             }];
            
        }
    }
}

@end
