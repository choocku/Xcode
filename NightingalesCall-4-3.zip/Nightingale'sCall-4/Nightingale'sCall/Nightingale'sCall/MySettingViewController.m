//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "MySettingViewController.h"
#import "AppDelegate.h"

@interface MySettingViewController ()

@end

@implementation MySettingViewController {
    AppDelegate * ad;
    NSMutableArray * data;
}

@synthesize serverIPTextField;
@synthesize settingsTableView;
@synthesize usernameLabel;
@synthesize nameLabel;
@synthesize profileImgView;
@synthesize logOutCell;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"settings");
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    
    settingsTableView.backgroundColor = [UIColor whiteColor];
    
    serverIPTextField.delegate = self;
    
    [self initVariables];
    [self dataStaticCell];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initVariables {
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    data = [[NSMutableArray alloc] init];
    NSMutableDictionary * dict = [[NSMutableDictionary alloc] init];
    [dict setObject:ad.host forKey:@"serverIP"];
    [data addObject:[dict mutableCopy]];
    [dict removeAllObjects];
    [data addObject:[ad.profile mutableCopy]];
    NSLog(@"setting %@",data);
}

-(void)dataStaticCell {
    serverIPTextField.text = [[data objectAtIndex:0] objectForKey:@"serverIP"];
    
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/picture/user/%@", ad.host, [[data objectAtIndex:1] objectForKey:@"picture"]];
    UIImage * image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:url]]];
    profileImgView.layer.cornerRadius = 20;
    profileImgView.layer.masksToBounds = YES;
    profileImgView.contentMode = UIViewContentModeScaleAspectFit;
    profileImgView.image = image;
    
    usernameLabel.text = [[data objectAtIndex:1] objectForKey:@"username"];
    nameLabel.text = [[data objectAtIndex:1] objectForKey:@"name"];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *theCellClicked = [tableView cellForRowAtIndexPath:indexPath];
    if (theCellClicked == logOutCell) {
        //Do stuff
        NSLog(@"Log Out id %@",[[data objectAtIndex:1] objectForKey:@"id"]);
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
        [parameters setObject:[[data objectAtIndex:1] objectForKey:@"id"] forKey:@"id"];
        NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/signout.php", ad.host];
        [manager POST:url parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            [ad initVariables];
            LoginViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
            controller.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:controller animated:YES];
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
}

-(IBAction)serverIPTextField:(id)sender {
    ad.host = serverIPTextField.text;
    [[data objectAtIndex:0] setObject:serverIPTextField.text forKey:@"serverIP"];
    NSLog(@"data=%@",data);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    for (UIView * txt in self.view.subviews){
        if ([txt isKindOfClass:[UITextField class]] && [txt isFirstResponder]) {
            [txt resignFirstResponder];
        }
    }
}

@end