//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "WaitingListViewController.h"

@interface WaitingListViewController ()

@end

@implementation WaitingListViewController {
    NSMutableArray * call;
    NSMutableDictionary * data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self initVariables];
}

-(void)initVariables {
    call = [[NSMutableArray alloc] init];
    data = [[NSMutableDictionary alloc] init];
    
    [data setObject:@"Room2" forKey:@"room"];
    [data setObject:@"EmergencyCall" forKey:@"event"];
    [data setObject:@"05/07/15 15:00:56" forKey:@"datetime"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    
    [data setObject:@"Room3" forKey:@"room"];
    [data setObject:@"GeneralCall" forKey:@"event"];
    [data setObject:@"05/07/15 14:30:56" forKey:@"datetime"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    
    
    
    [data setObject:@"Room4" forKey:@"room"];
    [data setObject:@"GeneralCall" forKey:@"event"];
    [data setObject:@"05/07/15 14:40:56" forKey:@"datetime"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    
    [data setObject:@"Room1" forKey:@"room"];
    [data setObject:@"EmergencyCall" forKey:@"event"];
    [data setObject:@"05/07/15 14:50:56" forKey:@"datetime"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    
    [data setObject:@"Room5" forKey:@"room"];
    [data setObject:@"EmergencyCall" forKey:@"event"];
    [data setObject:@"05/07/15 14:00:56" forKey:@"datetime"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    
    [data setObject:@"Room6" forKey:@"room"];
    [data setObject:@"GeneralCall" forKey:@"event"];
    [data setObject:@"05/07/15 14:00:56" forKey:@"datetime"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    
    [data setObject:@"Room7" forKey:@"room"];
    [data setObject:@"GeneralCall" forKey:@"event"];
    [data setObject:@"05/07/15 16:00:56" forKey:@"datetime"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    
    // grouping
    for (int i=0; i<[call count]; i++) {
        NSString * e = [[call objectAtIndex:i] objectForKey:@"event"];
        for (int j=i+1; j<[call count]; j++) {
            NSString * e2 = [[call objectAtIndex:j] objectForKey:@"event"];
            if ([e isEqual:@"GeneralCall"] && [e2 isEqual:@"EmergencyCall"]) {
                [call exchangeObjectAtIndex:i withObjectAtIndex:j];
            }
        }
    }
    
    // ordering by time
    for (int i=0; i<[call count]; i++) {
        NSString * e = [[call objectAtIndex:i] objectForKey:@"event"];
        NSString *dateStr1 = [[call objectAtIndex:i] objectForKey:@"datetime"];
        for (int j=i+1; j<[call count]; j++) {
            NSString * e2 = [[call objectAtIndex:j] objectForKey:@"event"];
            NSString *dateStr2 = [[call objectAtIndex:j] objectForKey:@"datetime"];
            
            // Convert string to date object
            NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
            [dateFormat setDateFormat:@"MM/dd/yy HH:mm:ss"];
            NSDate *date1= [dateFormat dateFromString:dateStr1];
            NSDate *date2 = [dateFormat dateFromString:dateStr2];
            
            NSComparisonResult result = [date1 compare:date2];
            
            if ([e isEqual:e2] && result == NSOrderedAscending) {
                [call exchangeObjectAtIndex:i withObjectAtIndex:j];
            }
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [call count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"WaitingListDataCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    
    // set cell backgroundcolor
    if ([[[call objectAtIndex:indexPath.row] objectForKey:@"event"] isEqual:@"EmergencyCall"]) {
        cell.backgroundColor = [UIColor colorWithRed:0.906 green:0.298 blue:0.235 alpha:1]; // arizarin
    } else {
        cell.backgroundColor = [UIColor colorWithRed:0.18 green:0.8 blue:0.443 alpha:1];    // emerald
    }
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self showData:cell indexPath:indexPath];
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * room = (UILabel *)[cell viewWithTag:1];
    UILabel * event = (UILabel *)[cell viewWithTag:2];
    UILabel * time = (UILabel *)[cell viewWithTag:3];
    
    room.text =[NSString stringWithFormat:@"%@",[[call objectAtIndex:indexPath.row] objectForKey:@"room"]];
    event.text =[NSString stringWithFormat:@"%@",[[call objectAtIndex:indexPath.row] objectForKey:@"event"]];
    time.text =[NSString stringWithFormat:@"%@",[[call objectAtIndex:indexPath.row] objectForKey:@"datetime"]];
}

@end
