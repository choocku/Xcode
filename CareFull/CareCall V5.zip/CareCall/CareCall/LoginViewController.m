//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"
#import "WardListViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController {
    AppDelegate * ad;
}

@synthesize loginButton;
@synthesize usnTextField;
@synthesize pwdTextField;
@synthesize imageView;
@synthesize bottomLabel;
@synthesize nameImage;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"Background2.jpg"]]];
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    self.navigationController.navigationBarHidden=YES;
    [loginButton addTarget:self action:@selector(login:) forControlEvents:UIControlEventTouchUpInside];
    usnTextField.text = @"test";
    pwdTextField.text = @"test";
    
    // App image
    UIImage *image = [UIImage imageNamed:@"nightingaleCall.png"];
    CGSize imageSize = image.size;
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.frame = CGRectMake(0.0, 0.0, imageSize.width,  imageSize.height);
    imageView.image = image;
    
    // App image
    UIImage *nameImg = [UIImage imageNamed:@"name2.png"];
    CGSize nameImgSize = nameImg.size;
    nameImage.contentMode = UIViewContentModeScaleAspectFit;
    nameImage.frame = CGRectMake(0.0, 0.0, nameImgSize.width,  nameImgSize.height);
    nameImage.image = nameImg;
    
    // bottom label
    bottomLabel.text = @"Cpr.E @ KMUTNB 2015";
}

-(void)viewDidAppear:(BOOL)animated {
    self.navigationController.navigationBarHidden=YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)login:(id)sender {
    if ([usnTextField.text isEqual:@"test"] && [pwdTextField.text isEqual:@"test"]) {
        NSLog(@"login success");
        WardListViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"WardListViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else {
        NSLog(@"login failed");
    }
}
@end
