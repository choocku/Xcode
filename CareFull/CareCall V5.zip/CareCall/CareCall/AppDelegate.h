//
//  AppDelegate.h
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) NSMutableArray * data;
@property (nonatomic, retain) NSMutableArray * profile;
@property (strong, nonatomic) UITabBarController * tabBarViewController;
@property (strong, nonatomic) NSString * wardName;
@property (strong, nonatomic) NSString * host;
@property (nonatomic) int port;

@end

