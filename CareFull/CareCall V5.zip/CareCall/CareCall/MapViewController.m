//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "MapViewController.h"
#import "AppDelegate.h"

@interface MapViewController ()

@end

@implementation MapViewController {
    AppDelegate * ad;
}

@synthesize wardMap;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self initVariables];
    [self configureNavBarAndTabBar];
    [self setWardImage];
    
    if ([ad.data count] != 0) {
        for (int i=0; i<[ad.data count]; i++) {
            int x = [[[ad.data objectAtIndex:i] objectForKey:@"x"] intValue];
            int y = [[[ad.data objectAtIndex:i] objectForKey:@"y"] intValue];
            int w = 40;
            int h = 40;
            
            UIImageView *dot =[[UIImageView alloc] initWithFrame:CGRectMake(x,y,w,h)];
            // select image
            if ([[[ad.data objectAtIndex:i] objectForKey:@"event"] isEqual:@"EmergencyCall"]) {
                dot.image=[UIImage imageNamed:@"emergencyCall2.png"];
            }
            else {
                dot.image=[UIImage imageNamed:@"generalCall2.png"];
            }
            
            [self.view addSubview:dot];
            
            dot.alpha = 1.0f;
            [UIView animateWithDuration:0.6f
                                  delay:0.0f
                                options:UIViewAnimationOptionRepeat
                             animations:^ {
                                 //[UIView setAnimationRepeatCount:10.0f/2.0f];
                                 dot.alpha = 0.1f;
                             } completion:^(BOOL finished) {
                                 dot.alpha = 1.0f;
                             }];
        }
    }
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapScreen:)];
    [self.view addGestureRecognizer:tapGestureRecognizer];
}

-(void)tapScreen:(UITapGestureRecognizer *)tapGestureRecognizer {
    CGPoint touchLocation = [tapGestureRecognizer locationInView:self.view];
    NSLog(@"tapScreen %f, %f",touchLocation.x,touchLocation.y);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initVariables {
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

-(void)configureNavBarAndTabBar {
    self.navigationController.navigationBar.topItem.title = ad.wardName;
    // config ward
    UITabBarItem * wardTabBar = [self.tabBarController.tabBar.items objectAtIndex:0];
    [wardTabBar setTitle:@"Ward"];
    UIImage * mapUnselectedImage = [UIImage imageNamed:@"map-unSelected.png"];
    UIImage *mapSelectedImage = [UIImage imageNamed:@"map-selected.png"];
    [wardTabBar setImage:[mapUnselectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [wardTabBar setSelectedImage:mapSelectedImage];
    // config waiting list
    UITabBarItem * waitingListTabBar = [self.tabBarController.tabBar.items objectAtIndex:1];
    [waitingListTabBar setTitle:@"Waiting List"];
    UIImage * w8UnselectedImage = [UIImage imageNamed:@"w8-unselected.png"];
    UIImage *w8SelectedImage = [UIImage imageNamed:@"w8-selected.png"];
    [waitingListTabBar setImage:[w8UnselectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [waitingListTabBar setSelectedImage:w8SelectedImage];
    // config nurse list
    UITabBarItem * nurseListTabBar = [self.tabBarController.tabBar.items objectAtIndex:2];
    [nurseListTabBar setTitle:@"Nurse List"];
    UIImage * nurseUnselectedImage = [UIImage imageNamed:@"nurse-unselected.png"];
    UIImage *nurseSelectedImage = [UIImage imageNamed:@"nurse-selected.png"];
    [nurseListTabBar setImage:[nurseUnselectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [nurseListTabBar setSelectedImage:nurseSelectedImage];
}

-(void)setWardImage {
    UIImage *image = [UIImage imageNamed:@"Hospital_Layout2.png"];
    CGSize imageSize = image.size;
    wardMap.contentMode = UIViewContentModeScaleAspectFit;
    int difference = imageSize.width - wardMap.bounds.size.width;
    // orientation
    if (difference > 100) {
        UIImage* flippedImage = [UIImage imageWithCGImage:image.CGImage
                                                    scale:image.scale
                                              orientation:UIImageOrientationRight];
        CGSize flippedImageSize = flippedImage.size;
        
        wardMap.frame = CGRectMake(0.0, 0.0, flippedImageSize.width,  flippedImageSize.height);
        wardMap.image = flippedImage;
        //NSLog(@"flip %f,%f",flippedImageSize.width, flippedImageSize.height);
    }
    else {
        wardMap.frame = CGRectMake(0.0, 0.0, imageSize.width,  imageSize.height);
        wardMap.image = image;
    }
}

@end
