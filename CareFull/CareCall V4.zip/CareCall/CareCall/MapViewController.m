//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "MapViewController.h"
#import "AppDelegate.h"

@interface MapViewController ()

@end

@implementation MapViewController {
    NSMutableArray * array;
    NSMutableDictionary * dict;
    AppDelegate * ad;
}

@synthesize wardMap;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self initVariables];
    [self setWardImage];
    
    UIButton * btn = [[UIButton alloc] initWithFrame:CGRectMake(50, 150, 100, 100)];
    [btn setBackgroundColor:[UIColor redColor]];
    [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    UIButton * btn2 = [[UIButton alloc] initWithFrame:CGRectMake(200, 150, 100, 100)];
    [btn2 setBackgroundColor:[UIColor blackColor]];
    [btn2 addTarget:self action:@selector(del:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initVariables {
    array = [[NSMutableArray alloc] init];
    dict = [[NSMutableDictionary alloc] init];
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    //NSLog(@"ad.wardName=%@",ad.wardName);
    self.navigationController.navigationBar.topItem.title = ad.wardName;
    UITabBarItem * wardTabBar = [self.tabBarController.tabBar.items objectAtIndex:0];
    [wardTabBar setTitle:@"Ward"];
    UIImage * mapUnselectedImage = [UIImage imageNamed:@"map-unSelected.png"];
    UIImage *mapSelectedImage = [UIImage imageNamed:@"map-selected.png"];
    [wardTabBar setImage:[mapUnselectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [wardTabBar setSelectedImage:mapSelectedImage];
}

-(void)setWardImage {
    UIImage *image = [UIImage imageNamed:@"Hospital_Layout2.jpg"];
    CGSize imageSize = image.size;
    wardMap.contentMode = UIViewContentModeScaleAspectFit;
    
    // orientation
    if (imageSize.width > wardMap.bounds.size.width) {
        UIImage* flippedImage = [UIImage imageWithCGImage:image.CGImage
                                                    scale:image.scale
                                              orientation:UIImageOrientationRight];
        CGSize flippedImageSize = flippedImage.size;
        
        wardMap.frame = CGRectMake(0.0, 0.0, flippedImageSize.width,  flippedImageSize.height);
        wardMap.image = flippedImage;
        //NSLog(@"flip %f,%f",flippedImageSize.width, flippedImageSize.height);
    }
    else {
        wardMap.frame = CGRectMake(0.0, 0.0, imageSize.width,  imageSize.height);
        wardMap.image = image;
    }
}

-(void)click:(id)sender {
    //NSLog(@"but");
    [dict setObject:@"room1" forKey:@"room"];
    [dict setObject:@"EmergencyCall" forKey:@"event"];
    [dict setObject:@"150" forKey:@"x"];
    [dict setObject:@"200" forKey:@"y"];
    [array addObject:[dict mutableCopy]];
    if ([array count] != 0) {
        int x = [[[array objectAtIndex:0] objectForKey:@"x"] intValue];
        int y = [[[array objectAtIndex:0] objectForKey:@"y"] intValue];
        int w = 40;
        int h = 40;
        
        UIImageView *dot =[[UIImageView alloc] initWithFrame:CGRectMake(x,y,w,h)];
        // select image
        if ([[[array objectAtIndex:0] objectForKey:@"event"] isEqual:@"EmergencyCall"]) {
            dot.image=[UIImage imageNamed:@"emergencyCall.jpg"];
        }
        else {
            dot.image=[UIImage imageNamed:@"generalCall.jpg"];
        }
        
        [wardMap addSubview:dot];
        
        dot.alpha = 1.0f;
        [UIView animateWithDuration:0.6f
                              delay:0.0f
                            options:UIViewAnimationOptionRepeat
                         animations:^ {
                             //[UIView setAnimationRepeatCount:10.0f/2.0f];
                             dot.alpha = 0.1f;
                         } completion:^(BOOL finished) {
                             dot.alpha = 1.0f;
                         }];
    }
}

-(void)del:(id)sender {
    for (UIView * subViews in [wardMap subviews]) {
        [subViews removeFromSuperview];
    }
}

@end
