//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"
#import "RegisterViewController.h"
#import "WardListViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController {
    AppDelegate * ad;
}

@synthesize loginButton;
@synthesize registerButton;
@synthesize usnTextField;
@synthesize pwdTextField;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    self.navigationController.navigationBarHidden=YES;
    [loginButton addTarget:self action:@selector(login:) forControlEvents:UIControlEventTouchUpInside];
    [registerButton addTarget:self action:@selector(regis:) forControlEvents:UIControlEventTouchUpInside];
    usnTextField.text = @"test";
    pwdTextField.text = @"test";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)login:(id)sender {
    if ([usnTextField.text isEqual:@"test"] && [pwdTextField.text isEqual:@"test"]) {
        NSLog(@"login success");
        WardListViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"WardListViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else {
        NSLog(@"login failed");
    }
}

-(void)regis:(id)sender {
    RegisterViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"RegisterViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

@end
