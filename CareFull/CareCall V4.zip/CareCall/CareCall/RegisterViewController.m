//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "RegisterViewController.h"
#import "AppDelegate.h"
#import "LoginViewController.h"

@interface RegisterViewController ()

@end

@implementation RegisterViewController {
    AppDelegate * ad;
}

@synthesize usnTextField;
@synthesize pwdTextField;
@synthesize nameTextField;
@synthesize subnameTextField;
@synthesize eMailTextField;
@synthesize okButton;
@synthesize cancelButton;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [self.view setBackgroundColor:[UIColor greenColor]];
    self.navigationController.navigationBarHidden=NO;
    self.navigationController.navigationBar.topItem.title = @"Register";
    [okButton addTarget:self action:@selector(submit:) forControlEvents:UIControlEventTouchUpInside];
    [cancelButton addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)submit:(id)sender {
    NSLog(@"submit");
    NSString * username = usnTextField.text;
    NSString * password = pwdTextField.text;
    NSString * name = nameTextField.text;
    NSString * subname = subnameTextField.text;
    NSString * email = eMailTextField.text;
    NSLog(@"username=%@,password=%@,name=%@,subname=%@,email=%@",username,password,name,subname,email);
    self.navigationController.navigationBarHidden=YES;
    LoginViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

-(void)cancel:(id)sender {
    NSLog(@"cancel");
    self.navigationController.navigationBarHidden=YES;
    LoginViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
