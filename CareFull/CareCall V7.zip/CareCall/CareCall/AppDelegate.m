//
//  AppDelegate.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@synthesize data;
@synthesize profile;
@synthesize tabBarViewController;
@synthesize wardName;
@synthesize host;
@synthesize port;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    host = @"192.168.106.70";
    port = 1024;
    [self configureTabBarAndNavigationBar];
    data = [[NSMutableArray alloc] init];
    profile = [[NSMutableArray alloc] init];
    wardName = @"";
    NSMutableDictionary * dict = [[NSMutableDictionary alloc] init];
    
    [dict setObject:@"MED-401" forKey:@"room"];
    [dict setObject:@"EmergencyCall" forKey:@"event"];
    [dict setObject:@"05/07/15 14:30:56" forKey:@"datetime"];
    [dict setObject:@"282" forKey:@"x"];
    [dict setObject:@"114" forKey:@"y"];
    [data addObject:[dict mutableCopy]];
    [dict removeAllObjects];
    [dict setObject:@"MED-402" forKey:@"room"];
    [dict setObject:@"GeneralCall" forKey:@"event"];
    [dict setObject:@"05/07/15 14:40:56" forKey:@"datetime"];
    [dict setObject:@"282" forKey:@"x"];
    [dict setObject:@"210" forKey:@"y"];
    [data addObject:[dict mutableCopy]];
    [dict removeAllObjects];
    
    //[self loadData];
    return YES;
}

-(void)loadData {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:[NSNumber numberWithInt:1] forKey:@"cueID"];
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/signin.php", host];
    [manager POST:url parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        NSLog(@"Dictionary %@", json);
//        for (int i=0; i<[[json objectForKey:@"data"] count]; i++) {
//            NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
//            NSMutableArray * temp = [[NSMutableArray alloc] init];
//            
//            [temp addObject:[response valueForKey:@"scene_id"]];
//            [temp addObject:[response valueForKey:@"scene_number"]];
//            [temp addObject:[response valueForKey:@"scene_name"]];
//            [scene addObject:temp];
//        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

-(void)configureTabBarAndNavigationBar {
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"tabBarBackground.png"] forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    
    // Assign tab bar item with titles
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateSelected];
    // Change the tab bar background
    UIImage* tabBarBackground = [UIImage imageNamed:@"tabBarBackground.png"];
    [[UITabBar appearance] setBackgroundImage:tabBarBackground];
    [[UITabBar appearance] setTintColor:[UIColor whiteColor]];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
