//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "NurseListViewController.h"

@interface NurseListViewController ()

@end

@implementation NurseListViewController {
    NSMutableArray * nurseList;
    NSMutableDictionary * data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self initVariables];
}

-(void)initVariables {
    nurseList = [[NSMutableArray alloc] init];
    data = [[NSMutableDictionary alloc] init];
    [data setObject:@"Aof" forKey:@"user"];
    [data setObject:@"Ward - อายุรกรรม 1" forKey:@"wardRes"];
    [data setObject:@"60m" forKey:@"distance"];
    [nurseList addObject:[data mutableCopy]];
    [data removeAllObjects];
    [data setObject:@"Pui" forKey:@"user"];
    [data setObject:@"Ward - อายุรกรรม 2" forKey:@"wardRes"];
    [data setObject:@"40m" forKey:@"distance"];
    [nurseList addObject:[data mutableCopy]];
    [data removeAllObjects];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [nurseList count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"NurseListDataCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    //cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self showData:cell indexPath:indexPath];
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * user = (UILabel *)[cell viewWithTag:1];
    UILabel * wardRes = (UILabel *)[cell viewWithTag:2];
    UILabel * distance = (UILabel *)[cell viewWithTag:3];
    
    user.text =[NSString stringWithFormat:@"%@",[[nurseList objectAtIndex:indexPath.row] objectForKey:@"user"]];
    wardRes.text =[NSString stringWithFormat:@"%@",[[nurseList objectAtIndex:indexPath.row] objectForKey:@"wardRes"]];
    distance.text =[NSString stringWithFormat:@"%@",[[nurseList objectAtIndex:indexPath.row] objectForKey:@"distance"]];
}

@end
