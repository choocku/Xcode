//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "MapViewController.h"

@interface MapViewController ()

@end

@implementation MapViewController

@synthesize scrollView;
@synthesize wardMap;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIImage *image = [UIImage imageNamed:@"Hospital_Layout.jpg"];
    CGSize imageSize = image.size;
    wardMap.contentMode = UIViewContentModeScaleAspectFit;
    if (imageSize.width > wardMap.bounds.size.width) {
        UIImage* flippedImage = [UIImage imageWithCGImage:image.CGImage
                                                    scale:image.scale
                                              orientation:UIImageOrientationRight];
        CGSize flippedImageSize = flippedImage.size;
        
        wardMap.frame = CGRectMake(0.0, 0.0, flippedImageSize.width,  flippedImageSize.height);
        wardMap.image = flippedImage;
        scrollView.contentSize = self.view.frame.size;
        NSLog(@"flip %f,%f",flippedImageSize.width, flippedImageSize.height);
    }
    else {
        wardMap.frame = CGRectMake(0.0, 0.0, imageSize.width,  imageSize.height);
        wardMap.image = image;
        scrollView.contentSize = imageSize;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)click:(id)sender {
    NSLog(@"but");
}

@end
