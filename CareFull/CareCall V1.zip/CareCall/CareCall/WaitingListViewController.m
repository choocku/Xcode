//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "WaitingListViewController.h"

@interface WaitingListViewController ()

@end

@implementation WaitingListViewController {
    NSMutableArray * call;
    NSMutableDictionary * data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self initVariables];
}

-(void)initVariables {
    call = [[NSMutableArray alloc] init];
    data = [[NSMutableDictionary alloc] init];
    [data setObject:@"Room101" forKey:@"room"];
    [data setObject:@"GeneralCall" forKey:@"event"];
    [data setObject:@"16:10:50" forKey:@"time"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    [data setObject:@"Room102" forKey:@"room"];
    [data setObject:@"GeneralCall" forKey:@"event"];
    [data setObject:@"16:20:00" forKey:@"time"];
    [call addObject:[data mutableCopy]];
    [data removeAllObjects];
    [data setObject:@"Room103" forKey:@"room"];
    [data setObject:@"EmergencyCall" forKey:@"event"];
    [data setObject:@"16:21:00" forKey:@"time"];
    [call addObject:[data mutableCopy]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [call count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"WaitingListDataCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    
    // set cell backgroundcolor
    if ([[[call objectAtIndex:indexPath.row] objectForKey:@"event"] isEqual:@"GeneralCall"]) {
        cell.backgroundColor = [UIColor colorWithRed:0.18 green:0.8 blue:0.443 alpha:1];    // emerald
    } else {
        cell.backgroundColor = [UIColor colorWithRed:0.906 green:0.298 blue:0.235 alpha:1]; // arizarin
    }
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self showData:cell indexPath:indexPath];
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * room = (UILabel *)[cell viewWithTag:1];
    UILabel * event = (UILabel *)[cell viewWithTag:2];
    UILabel * time = (UILabel *)[cell viewWithTag:3];
    
    room.text =[NSString stringWithFormat:@"%@",[[call objectAtIndex:indexPath.row] objectForKey:@"room"]];
    event.text =[NSString stringWithFormat:@"%@",[[call objectAtIndex:indexPath.row] objectForKey:@"event"]];
    time.text =[NSString stringWithFormat:@"%@",[[call objectAtIndex:indexPath.row] objectForKey:@"time"]];
}

@end
