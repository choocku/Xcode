//
//  ViewController.h
//  TESTContrainer
//
//  Created by Chawatvish Worrapoj on 1/29/2558 BE.
//  Copyright (c) 2558 Chawatvish Worrapoj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContainerController.h"

@interface ViewController : UIViewController <UIAppearanceContainer>

- (IBAction)Page1:(id)sender;
- (IBAction)Page2:(id)sender;


@end

