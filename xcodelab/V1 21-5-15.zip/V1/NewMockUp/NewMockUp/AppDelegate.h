//
//  AppDelegate.h
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncUdpSocket.h"
#import "AFNetworking.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate> {
    long tag;
    AsyncUdpSocket *udpSocket;
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSString * page;
@property (strong, nonatomic) NSString * host;
//@property (nonatomic) float cueNumber;
@property (nonatomic) int port;
@property (nonatomic) int countPressAllPreset;
@property (nonatomic) int clearState;
@property (nonatomic) int currentSceneID;
@property (nonatomic) int currentSceneNumber;
@property (nonatomic) int currentCueID;
@property (nonatomic) int currentSequenceID;
@property (nonatomic) bool storeState;
@property (nonatomic) bool addSequence;
@property (nonatomic) long tagAllPreset;
@property (nonatomic, retain) NSMutableArray *selected;
@property (nonatomic, retain) NSMutableArray *arrayForControlBar;
@property (nonatomic, retain) NSArray *typeOfLight;
@property (nonatomic, retain) NSArray *numberChOfLight;

-(void)sendUDP:(NSString *)msg;
-(void)toString:(NSMutableArray *)theArray
       thatView:(NSString *)thatView
         action:(NSString *)action;
-(void)toStringDelete:(NSMutableArray *)theArray
             thatView:(NSString *)thatView
               action:(NSString *)action;
-(void)setData:(int)index
            ch:(int)ch
           obj:(NSString *)obj;
-(void)updatedAndSent:(int)ch
            parameter:(NSString *)parameter
                  val:(NSString *)val;

@end

