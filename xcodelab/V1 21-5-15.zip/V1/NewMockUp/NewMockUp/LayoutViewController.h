//
//  ViewController.h
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "ControlBar.h"

@interface LayoutViewController : ControlBar

@property (weak, nonatomic) IBOutlet UIView *headerView;
@property (weak, nonatomic) IBOutlet UIView *dataView;

@property (weak, nonatomic) IBOutlet UILabel *headerLabel;

@end

