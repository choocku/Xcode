//
//  AppDelegate.h
//  scrollBar
//
//  Created by Kittisak Chiewchoengchon on 10/23/14.
//  Copyright (c) 2014 extalion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

