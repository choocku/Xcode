//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "ChannelOverviewViewController.h"

@interface ChannelOverviewViewController ()

@end

@implementation ChannelOverviewViewController {
    AppDelegate * channelOverviewDelagate;
    NSMutableArray * channelOverviewArray;
    int currentItem;
}

@synthesize headerLabel;
@synthesize headerView;
@synthesize contentView;
@synthesize myCollectionView;
@synthesize slider;
@synthesize valueTextField;

- (void)viewDidLoad {
    [super viewDidLoad];
    [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    // Do any additional setup after loading the view, typically from a nib.
    [self initVariables];
    [self configureView];
    [self loadData];
    //[self.view addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self.view action:@selector(endEditing:)]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated {
    [myCollectionView reloadData];
}

-(void)configureView {
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    contentView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    headerLabel.text = @"Channel Overview";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    myCollectionView.backgroundColor = [UIColor clearColor];
    
    CGAffineTransform trans = CGAffineTransformMakeRotation(-M_PI_2);
    slider.transform = trans;
    slider.minimumValue = 0;
    slider.maximumValue = 255;
    
    //[slider addTarget:self action:@selector(changeValue) forControlEvents:UIControlEventTouchUpInside];
    [slider configureFlatSliderWithTrackColor:[UIColor silverColor]
                                     progressColor:[UIColor peterRiverColor]
                                        thumbColor:[UIColor belizeHoleColor]];
    
}

-(void)initVariables {
    channelOverviewDelagate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    channelOverviewArray = [[NSMutableArray alloc] init];
}

-(void)loadData {
    NSString * urlString = [NSString stringWithFormat:@"http://%@/lighttouch_api/channel_overview.php",channelOverviewDelagate.host];
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSData *jsonData = [NSData dataWithContentsOfURL:url];
    
    if(jsonData != nil)
    {
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        if (error == nil){
            // split json to Dictionary
            for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
                NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
                NSMutableDictionary * temp = [[NSMutableDictionary alloc] init];
                [temp setObject:[response valueForKey:@"device_id"] forKey:@"device_id"];
                [temp setObject:[response valueForKey:@"channel"] forKey:@"channel"];
                [temp setObject:[response valueForKey:@"name"] forKey:@"name"];
                [temp setObject:[response valueForKey:@"parameter"] forKey:@"parameter"];
                [temp setObject:[response valueForKey:@"value"] forKey:@"value"];
                [channelOverviewArray addObject:[temp mutableCopy]];
            }
//            NSLog(@"ch overview = %@",channelOverviewArray);
            [myCollectionView reloadData];
        }
    }
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [channelOverviewArray count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"collectionViewCell";
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    [cell setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    
    [self showData:cell indexPath:indexPath];
    
    return cell;
}

-(void)showData:(UICollectionViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * ch = (UILabel *)[cell viewWithTag:1];
    UILabel * value = (UILabel *)[cell viewWithTag:2];
    UILabel * parameter = (UILabel *)[cell viewWithTag:3];
    UILabel * name = (UILabel *)[cell viewWithTag:4];
    
    parameter.numberOfLines = 1;
    parameter.minimumScaleFactor  = 8./parameter.font.pointSize;
    parameter.adjustsFontSizeToFitWidth = YES;
    name.numberOfLines = 1;
    name.minimumScaleFactor  = 8./name.font.pointSize;
    name.adjustsFontSizeToFitWidth = YES;
    
    ch.text = [NSString stringWithFormat:@"%@",[[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"channel"]];
    ch.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    value.text = [NSString stringWithFormat:@"%@",[[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"value"]];
    parameter.text = [NSString stringWithFormat:@"%@",[[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"parameter"]];
    parameter.textColor = [UIColor colorWithRed:1 green:0.29 blue:0.165 alpha:1];
    name.text = [NSString stringWithFormat:@"%@",[[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"name"]];
//    if (![[[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"parameter"] isEqual:[NSNull null]] ||
//        ![[[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"name"] isEqual:[NSNull null]]) {
//        
//    }
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell * cell = [collectionView cellForItemAtIndexPath:indexPath];
    currentItem = (int)indexPath.row;
    NSLog(@"%@",[[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"value"]);
    valueTextField.text = [[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"value"];
    slider.value = [[[channelOverviewArray objectAtIndex:indexPath.row] objectForKey:@"value"] intValue];
    
    UIView *bgColorView = [[UIView alloc] init];
    bgColorView.backgroundColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    [cell setSelectedBackgroundView:bgColorView];
}

-(IBAction)changeTextEnded:(id)sender {
    slider.value = [valueTextField.text intValue];
    [self changeValue];
}

-(IBAction)changeSliderValue:(id)sender {
    valueTextField.text = [NSString stringWithFormat:@"%d",(int)slider.value];
    [self changeValue];
}

-(void)changeValue {
    [[channelOverviewArray objectAtIndex:currentItem] removeObjectForKey:@"value"];
    [[channelOverviewArray objectAtIndex:currentItem] setObject:valueTextField.text forKey:@"value"];
    [myCollectionView reloadItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:currentItem inSection:0]]];    // reload single cell
    
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    [test setObject:[[channelOverviewArray objectAtIndex:currentItem] objectForKey:@"device_id"]
             forKey:@"device_id"];
    [test setObject:[[channelOverviewArray objectAtIndex:currentItem] objectForKey:@"parameter"]
             forKey:@"parameter"];
    [test setObject:[[channelOverviewArray objectAtIndex:currentItem] objectForKey:@"value"]
             forKey:@"value"];
    
    [channelOverviewDelagate toString:[test mutableCopy] thatView:@"controlbar" action:@"control/"];
}

@end