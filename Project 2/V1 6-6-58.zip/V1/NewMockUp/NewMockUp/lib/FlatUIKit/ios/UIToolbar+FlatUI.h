//
// Created by Jonathon Hibbard on 6/13/13.
// Copyright (c) 2013 Integrated Events. All rights reserved.
//
// To change the template use AppCode | Preferences | File Templates.
//

#import <UIKit/UIKit.h>

@interface UIToolbar (FlatUI)

- (void)configureFlatToolbarWithColor:(UIColor *)color UI_APPEARANCE_SELECTOR;

@end