//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "ContainerController.h"

@interface ContainerController ()

@end

@implementation ContainerController {
    AppDelegate * ad;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSLog(@"%@",ad.page);
    
    self.view.layer.shadowColor = [UIColor purpleColor].CGColor;
    self.view.layer.shadowOffset = CGSizeMake(5, 5);
    self.view.layer.shadowOpacity = 1;
    self.view.layer.shadowRadius = 1.0;
    
    NSArray *views = [self.view subviews];
    
    if ([views count] != 0) {
        for(UIView *newview in views) {
            [newview removeFromSuperview];
            NSLog(@"%@",newview);
        }
    }
    
    UIStoryboard * storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    if ( [ad.page isEqualToString:@"PatchingViewController"]) {
        PatchingViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"PatchingViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"LayoutViewController"]) {
        LayoutViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"LayoutViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"DeviceViewController"]) {
        DeviceViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"DeviceViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"AllPresetViewController"]) {
        AllPresetViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"AllPresetViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"CueListViewController"]) {
        CueListViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"CueListViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"ChannelOverviewViewController"]) {
        ChannelOverviewViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"ChannelOverviewViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
