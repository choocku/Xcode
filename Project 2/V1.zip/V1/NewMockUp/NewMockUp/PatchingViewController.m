//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "PatchingViewController.h"

@interface PatchingViewController ()

@end

@implementation PatchingViewController{
    AppDelegate * patchingDelegate;
    NSMutableArray * device;
    NSMutableArray * library;
    NSString * name;
    NSString * type;
    float x_drawDevices;
    float y_drawDevices;
    int usedCH;
    int row;
    int startCH;
    
}

@synthesize headerView;
@synthesize dataView;
@synthesize headerLabel;
@synthesize idLabel;
@synthesize nameLabel;
@synthesize typeLabel;
@synthesize patchingTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
    [self initVariables];
    [self loadLibrary];
    bool loadComplete = false;
    if (!loadComplete) {
        [self loadData];
        loadComplete = true;
    }
    patchingTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    patchingTableView.separatorColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    //[self.view addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self.view action:@selector(endEditing:)]];
}

//-(void)viewDidAppear:(BOOL)animated {
//    [patchingTableView reloadData];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)loadData {
    [device removeAllObjects];
    NSString * urlString = [NSString stringWithFormat:@"http://%@/lighttouch_api/patching.php",patchingDelegate.host];
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSData *jsonData = [NSData dataWithContentsOfURL:url];
    
    if(jsonData != nil)
    {
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        if (error == nil){
            // split json to Dictionary
            for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
                NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
                NSMutableArray * temp = [[NSMutableArray alloc] init];
                [temp addObject:[response valueForKey:@"device_id"]];
                [temp addObject:[response valueForKey:@"name"]];
                [temp addObject:[response valueForKey:@"type"]];
                [device addObject:[temp mutableCopy]];    // add temp array to device array
            }
            usedCH = [[json valueForKey:@"quantity"] intValue];
            NSLog(@"patchingFromAPI - %@,%d",device,usedCH);
        }
    }
}

-(void)loadLibrary {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSString * url = [NSString stringWithFormat:@"http://%@/lighttouch_api/library.php", patchingDelegate.host];
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        //NSLog(@"Dictionary %@", [json objectForKey:@"totalCue"]);
        for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
            NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
            NSMutableDictionary * temp = [[NSMutableDictionary alloc] init];
            
            [temp setObject:[response valueForKey:@"library_id"] forKey:@"library_id"];
            [temp setObject:[response valueForKey:@"library_name"] forKey:@"library_name"];
            [temp setObject:[response valueForKey:@"vendor"] forKey:@"vendor"];
            [temp setObject:[response valueForKey:@"quantity"] forKey:@"quantity"];
            [library addObject:[temp mutableCopy]];
        }
        NSLog(@"library=%@",library);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

-(void)configureView {
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    dataView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    patchingTableView.backgroundColor = [UIColor clearColor];
    
    headerLabel.text = @"PATCHING";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    idLabel.text = @"DEVICE ID";
    
    nameLabel.text = @"NAME";
    
    typeLabel.text = @"TYPE";
    
    // set table style
    patchingTableView.backgroundColor = [UIColor clearColor];
    patchingTableView.separatorColor = [UIColor clearColor];
    patchingTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

-(void)initVariables {
    patchingDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    device = [[NSMutableArray alloc] init];    // store devices
    library = [[NSMutableArray alloc] init];    // store devicelibrary
    
    // parameter of drawDevices
    x_drawDevices = 400.0f;
    y_drawDevices = 50.0f;

    row=0;
    name=@"";
    type=@"";
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return device.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"MyCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self showData:cell indexPath:indexPath];
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * label1 = (UILabel *)[cell viewWithTag:1];
    UILabel * label2 = (UILabel *)[cell viewWithTag:2];
    UILabel * label3 = (UILabel *)[cell viewWithTag:3];
    
    label1.text =[NSString stringWithFormat:@"%@",[[device objectAtIndex:indexPath.row] objectAtIndex:0]];
    label1.textColor = [UIColor whiteColor];
    label2.text =[NSString stringWithFormat:@"%@",[[device objectAtIndex:indexPath.row] objectAtIndex:1]];
    label2.textColor = [UIColor whiteColor];
    label3.text =[NSString stringWithFormat:@"%@",[[device objectAtIndex:indexPath.row] objectAtIndex:2]];
    label3.textColor = [UIColor whiteColor];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    UIView *bgColorView = [[UIView alloc] init];
    bgColorView.backgroundColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    [cell setSelectedBackgroundView:bgColorView];
}

- (IBAction)addButton:(id)sender {
    NSLog(@"add");
    
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Type"
                          message:@"Select device type"
                          delegate:self
                          cancelButtonTitle:nil
                          otherButtonTitles:nil];
    alert.tag = 1;
    for (int i=0; i<[library count]; i++) {
        [alert addButtonWithTitle:[[library objectAtIndex:i] objectForKey:@"library_name"]];
    }
    alert.cancelButtonIndex = [alert addButtonWithTitle:@"Cancel"];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSMutableArray * data;
    NSMutableArray * temp;
    NSMutableArray * newDevice = [[NSMutableArray alloc] init];
    if (alertView.tag == 1 && ![[alertView buttonTitleAtIndex:buttonIndex] isEqual:@"Cancel"]) {
        type = [alertView buttonTitleAtIndex:buttonIndex];
        NSLog(@"type=%@",type);
        NSString * message = [NSString stringWithFormat:@"Insert beginning channel \nLast Channel :%d",usedCH];
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Channel"
                              message:message
                              delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"OK",nil];
        alert.tag = 2;
        alert.alertViewStyle = UIAlertViewStylePlainTextInput;
        UITextField* tf = [alert textFieldAtIndex:0];
        tf.keyboardType = UIKeyboardTypeNumberPad;
        tf.text = [NSString stringWithFormat:@"%d",usedCH+1];
        [alert show];
    }
    else if (buttonIndex == 1 && alertView.tag == 2) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        startCH = [textfield.text intValue];      // set beginning channel
        
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Amount"
                              message:@"Insert amount of device"
                              delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"OK",nil];
        alert.tag = 3;
        alert.alertViewStyle = UIAlertViewStylePlainTextInput;
        UITextField* tf = [alert textFieldAtIndex:0];
        tf.keyboardType = UIKeyboardTypeNumberPad;
        [alert show];
    }
    else if (buttonIndex == 1 && alertView.tag == 3) {
         UITextField *textfield = [alertView textFieldAtIndex:0];
         row = [textfield.text intValue];    // row is amount of device
        
         UIAlertView *alert = [[UIAlertView alloc]
         initWithTitle:@"Name"
         message:@"Insert device name"
         delegate:self
         cancelButtonTitle:@"Cancel"
         otherButtonTitles:@"OK",nil];
         alert.tag = 4;
         alert.alertViewStyle = UIAlertViewStylePlainTextInput;
         [alert show];
    }
    else if (buttonIndex == 1 && alertView.tag == 4) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        name = textfield.text;      // name of device
        
        // add data to Device Array(in Dataclass)
        for (int i=0; i<row; i++) {
            data = [[NSMutableArray alloc] init];
            temp = [[NSMutableArray alloc] init];
            //[data addObject:[NSNumber numberWithInt:device.count+1]]; // set device id
            [data addObject:[name stringByAppendingString:[NSString stringWithFormat:@"%d",i+1]]]; // set name
            [data addObject:type];  // set type
            
//            [device addObject:[data mutableCopy]];
            
//            [temp addObject:[data objectAtIndex:0]];
//            NSString * deviceType = [data objectAtIndex:2];
            
            // store x, y position
            [temp addObject:[NSString stringWithFormat:@"%f",x_drawDevices-250]];
            [temp addObject:[NSString stringWithFormat:@"%f",y_drawDevices+(i*(row+10))]];
            
//            if ([deviceType isEqual:[patchingDelegate.typeOfLight objectAtIndex:0]]) {
//                [temp addObject:[NSString stringWithFormat:@"%f",x_drawDevices-250]];
//                [temp addObject:[NSString stringWithFormat:@"%f",y_drawDevices+(i*(row+10))]];
//            }
//            else if ([deviceType isEqual:[patchingDelegate.typeOfLight objectAtIndex:1]]) {
//                [temp addObject:[NSString stringWithFormat:@"%f",x_drawDevices]];
//                [temp addObject:[NSString stringWithFormat:@"%f",y_drawDevices+(i*(row+10))]];
//            }
//            else if ([deviceType isEqual:[patchingDelegate.typeOfLight objectAtIndex:2]]) {
//                [temp addObject:[NSString stringWithFormat:@"%f",x_drawDevices+250]];
//                [temp addObject:[NSString stringWithFormat:@"%f",y_drawDevices+(i*(row+10))]];
//            }
            
            [data addObject:[temp objectAtIndex:0]];
            [data addObject:[temp objectAtIndex:1]];
            [newDevice addObject:[data mutableCopy]];
            [temp removeAllObjects];
        }
        // create JSON form
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        NSMutableDictionary * eachDevice = [[NSMutableDictionary alloc] init];
        NSMutableArray *patchDevice = [[NSMutableArray alloc] init];
        //NSMutableArray *theArrayTest = [[NSMutableArray alloc] init];
        [test setObject:type forKey:@"type"];
        [test setObject:[NSNumber numberWithInt:startCH] forKey:@"startCH"];
        for (int i=0; i<[newDevice count]; i++) {
            //[eachDevice setObject:[[newDevice objectAtIndex:i] objectAtIndex:0] forKey:@"device_id"];
            [eachDevice setObject:[[newDevice objectAtIndex:i] objectAtIndex:0] forKey:@"name"];
            [eachDevice setObject:[[newDevice objectAtIndex:i]
                                   objectAtIndex:[[newDevice objectAtIndex:i] count]-2]
                           forKey:@"xLayoutPosition"];
            [eachDevice setObject:[[newDevice objectAtIndex:i]
                                   objectAtIndex:[[newDevice objectAtIndex:i] count]-1]
                           forKey:@"yLayoutPosition"];
            [patchDevice addObject:[eachDevice mutableCopy]];
        }
        [test setObject:[patchDevice mutableCopy] forKey:@"device"];

        [patchingDelegate toString:[test mutableCopy] thatView:@"patching" action:@"add_device/"]; // send JSON form
        [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(addFinished) userInfo:nil repeats:NO];
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //remove the deleted object from your data source.
        //If your data source is an NSMutableArray, do this
        NSLog(@"delete=%@",[[device objectAtIndex:indexPath.row] objectAtIndex:0]);
        
        /* create JSON form */
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        
        [test setObject:[[device objectAtIndex:indexPath.row] objectAtIndex:0] forKey:@"device_id"];
        
        /* send JSON form */
        [patchingDelegate toStringDelete:[test mutableCopy] thatView:@"patching" action:@"delete_device/"];
        if (patchingDelegate.selected.count!=0)
            [patchingDelegate.selected removeObjectIdenticalTo:[NSNumber numberWithInt:(int)indexPath.row+1]];
        [device removeObjectAtIndex:indexPath.row];     // delete data from array
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(deleteFinished) userInfo:nil repeats:NO];
    }
}

-(void)addFinished {
    [self loadData];
    [patchingTableView reloadData]; // tell table to refresh now
//    NSLog(@"device=%@",device);
}

-(void)deleteFinished {
    [self loadData];
    [patchingTableView reloadData]; // tell table to refresh now
    NSLog(@"selectedNEW=%@",patchingDelegate.selected);
}

@end
