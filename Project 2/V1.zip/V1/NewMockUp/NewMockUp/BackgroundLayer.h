//
//  BackgroundLayer.h
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 2/6/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface BackgroundLayer : NSObject

+(CAGradientLayer*) greyGradient;
+(CAGradientLayer*) blueGradient;
+(CAGradientLayer*) testGradient;
+(CAGradientLayer*) greenGradient;

@end