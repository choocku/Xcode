//
//  ViewController.h
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FlatUIKit.h"
#import "ContainerController.h"
#import "AppDelegate.h"
#import "BackgroundLayer.h"

@interface ViewController : UIViewController

- (IBAction)patchingButton:(id)sender;
- (IBAction)layoutButton:(id)sender;
- (IBAction)deviceButton:(id)sender;
- (IBAction)allPresetButton:(id)sender;
- (IBAction)cueListButton:(id)sender;
- (IBAction)chOverviewButton:(id)sender;

@end

