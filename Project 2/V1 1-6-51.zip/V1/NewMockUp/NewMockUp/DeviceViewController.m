//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "DeviceViewController.h"

@interface DeviceViewController ()

@end

@implementation DeviceViewController {
    AppDelegate * deviceDelegate;
    
    // group device
    UIView *groupView;
    UIScrollView *myScroll;
    int x_groupView;
    int y_groupView;
    int width_groupView;
    int height_groupView;
    
    NSMutableArray * groupDevice;
    NSMutableArray * element;
    
    bool once;
}

@synthesize headerView;
@synthesize headerLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    [super initControlBar];
    // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
    [self initVariables];
    [self loadData];
    [self setGroupDeviceButton];
    /*
    NSArray *views = [myScroll subviews];
    
    if ([views count] != 0) {
        for(UIView *newview in views) {
            if ([newview isKindOfClass:[FUIButton class]]) {
                NSLog(@"s%@",newview);
                [newview removeFromSuperview];
            }
        }
        NSLog(@"%d",views.count);
    }
    */
//    if (!once) {
//        [self loadData];
//        once = true;
//    }
    
    if (groupDevice.count!=0) {
        NSLog(@"viewdidload refresh");
        for (int i=0; i<[groupDevice count]; i++) {
            int savedGroupDeviceTag = [[[groupDevice objectAtIndex:i] objectAtIndex:0] intValue];
            [self refresh:savedGroupDeviceTag index:i];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    for (UIView * txt in self.view.subviews){
        if ([txt isKindOfClass:[UITextField class]] && [txt isFirstResponder]) {
            [txt resignFirstResponder];
        }
    }
}

-(void)configureView {
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    headerLabel.text = @"DEVICE";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    //parameter for groupView
    x_groupView = 0;
    y_groupView = 56;
    width_groupView = 830;
    height_groupView = 611;
    
    // init groupView
    groupView = [[UIView alloc] initWithFrame:CGRectMake( x_groupView, y_groupView,width_groupView, height_groupView)];
    groupView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    groupView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    //groupView.layer.cornerRadius = cornerRadius;
    groupView.layer.masksToBounds = YES;
    [self.view addSubview:groupView];
    
    // init scroll view
    myScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, groupView.bounds.size.width, groupView.bounds.size.height)];
    myScroll.contentSize = CGSizeMake(groupView.bounds.size.width, 1000);   //scroll view size
    myScroll.backgroundColor = [UIColor clearColor];
    myScroll.showsVerticalScrollIndicator = NO;    // to hide scroll indicators!
    myScroll.showsHorizontalScrollIndicator = YES; //by default, it shows!
    myScroll.scrollEnabled = YES;                 //say "NO" to disable scroll
    [groupView addSubview:myScroll];               //adding to parent view!
}

-(void)initVariables {
    deviceDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    element = [[NSMutableArray alloc] init];
    groupDevice = [[NSMutableArray alloc] init];
    
    once = false;
}

-(void)loadData {
    NSString * urlString = [NSString stringWithFormat:@"http://%@/lighttouch_api/groupdevice.php",deviceDelegate.host];
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSData *jsonData = [NSData dataWithContentsOfURL:url];
    
    if(jsonData != nil)
    {
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        //NSLog(@"json=%@",json);
        if (error == nil){
            for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
                NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
                NSMutableArray * temp = [[NSMutableArray alloc] init];
                [temp addObject:[response valueForKey:@"group_id"]];
                [temp addObject:[response valueForKey:@"name"]];
                [temp addObject:[[response valueForKey:@"device"] mutableCopy]];
        
                [groupDevice addObject:[temp mutableCopy]];
            }
            NSLog(@"groupDeviceFromAPI - %@",groupDevice);
        }
    }
}


-(void)setGroupDeviceButton {
    int column = 7;
    int row = 8;
    int x_groupDeviceButton = 5;
    int y_groupDeviceButton = 5;
    int width_groupDeviceButton = 118-x_groupDeviceButton;
    int height_groupDeviceButton = 118-y_groupDeviceButton;
    for (int i=0; i<row; i++) {
        for (int j=0; j<column; j++) {
            [self createGroupButton:myScroll
                              title:@""
                                tag:(i*column)+j+1
                                  x:x_groupDeviceButton+((width_groupDeviceButton+x_groupDeviceButton)*j)
                                  y:y_groupDeviceButton+((height_groupDeviceButton+y_groupDeviceButton)*i)
                                  w:width_groupDeviceButton
                                  h:height_groupDeviceButton
                        buttonColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]
                        shadowColor:[UIColor colorWithRed:0.171 green:0.21 blue:0.237 alpha:1]
                       shadowHeight:3.0f
                         titleColor:[UIColor cloudsColor]
                           selector:NSStringFromSelector(@selector(showAlertView:))
                               font:[UIFont flatFontOfSize:16]];
        }
    }
}

-(void)showAlertView:(id)sender {
    long tag = (long)((UIButton *)sender).tag;
    if (deviceDelegate.storeState && deviceDelegate.selected.count!=0) {
        FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Name"
                                                              message:@"Insert group name"
                                                             delegate:nil
                                                    cancelButtonTitle:@"Cancel"
                                                    otherButtonTitles:@"OK", nil];
        alertView.alertViewStyle = FUIAlertViewStylePlainTextInput;
        [@[[alertView textFieldAtIndex:0]] enumerateObjectsUsingBlock:^(FUITextField *textField, NSUInteger idx, BOOL *stop) {
            [textField setTextFieldColor:[UIColor cloudsColor]];
            [textField setBorderColor:[UIColor asbestosColor]];
            [textField setCornerRadius:4];
            [textField setFont:[UIFont flatFontOfSize:14]];
            [textField setTextColor:[UIColor midnightBlueColor]];
        }];
        [[alertView textFieldAtIndex:0] setPlaceholder:@"Text here!"];
        
        alertView.delegate = self;
        alertView.tag = tag;
        alertView.titleLabel.textColor = [UIColor cloudsColor];
        alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
        alertView.messageLabel.textColor = [UIColor cloudsColor];
        alertView.messageLabel.font = [UIFont flatFontOfSize:14];
        alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
        alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
        //alertView.alertContainer.layer.cornerRadius = cornerRadius;
        alertView.defaultButtonColor = [UIColor cloudsColor];
        alertView.defaultButtonShadowColor = [UIColor asbestosColor];
        alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
        alertView.defaultButtonTitleColor = [UIColor asbestosColor];
        [alertView show];
    }
    else if (!deviceDelegate.storeState){
        if ([groupDevice count]!=0) {
            for (int i=0; i<[groupDevice count]; i++) {
                int numberOfGroupDevice = [[[groupDevice objectAtIndex:i] objectAtIndex:0] intValue];
                if (tag==numberOfGroupDevice) {
                    deviceDelegate.selected = [[[groupDevice objectAtIndex:i]
                                             objectAtIndex:2] mutableCopy];
                    NSLog(@"select group device, selected=%@",deviceDelegate.selected);
                }
            }
            
            // create JSON form
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            [test setObject:[NSNumber numberWithLong:tag] forKey:@"group_id"];
            // send JSON form
            [deviceDelegate toString:[test mutableCopy] thatView:@"groupdevice" action:@"select_groupdevice/"];
        }
        for (int i=0; i<[groupDevice count]; i++) {
            int savedGroupDeviceTag = [[[groupDevice objectAtIndex:i] objectAtIndex:0] intValue];
            [self refresh:savedGroupDeviceTag index:i];
        }
    }
}

- (void)alertView:(FUIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString * saveNameGroup = @"";
    if (buttonIndex==1) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        saveNameGroup = textfield.text;      // name of group device
        NSLog(@"group name=%@",saveNameGroup);
        bool same = false;
        int sameIndex = 0;
        [element addObject:[NSNumber numberWithLong:(long)alertView.tag]];
        [element addObject:saveNameGroup];
        [element addObject:[deviceDelegate.selected mutableCopy]];
        if ([groupDevice count]!=0) {
            for (int i=0; i<[groupDevice count]; i++) {
                int numberOfGroupDevice = [[[groupDevice objectAtIndex:i] objectAtIndex:0] intValue];
                if (alertView.tag==numberOfGroupDevice) {
                    //NSLog(@"tag=%ld,already have=%d", tag,numberOfGroupDevice);
                    same = true;
                    sameIndex = i;
                }
            }
            if (!same) {
                [groupDevice addObject:[element mutableCopy]];
                NSLog(@"ADD save group done %@",groupDevice);
                same = false;
            }
            else {
                [groupDevice replaceObjectAtIndex:sameIndex withObject:[element mutableCopy]];
                NSLog(@"REPLACE save group done %@",groupDevice);
            }
        }
        else {
            [groupDevice addObject:[element mutableCopy]];
            NSLog(@"EMPTY_ADD save group done %@",groupDevice);
        }
        
        // create JSON form
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        NSMutableDictionary * dictEachDevice = [[NSMutableDictionary alloc] init];
        NSMutableArray * group = [[NSMutableArray alloc] init];
        [test setObject:[element objectAtIndex:0] forKey:@"group_id"];
        [test setObject:[element objectAtIndex:1] forKey:@"group_name"];
        for (int i=0; i<[[element objectAtIndex:2] count]; i++) {
            NSNumber * deviceString = [[element objectAtIndex:2] objectAtIndex:i];
            [dictEachDevice setObject:deviceString forKey:@"device_id"];
            [group addObject:[dictEachDevice mutableCopy]];
        }
        [test setObject:[group mutableCopy] forKey:@"device"];
        // send JSON form
        [deviceDelegate toString:[test mutableCopy] thatView:@"groupdevice" action:@"add_groupdevice/"];
        
        [element removeAllObjects];
        
        [super store];
    }
    for (int i=0; i<[groupDevice count]; i++) {
        int savedGroupDeviceTag = [[[groupDevice objectAtIndex:i] objectAtIndex:0] intValue];
        [self refresh:savedGroupDeviceTag index:i];
    }
}

-(void)refresh:(long)tag index:(int)index {
    FUIButton *b = (FUIButton *)[myScroll viewWithTag:tag];
    UILabel *nameLabel_hasselect = (UILabel *)(FUIButton *)[myScroll viewWithTag:10000+tag];
    UILabel *groupLabel_hasselect = (UILabel *)(FUIButton *)[myScroll viewWithTag:100000+tag];
    
    // set name
    NSString *text = @"";
    text = [[[groupDevice objectAtIndex:index] objectAtIndex:1] mutableCopy];
    nameLabel_hasselect.text = text;
    text = @"";
    
    // set group
    NSMutableArray *temp = [[NSMutableArray alloc] init];
    temp = [[[groupDevice objectAtIndex:index] objectAtIndex:2] mutableCopy];
    [temp sortUsingSelector:@selector(compare:)];
    for (int j=0; j<[temp count]; j++) {
        if(j==[temp count]-1)
            text= [text stringByAppendingString:[NSString stringWithFormat:@"%@",[temp objectAtIndex:j]]];
        else
            text=[text stringByAppendingString:[NSString stringWithFormat:@"%@,",[temp objectAtIndex:j]]];
    }
    groupLabel_hasselect.text = text;
    
    // change buttonColor
    NSMutableSet *common = [NSMutableSet setWithArray:deviceDelegate.selected];
    NSMutableArray * tempGroupSelected = [[NSMutableArray alloc] init];
    tempGroupSelected = [[[groupDevice objectAtIndex:index] objectAtIndex:2] mutableCopy];
    NSMutableSet * a =[NSMutableSet setWithArray:tempGroupSelected];
    [common intersectSet:a];
    //NSLog(@"commonCOUNT=%lu",(unsigned long)common.count);
    if (common.count == tempGroupSelected.count) {
        b.buttonColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
        b.shadowColor = [UIColor colorWithRed:0.157 green:0.507 blue:0.7 alpha:1];
    }
    else {
        b.buttonColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        b.shadowColor = [UIColor colorWithRed:0.171 green:0.21 blue:0.237 alpha:1];
    }
}

-(void)createGroupButton:(UIView *)view
                   title:(NSString *)title
                     tag:(int)tag
                       x:(int)x
                       y:(int)y
                       w:(int)w
                       h:(int)h
             buttonColor:(UIColor *)buttonColor
             shadowColor:(UIColor *)shadowColor
            shadowHeight:(float)shadowHeight
              titleColor:(UIColor *)titleColor
                selector:(NSString *)selector
                    font:(UIFont *)font {
    FUIButton *button = [[FUIButton alloc] initWithFrame:CGRectMake(x, y, w, h)];
    [button setTitle:title forState:UIControlStateNormal];
    button.tag = tag;
    button.buttonColor = buttonColor;
    button.shadowColor = shadowColor;
    button.shadowHeight = shadowHeight;
    //button.cornerRadius = 9.0f;
    NSString * btnName = [NSString stringWithFormat:@"%ld",(long)button.tag];
    [button setTitle:btnName forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = font;
    
    button.contentEdgeInsets = UIEdgeInsetsMake(5, 0, 0, 5);
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    button.contentVerticalAlignment = UIControlContentVerticalAlignmentTop;
    
    [button setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
    [button addTarget:self action:NSSelectorFromString(selector) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    
    UILabel * name = [[UILabel alloc] initWithFrame:CGRectMake(5, h/2-(25/2), w-5, 20)];
    name.text = @"";
    name.font = [UIFont flatFontOfSize:16];
    name.textColor = [UIColor cloudsColor];
    name.tag = 10000+tag;
    name.textAlignment = NSTextAlignmentCenter;
    [button addSubview:name];
    
    UILabel * group = [[UILabel alloc] initWithFrame:CGRectMake(5, h-25, w-5, 20)];
    group.text = @"";
    group.font = [UIFont flatFontOfSize:16];
    group.textColor = [UIColor cloudsColor];
    group.tag = 100000+tag;
    group.textAlignment = NSTextAlignmentCenter;
    [button addSubview:group];
}

@end
