//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "CueListViewController.h"

@interface CueListViewController ()

@end

@implementation CueListViewController {
    AppDelegate * cueListDelegate;
    NSMutableArray * sequence;
    NSMutableArray * scene;
    NSMutableArray * cue;
    UILongPressGestureRecognizer * longPress;
    UILongPressGestureRecognizer * longPress3;
    long touchDownTag;
    long sceneIndexPathRow;
    long cueIndexPathRow;
    float oldCueNumber;
    UITapGestureRecognizer *gestureRecognizer;
    UIActivityIndicatorView * activity;
}

@synthesize headerView;
@synthesize sceneView;
@synthesize cueListView;

@synthesize controlView;
@synthesize cueLabel;
@synthesize addCueButton;
@synthesize cueScrollView;
@synthesize cueView;

@synthesize headerLabel;
@synthesize sceneHeaderLabel;
@synthesize numberLabel;
@synthesize nameLabel;
@synthesize trigLabel;
@synthesize trigTimeLabel;
@synthesize fadeLabel;
@synthesize delayLabel;

@synthesize addSceneButton;
@synthesize backButton;
@synthesize playButton;
@synthesize stopButton;
@synthesize forwardButton;

@synthesize sceneTableView;
@synthesize sequenceTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    // Do any additional setup after loading the view, typically from a nib.
    [self setVariable];
    [self setPerformance];
//    [self getDataFromServer];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setVariable {
    cueListDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    sequence = [[NSMutableArray alloc] init];
    scene = [[NSMutableArray alloc] init];
    cue = [[NSMutableArray alloc] init];
}

-(void)setPerformance {
    // set view background
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    sceneView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    cueListView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    controlView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    cueView.backgroundColor = [UIColor clearColor];
    
    // set header
    headerLabel.text = @"CUE LIST";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    // set scene header
    sceneHeaderLabel.text = @"SCENE";
    sceneHeaderLabel.textColor = [UIColor whiteColor];
    
    // set cue list header
    numberLabel.text = @"NUMBER";
    numberLabel.textColor = [UIColor whiteColor];
    nameLabel.text = @"NAME";
    nameLabel.textColor = [UIColor whiteColor];
    trigLabel.text = @"TRIG";
    trigLabel.textColor = [UIColor whiteColor];
    trigTimeLabel.text = @"TRIG TIME";
    trigTimeLabel.textColor = [UIColor whiteColor];
    fadeLabel.text = @"FADE";
    fadeLabel.textColor = [UIColor whiteColor];
    delayLabel.text = @"DELAY";
    delayLabel.textColor = [UIColor whiteColor];
    
    // set table style
    sceneTableView.backgroundColor = [UIColor clearColor];
    sceneTableView.separatorColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    //sceneTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    sceneTableView.rowHeight = 96;
    
    // set cuelist table style
    sequenceTableView.backgroundColor = [UIColor clearColor];
    sequenceTableView.separatorColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    //sequenceTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    sequenceTableView.rowHeight = 50;
    
    gestureRecognizer = [[UITapGestureRecognizer alloc]
              initWithTarget:self action:@selector(handleSingleTap:)];
    gestureRecognizer.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:gestureRecognizer];
}

- (void)handleSingleTap:(UITapGestureRecognizer *) sender
{
    [self.view endEditing:YES];
}


-(void)getDataFromServer {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
     NSString * url = [NSString stringWithFormat:@"http://%@/lighttouch_api/cue_list.php", cueListDelegate.host];
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        //NSLog(@"Dictionary %@", [json objectForKey:@"totalCue"]);
        if ([[json valueForKey:@"totalCue"] intValue] != 0) {
            for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
                NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
                NSMutableArray * temp = [[NSMutableArray alloc] init];
                
                [temp addObject:[response valueForKey:@"cue_id"]];
                [temp addObject:[response valueForKey:@"cue_name"]];
                [cue addObject:temp];
                [self drawCueinScrollView:i];
            }
//            NSLog(@"cue=%@",cue);
            [self getSceneFromServer:cueListDelegate.currentCueID];
        }
        else {
            NSLog(@"don't have any cue");
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

-(void)getSceneFromServer:(int)cueID {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:[NSNumber numberWithInt:cueID] forKey:@"cueID"];
    NSString * url = [NSString stringWithFormat:@"http://%@/lighttouch_api/cue_scene.php", cueListDelegate.host];
    [manager POST:url parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        //NSLog(@"Dictionary %@", json);
        for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
            NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
            NSMutableArray * temp = [[NSMutableArray alloc] init];
            
            [temp addObject:[response valueForKey:@"scene_id"]];
            [temp addObject:[response valueForKey:@"scene_number"]];
            [temp addObject:[response valueForKey:@"scene_name"]];
            [scene addObject:temp];
        }
        [sceneTableView reloadData];
//        NSLog(@"scene = %@", scene);
        [self getSequenceFromServer:cueListDelegate.currentSceneID];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

-(void)getSequenceFromServer:(int)sceneID {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:[NSNumber numberWithInt:sceneID] forKey:@"sceneID"];
    NSString * url = [NSString stringWithFormat:@"http://%@/lighttouch_api/cue_sequence.php", cueListDelegate.host];
    [manager POST:url parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
//        NSLog(@"Dictionary %@", json);
        if ([scene count] != 0) {
            for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
                NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
                NSMutableArray * temp = [[NSMutableArray alloc] init];
                
                [temp addObject:[response valueForKey:@"sequence_id"]];
                [temp addObject:[response valueForKey:@"sequence_number"]];
                [temp addObject:[response valueForKey:@"sequence_name"]];
                [temp addObject:[response valueForKey:@"trig"]];
                [temp addObject:[response valueForKey:@"trig_time"]];
                [temp addObject:[response valueForKey:@"fade"]];
                [temp addObject:[response valueForKey:@"delay"]];
                [sequence addObject:temp];
            }
//            NSLog(@"sequence = %@", sequence);
        }
        else {
            NSLog(@"don't have any scene");
        }
        [sequenceTableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

-(IBAction)addCueButton:(id)sender {
    FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Add Cue"
                                                          message:@"Insert Cue Name"
                                                         delegate:nil
                                                cancelButtonTitle:@"Cancel"
                                                otherButtonTitles:@"OK", nil];
    alertView.alertViewStyle = FUIAlertViewStylePlainTextInput;
    [@[[alertView textFieldAtIndex:0]] enumerateObjectsUsingBlock:^(FUITextField *textField, NSUInteger idx, BOOL *stop) {
        [textField setTextFieldColor:[UIColor cloudsColor]];
        [textField setBorderColor:[UIColor asbestosColor]];
        [textField setCornerRadius:4];
        [textField setFont:[UIFont flatFontOfSize:14]];
        [textField setTextColor:[UIColor midnightBlueColor]];
    }];
    [[alertView textFieldAtIndex:0] setPlaceholder:@"Text here!"];
    
    alertView.delegate = self;
    alertView.tag = 1001;
    alertView.titleLabel.textColor = [UIColor cloudsColor];
    alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
    alertView.messageLabel.textColor = [UIColor cloudsColor];
    alertView.messageLabel.font = [UIFont flatFontOfSize:14];
    alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
    alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
    //alertView.alertContainer.layer.cornerRadius = cornerRadius;
    alertView.defaultButtonColor = [UIColor cloudsColor];
    alertView.defaultButtonShadowColor = [UIColor asbestosColor];
    alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
    alertView.defaultButtonTitleColor = [UIColor asbestosColor];
    [alertView show];
}

// show alertView
-(IBAction)addSceneButton:(id)sender {
    NSLog(@"add Scene");
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:sceneTableView];
    NSIndexPath *indexPath = [sceneTableView indexPathForRowAtPoint:buttonPosition];
    sceneIndexPathRow = indexPath.row;

    FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Add Scene"
                                                          message:@"Insert Scene Name"
                                                         delegate:nil
                                                cancelButtonTitle:@"Cancel"
                                                otherButtonTitles:@"OK", nil];
    alertView.alertViewStyle = FUIAlertViewStylePlainTextInput;
    [@[[alertView textFieldAtIndex:0]] enumerateObjectsUsingBlock:^(FUITextField *textField, NSUInteger idx, BOOL *stop) {
        [textField setTextFieldColor:[UIColor cloudsColor]];
        [textField setBorderColor:[UIColor asbestosColor]];
        [textField setCornerRadius:4];
        [textField setFont:[UIFont flatFontOfSize:14]];
        [textField setTextColor:[UIColor midnightBlueColor]];
    }];
    [[alertView textFieldAtIndex:0] setPlaceholder:@"Text here!"];
    
    alertView.delegate = self;
    alertView.tag = 2000;
    alertView.titleLabel.textColor = [UIColor cloudsColor];
    alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
    alertView.messageLabel.textColor = [UIColor cloudsColor];
    alertView.messageLabel.font = [UIFont flatFontOfSize:14];
    alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
    alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
    //alertView.alertContainer.layer.cornerRadius = cornerRadius;
    alertView.defaultButtonColor = [UIColor cloudsColor];
    alertView.defaultButtonShadowColor = [UIColor asbestosColor];
    alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
    alertView.defaultButtonTitleColor = [UIColor asbestosColor];
    [alertView show];
    
    NSLog(@"show alert");
}

-(IBAction)trigAlertView:(id)sender {
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:sequenceTableView];
    NSIndexPath *indexPath = [sequenceTableView indexPathForRowAtPoint:buttonPosition];
    cueListDelegate.currentSequenceID = [[[sequence objectAtIndex:indexPath.row] objectAtIndex:0] intValue];
//    NSLog(@"row=%ld, trigButtonTag:%ld, currentSeqID= %d",(long)indexPath.row, (long)((UIButton *)sender).tag, cueListDelegate.currentSequenceID);
    
    FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Select Trig"
                                                          message:nil
                                                         delegate:nil
                                                cancelButtonTitle:nil
                                                otherButtonTitles:nil];
    alertView.alertViewStyle = FUIAlertViewStyleDefault;
    [alertView addButtonWithTitle:@"Go"];
    [alertView addButtonWithTitle:@"Time"];
    [alertView addButtonWithTitle:@"Follow"];
    alertView.cancelButtonIndex = [alertView addButtonWithTitle:@"Cancel"];
    
    alertView.delegate = self;
    alertView.tag = 3000;
    alertView.titleLabel.textColor = [UIColor cloudsColor];
    alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
    alertView.messageLabel.textColor = [UIColor cloudsColor];
    alertView.messageLabel.font = [UIFont flatFontOfSize:14];
    alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
    alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
    //alertView.alertContainer.layer.cornerRadius = cornerRadius;
    alertView.defaultButtonColor = [UIColor cloudsColor];
    alertView.defaultButtonShadowColor = [UIColor asbestosColor];
    alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
    alertView.defaultButtonTitleColor = [UIColor asbestosColor];
    [alertView show];
    
    NSLog(@"show alert");
}

// changing scene name
- (void)handleLongPressGestures:(UILongPressGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateBegan)
    {
        FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Change Scene Name"
                                                              message:@"Insert Scene Name"
                                                             delegate:nil
                                                    cancelButtonTitle:@"Cancel"
                                                    otherButtonTitles:@"OK", nil];
        alertView.alertViewStyle = FUIAlertViewStylePlainTextInput;
        [@[[alertView textFieldAtIndex:0]] enumerateObjectsUsingBlock:^(FUITextField *textField, NSUInteger idx, BOOL *stop) {
            [textField setTextFieldColor:[UIColor cloudsColor]];
            [textField setBorderColor:[UIColor asbestosColor]];
            [textField setCornerRadius:4];
            [textField setFont:[UIFont flatFontOfSize:14]];
            [textField setTextColor:[UIColor midnightBlueColor]];
        }];
        [[alertView textFieldAtIndex:0] setPlaceholder:@"Text here!"];
        
        alertView.delegate = self;
        alertView.tag = 2001;
        alertView.titleLabel.textColor = [UIColor cloudsColor];
        alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
        alertView.messageLabel.textColor = [UIColor cloudsColor];
        alertView.messageLabel.font = [UIFont flatFontOfSize:14];
        alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
        alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
        //alertView.alertContainer.layer.cornerRadius = cornerRadius;
        alertView.defaultButtonColor = [UIColor cloudsColor];
        alertView.defaultButtonShadowColor = [UIColor asbestosColor];
        alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
        alertView.defaultButtonTitleColor = [UIColor asbestosColor];
        [alertView show];
        
        NSLog(@"show alert");
    }
}

- (void)alertView:(FUIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    // adding cue button alertView
    if (alertView.tag==1001 && buttonIndex==1) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        NSString * cueName = textfield.text;
        NSLog(@"cueName=%@",cueName);
        
        // create JSON form
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        [test setObject:cueName forKey:@"cue_name"];
        
        // send JSON form
        [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"add_cue/"];
        
        [cue removeAllObjects];
        [scene removeAllObjects];
        [sequence removeAllObjects];
        [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(getDataFromServer) userInfo:nil repeats:NO];
    }
    // add Scene
    else if (alertView.tag == 2000) {
        if (buttonIndex == 1) {
            NSString * savedSceneName = @"";
            UITextField *textfield = [alertView textFieldAtIndex:0];
            savedSceneName = textfield.text;      // scene name
            //[[scene objectAtIndex:sceneIndexPathRow] replaceObjectAtIndex:1 withObject:savedSceneName];
            
            // create JSON form
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            [test setObject:[NSNumber numberWithInt:cueListDelegate.currentCueID] forKey:@"cue_id"];
            [test setObject:savedSceneName forKey:@"scene_name"];
            
            // send JSON form
            [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"add_scene/"];
            
            [scene removeAllObjects];
            [sequence removeAllObjects];
            [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(addSceneFinish) userInfo:nil repeats:NO];
        }
    }
    // change Scene Name (don't test yet)
    else if (alertView.tag == 2001) {
        if (buttonIndex == 1) {
            NSString * newSceneName = @"";
            UITextField *textfield = [alertView textFieldAtIndex:0];
            newSceneName = textfield.text;      // new scene name
            //[[scene objectAtIndex:sceneIndexPathRow] replaceObjectAtIndex:1 withObject:savedSceneName];
            
            // create JSON form
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSceneID]
                     forKey:@"scene_id"];
            [test setObject:newSceneName forKey:@"scene_name"];
            
            // send JSON form
            [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"set_sceneName/"];
            
            [scene removeAllObjects];
            [sequence removeAllObjects];
            [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(addSceneFinish) userInfo:nil repeats:NO];
        }
    }
    // change Trig
    else if (alertView.tag == 3000 && ![[alertView buttonTitleAtIndex:buttonIndex] isEqual:@"Cancel"]) {
        int trig;
        
        // set trig
        if (buttonIndex==0)         trig = 1;
        else if (buttonIndex==1)    trig = 2;
        else if (buttonIndex==2)    trig = 3;
        
        // create JSON form
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSequenceID]
                 forKey:@"sequence_id"];
        [test setObject:[NSNumber numberWithInt:trig] forKey:@"trig"];
        
        // send JSON form
        [cueListDelegate toString:[test mutableCopy]
                         thatView:@"cuelist"
                           action:@"edit_sequence_trig/"];
        
        [sequence removeAllObjects];
        [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(changeTrigFinish) userInfo:nil repeats:NO];
    }
    // add Scene
    else if (alertView.tag == 4000) {
        if (![[alertView buttonTitleAtIndex:buttonIndex] isEqual:@"Cancel"]) {
            NSLog(@"delete touchDownTag =%ld",touchDownTag);
            NSNumber * delCueID = [NSNumber numberWithFloat:touchDownTag];
            
            // create JSON form
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            [test setObject:delCueID forKey:@"cue_id"];
            
            // send JSON form
            [cueListDelegate toString:[test mutableCopy] thatView:@"cueList" action:@"delete_cue/"];
            [NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(deleteCueFin) userInfo:nil repeats:NO];
        }
    }
}

-(void)addSceneFinish {
    [self getSceneFromServer:cueListDelegate.currentCueID];
}

-(void)changeTrigFinish {
    [self getSequenceFromServer:cueListDelegate.currentSceneID];
}

-(IBAction)changeTextBegin:(id)sender {
    UITextField * myTextField = (UITextField *)sender;
    if (myTextField.tag==1) {
        oldCueNumber = [myTextField.text floatValue];
        NSLog(@"oldCueNumber =%f",oldCueNumber);
    }
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:sequenceTableView];
    NSIndexPath *indexPath = [sequenceTableView indexPathForRowAtPoint:buttonPosition];
    cueListDelegate.currentSequenceID = [[[sequence objectAtIndex:indexPath.row] objectAtIndex:0] intValue];
//    NSLog(@"sequence = %@",sequence);
//    NSLog(@"row=%ld, trigButtonTag:%ld, currentSeqID= %d",(long)indexPath.row, (long)((UIButton *)sender).tag, cueListDelegate.currentSequenceID);
}


-(IBAction)changeTextEnded:(id)sender {
    UITextField * myTextField = (UITextField *)sender;
    NSNumber * value = [NSNumber numberWithFloat:[myTextField.text floatValue]];
    NSString * key = @"";
    NSString * action = @"";
    
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    if (myTextField.tag == 1) {
        key = @"sequence_number";
        action = @"edit_sequence_number/";
        //        [test setObject:oldCueNumber forKey:@"old_number"];
    }
    else if (myTextField.tag == 2) {
        key = @"sequence_name";
        action = @"edit_sequence_name/";
    }
    else if (myTextField.tag == 4) {
        key = @"time";
        action = @"edit_sequence_trigTime/";
    }
    else if (myTextField.tag == 5) {
        key = @"fade";
        action = @"edit_sequence_fade/";
    }
    else if (myTextField.tag == 6) {
        key = @"delay";
        action = @"edit_sequence_delay/";
    }
    
    [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSequenceID]
             forKey:@"sequence_id"];
    if (myTextField.tag != 2) {
        [test setObject:value forKey:key];
    }
    else {
        [test setObject:myTextField.text forKey:key];
    }
    
    // send JSON form
    [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:action];
    
    [sequence removeAllObjects];
    [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(changeTrigFinish) userInfo:nil repeats:NO];
}

-(void)drawCueinScrollView:(int)index {
    int yCueButton = 7;
    int wCueButton = 78;
    int hCueButton = 40;
    int xCueButton = ([cue count]-1)*wCueButton+(yCueButton*[cue count]-1);
    
    UIButton * cueButton = [[UIButton alloc] initWithFrame:CGRectMake(xCueButton, yCueButton, wCueButton, hCueButton)];
    [cueButton setTitle:[[cue objectAtIndex:index] objectAtIndex:1]   forState:UIControlStateNormal];
    [cueButton setTag:[cue count]];
    [cueButton setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    [cueButton addTarget:self action:@selector(cue:) forControlEvents:UIControlEventTouchUpInside];
    [cueScrollView addSubview:cueButton];
    
    cueButton.titleLabel.numberOfLines = 1;
    cueButton.titleLabel.minimumScaleFactor = 8./cueButton.titleLabel.font.pointSize;
    cueButton.titleLabel.adjustsFontSizeToFitWidth = YES;
    
    int x = CGRectGetMaxX(((UIView*)[cueScrollView.subviews lastObject]).frame);
    [cueScrollView setContentSize:(CGSizeMake(x, CGRectGetHeight(cueScrollView.frame)))];
    
    longPress3 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressGestures3:)];
    longPress3.minimumPressDuration = 1.0f;
    longPress3.allowableMovement = 100.0f;
    [cueButton addGestureRecognizer:longPress3];
}

-(void)touchDown:(id)sender {
    touchDownTag = ((UIButton *)sender).tag;
}

- (void)handleLongPressGestures3:(UILongPressGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateBegan)
    {
        //delegateInControlBar.addSequence = true;
        [self cueAlertView];
    }
}

-(void)cueAlertView {
    NSLog(@"cueAlertView");
    
    FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Delete Cue"
                                                          message:nil
                                                         delegate:nil
                                                cancelButtonTitle:nil
                                                otherButtonTitles:nil];
    alertView.alertViewStyle = FUIAlertViewStyleDefault;
    [alertView addButtonWithTitle:@"Delete Cue"];
    alertView.cancelButtonIndex = [alertView addButtonWithTitle:@"Cancel"];
    alertView.delegate = self;
    alertView.tag = 4000;
    alertView.titleLabel.textColor = [UIColor cloudsColor];
    alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
    alertView.messageLabel.textColor = [UIColor cloudsColor];
    alertView.messageLabel.font = [UIFont flatFontOfSize:14];
    alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
    alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
    //alertView.alertContainer.layer.cornerRadius = cornerRadius;
    alertView.defaultButtonColor = [UIColor cloudsColor];
    alertView.defaultButtonShadowColor = [UIColor asbestosColor];
    alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
    alertView.defaultButtonTitleColor = [UIColor asbestosColor];
    [alertView show];
}

-(void)cue:(id)sender {
//    NSLog(@"%ld",(long)((UIButton *)sender).tag);
    cueListDelegate.currentCueID = [[[cue objectAtIndex:((UIButton *)sender).tag-1] objectAtIndex:0] intValue];
    for (UIButton * hl in cueScrollView.subviews) {
        if (((UIButton *)sender).tag==hl.tag) {
//            hl.buttonColor = [UIColor sunflowerColor];
//            hl.shadowColor = [UIColor orangeColor];
            [hl setBackgroundColor:[UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1]];
//            [hl setSelected:YES];
        }
        else {
//            hl.buttonColor = [UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1];
//            hl.shadowColor = [UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1];
            [hl setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
//            [hl setSelected:NO];
        }
    }
//    NSLog(@"cueListDelegate.currentCueID=%d",cueListDelegate.currentCueID);
    
    NSMutableDictionary * sendToLoad = [[NSMutableDictionary alloc] init];
    [sendToLoad setObject:[NSNumber numberWithInt:cueListDelegate.currentCueID] forKey:@"cue_id"];
    [cueListDelegate sendUDP:[NSString stringWithFormat:@"cue/%@",sendToLoad]];
    
//    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
//    activity.center = CGPointMake(400, 400);
//    [self.view addSubview:activity];
//    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(load) userInfo:nil repeats:NO];
//    [activity startAnimating];
//     NSLog(@"start");

    [scene removeAllObjects];
    [sequence removeAllObjects];
    [self getSceneFromServer:cueListDelegate.currentCueID];
}

-(void)load {
    if (cueListDelegate.loadFinished) {
        NSLog(@"stop");
        [activity stopAnimating];
        [scene removeAllObjects];
        [sequence removeAllObjects];
        [self getSceneFromServer:cueListDelegate.currentCueID];
        cueListDelegate.loadFinished = 0;
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == sceneTableView) {
        return [scene count];
    }
    else if (tableView == sequenceTableView) {
        return [sequence count];
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"sceneCell";
    static NSString * cellIdentifier2 = @"sequenceCell";
    UITableViewCell *cell;
    
    if (tableView == sceneTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
        cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        
        [tableView selectRowAtIndexPath:cueListDelegate.sceneIndexPath
                               animated:NO
                         scrollPosition:UITableViewScrollPositionNone];
//        if ([cell isSelected]) {
//            UIView *bgColorView = [[UIView alloc] init];
//            bgColorView.backgroundColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
//            [cell setSelectedBackgroundView:bgColorView];
//        }
        
        // add longPress to cell
        longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressGestures:)];
        longPress.minimumPressDuration = 1.0f;
        longPress.allowableMovement = 100.0f;
        [cell addGestureRecognizer:longPress];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [self showScene:cell indexPath:indexPath];
        return cell;
    }
    else if (tableView == sequenceTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier2 forIndexPath:indexPath];
        cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        
        [tableView selectRowAtIndexPath:cueListDelegate.sequenceIndexPath
                               animated:NO
                         scrollPosition:UITableViewScrollPositionNone];
//        if ([cell isSelected]) {
//            UIView *bgColorView = [[UIView alloc] init];
//            bgColorView.backgroundColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
//            [cell setSelectedBackgroundView:bgColorView];
//        }
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier2];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [self showSequence:cell indexPath:indexPath];
        return cell;
    }
    return 0;
}

-(void)showScene:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * label1 = (UILabel *)[cell viewWithTag:1];
    UILabel * label2 = (UILabel *)[cell viewWithTag:11];
    
    NSString * label1Text = [NSString stringWithFormat:@"%@",[[scene objectAtIndex:indexPath.row] objectAtIndex:0+1]];
    label1.text = label1Text;
    label1.textColor = [UIColor whiteColor];
    label1.textAlignment = NSTextAlignmentCenter;
    
    NSString * label2Text = [[scene objectAtIndex:indexPath.row] objectAtIndex:1+1];
    label2.text = label2Text;
    label2.textColor = [UIColor whiteColor];
    label2.textAlignment = NSTextAlignmentCenter;
}

-(void)showSequence:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UITextField * number = (UITextField *)[cell viewWithTag:1];
    UITextField * name = (UITextField *)[cell viewWithTag:2];
    UIButton * trig = (UIButton *)[cell viewWithTag:3];
    UITextField * trigTime = (UITextField *)[cell viewWithTag:4];
    UITextField * fade = (UITextField *)[cell viewWithTag:5];
    UITextField * delay = (UITextField *)[cell viewWithTag:6];
    
    number.delegate = self;
    name.delegate = self;
    trigTime.delegate = self;
    fade.delegate = self;
    delay.delegate = self;
    
    NSString * numberValue = [NSString stringWithFormat:@"%@",[[sequence objectAtIndex:indexPath.row] objectAtIndex:0+1]];
    NSString * nameValue = [[sequence objectAtIndex:indexPath.row] objectAtIndex:1+1];
    NSString * trigTitle = [[sequence objectAtIndex:indexPath.row] objectAtIndex:2+1];
    NSString * trigTimeValue = [[sequence objectAtIndex:indexPath.row] objectAtIndex:3+1];
    NSString * fadeValue = [[sequence objectAtIndex:indexPath.row] objectAtIndex:4+1];
    NSString * delayValue = [[sequence objectAtIndex:indexPath.row] objectAtIndex:5+1];
    
    number.text = numberValue;
    name.text = nameValue;
    [trig setTitle:trigTitle forState:UIControlStateNormal];
    trigTime.text = trigTimeValue;
    fade.text = fadeValue;
    delay.text = delayValue;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    UIView *bgColorView = [[UIView alloc] init];
    bgColorView.backgroundColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    [cell setSelectedBackgroundView:bgColorView];
    if (tableView == sceneTableView) {
//        NSLog(@"scene, select cell, indexpath.row=%ld",(long)indexPath.row);
        cueListDelegate.sceneIndexPath = indexPath;
        cueListDelegate.currentSceneNumber = (int)indexPath.row+1;
        cueListDelegate.currentSceneID = [[[scene objectAtIndex:indexPath.row] objectAtIndex:0] intValue];
        
        
        // create JSON form
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        
        [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSceneID]
                 forKey:@"scene_id"];
        
        // send JSON form
        [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"select_scene/"];
        
        [sequence removeAllObjects];
        [self getSequenceFromServer:cueListDelegate.currentSceneID];
    }
    else if (tableView == sequenceTableView) {
//        NSLog(@"sequence, select cell, indexpath.row=%ld",(long)indexPath.row);
        cueListDelegate.sequenceIndexPath = indexPath;
        NSLog(@"1");
//        NSLog(@"sequence id = %d",[[[sequence objectAtIndex:indexPath.row] objectAtIndex:0] intValue]);
        cueListDelegate.currentSequenceID = [[[sequence objectAtIndex:indexPath.row] objectAtIndex:0] intValue];
        NSLog(@"2");
        // create JSON form
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        
        [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSequenceID]
                 forKey:@"sequence_id"];
        NSLog(@"3");
        // send JSON form
        [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"select_sequence/"];
    }
}

-(IBAction)playButton:(id)sender {
//    for(UIButton *button in [cueListView subviews]) {
//        if([button isKindOfClass:[UIButton class]]) {
//            NSLog(@"%@",button);
//        }
//    }
    
//    UIButton * btn = (UIButton *)sender;
//    if (!btn.selected) {
//        btn.selected = YES;
//    }
//    else btn.selected = NO;
    
    NSLog(@"play");
    
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    
    [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSceneID]
             forKey:@"scene_id"];
    
    // send JSON form
    [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"play/"];
}

-(IBAction)pauseButton:(id)sender {
    
//    UIButton * btn = (UIButton *)sender;
//    if (!btn.selected) {
//        btn.selected = YES;
//    }
//    else btn.selected = NO;
    
    NSLog(@"pause");
    
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    
    [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSceneID]
             forKey:@"scene_id"];
    
    // send JSON form
    [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"pause/"];
}

-(IBAction)backButton:(id)sender {
    NSLog(@"back");
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    
    [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSceneID]
             forKey:@"scene_id"];
    
    // send JSON form
    [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"backward/"];
}

-(IBAction)stopButton:(id)sender {
    NSLog(@"stop");
    
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    
    [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSceneID]
             forKey:@"scene_id"];
    
    // send JSON form
    [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"stop/"];
}

-(IBAction)forwardButton:(id)sender {
    NSLog(@"forward");
    
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    
    [test setObject:[NSNumber numberWithInt:cueListDelegate.currentSceneID]
             forKey:@"scene_id"];
    
    // send JSON form
    [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"forward/"];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if (tableView == sequenceTableView) {
            //remove the deleted object from your data source.
            //If your data source is an NSMutableArray, do this
//            NSLog(@"delete=%@",[[sequence objectAtIndex:indexPath.row] objectAtIndex:0]);
            
            /* create JSON form */
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            
            [test setObject:[NSNumber numberWithInt:[[[sequence objectAtIndex:indexPath.row] objectAtIndex:0] intValue]] forKey:@"sequence_id"];
            
            /* send JSON form */
            [cueListDelegate toStringDelete:[test mutableCopy] thatView:@"cueList" action:@"delete_sequence/"];
            
            //        if (patchingDelegate.selected.count!=0)
            //            [patchingDelegate.selected removeObjectIdenticalTo:[NSNumber numberWithInt:(int)indexPath.row+1]];
            [sequence removeObjectAtIndex:indexPath.row];     // delete data from array
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(deleteSequenceFinished) userInfo:nil repeats:NO];
        }
        else if(tableView == sceneTableView) {
            //remove the deleted object from your data source.
            //If your data source is an NSMutableArray, do this
            NSLog(@"delete=%@",[[scene objectAtIndex:indexPath.row] objectAtIndex:0]);
            
            /* create JSON form */
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            
            [test setObject:[NSNumber numberWithInt:[[[scene objectAtIndex:indexPath.row] objectAtIndex:0] intValue]] forKey:@"scene_id"];
            
            /* send JSON form */
            [cueListDelegate toStringDelete:[test mutableCopy] thatView:@"cueList" action:@"delete_scene/"];
            
            //        if (patchingDelegate.selected.count!=0)
            //            [patchingDelegate.selected removeObjectIdenticalTo:[NSNumber numberWithInt:(int)indexPath.row+1]];
            [scene removeObjectAtIndex:indexPath.row];     // delete data from array
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(deleteSceneFinished) userInfo:nil repeats:NO];
        }
    }
}

-(void)deleteSequenceFinished {
    [sequence removeAllObjects];
    [self getSequenceFromServer:cueListDelegate.currentSceneID];
}

-(void)deleteSceneFinished {
    [scene removeAllObjects];
    [self getSceneFromServer:cueListDelegate.currentCueID];
}

-(void)deleteCueFin {
    [[cueScrollView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [cue removeAllObjects];
    [self getDataFromServer];
}

@end
