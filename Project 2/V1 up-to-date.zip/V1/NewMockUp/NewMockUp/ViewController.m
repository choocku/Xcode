//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController {
    AppDelegate * ad;
    ContainerController * con;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    
    // green
    // [UIColor colorWithRed:0.631 green:0.78 blue:0.173 alpha:1]
    
    // blue
    // [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1]
    
    // red
    // [UIColor colorWithRed:1 green:0.29 blue:0.165 alpha:1]
    
    // grey
    // [UIColor colorWithRed:0.592 green:0.592 blue:0.592 alpha:1]
    
    // cell bg
    // [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]
    
    CAGradientLayer *bgLayer = [BackgroundLayer greyGradient];
    bgLayer.frame = self.view.bounds;
    [self.view.layer insertSublayer:bgLayer atIndex:0];
    
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    con = [[self childViewControllers] objectAtIndex:0];
    ad.page = @"PatchingViewController";
    [con viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (IBAction)patchingButton:(id)sender {
    ad.page = @"PatchingViewController";
    [con viewDidLoad];
}

- (IBAction)layoutButton:(id)sender {
    ad.page = @"LayoutViewController";
    [con viewDidLoad];
}

- (IBAction)deviceButton:(id)sender {
    ad.page = @"DeviceViewController";
    [con viewDidLoad];
}

- (IBAction)allPresetButton:(id)sender {
    ad.page = @"AllPresetViewController";
    [con viewDidLoad];
}

- (IBAction)cueListButton:(id)sender {
    ad.page = @"CueListViewController";
    [con viewDidLoad];
}


@end
