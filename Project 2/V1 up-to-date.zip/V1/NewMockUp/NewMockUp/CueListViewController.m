//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "CueListViewController.h"

@interface CueListViewController ()

@end

@implementation CueListViewController {
    AppDelegate * cueListDelegate;
    NSMutableArray * cueList;
    NSMutableArray * scene;
}

@synthesize headerView;
@synthesize sceneView;
@synthesize cueListView;
@synthesize controlView;

@synthesize headerLabel;
@synthesize sceneHeaderLabel;
@synthesize numberLabel;
@synthesize nameLabel;
@synthesize trigLabel;
@synthesize trigTimeLabel;
@synthesize fadeLabel;
@synthesize delayLabel;

@synthesize addSceneButton;

@synthesize sceneTableView;
@synthesize cueListTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setVariable];
    [self setPerformance];
}

-(void)viewDidAppear:(BOOL)animated {
    [sceneTableView reloadData];
    [cueListTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setVariable {
    cueListDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    cueList = [[NSMutableArray alloc] init];
    //NSMutableArray * cue = [[NSMutableArray alloc] init];
    //NSMutableArray * data = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:1], @"check", @"Go", @"1.0", @"1.1", @"0", nil];
    //NSMutableArray * data2 = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:2], @"aaa", @"Go", @"1.0", @"1.1", @"0", nil];
    //[cue addObject:data];
    //[cue addObject:data2];
    //[cueList addObject:cue];
    scene = [[NSMutableArray alloc] init];
    NSLog(@"cueList=%@",cueList);
}

-(void)setPerformance {
    // set view background
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    sceneView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    cueListView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    controlView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    // set header
    headerLabel.text = @"CUE LIST";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    // set scene header
    sceneHeaderLabel.text = @"SCENE";
    sceneHeaderLabel.textColor = [UIColor whiteColor];
    
    // set cue list header
    numberLabel.text = @"NUMBER";
    numberLabel.textColor = [UIColor whiteColor];
    nameLabel.text = @"NAME";
    nameLabel.textColor = [UIColor whiteColor];
    trigLabel.text = @"TRIG";
    trigLabel.textColor = [UIColor whiteColor];
    trigTimeLabel.text = @"TRIG TIME";
    trigTimeLabel.textColor = [UIColor whiteColor];
    fadeLabel.text = @"FADE";
    fadeLabel.textColor = [UIColor whiteColor];
    delayLabel.text = @"DELAY";
    delayLabel.textColor = [UIColor whiteColor];
    
    // set table style
    sceneTableView.backgroundColor = [UIColor clearColor];
    sceneTableView.separatorColor = [UIColor clearColor];
    sceneTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    sceneTableView.rowHeight = 96;
    
    // set cuelist table style
    cueListTableView.backgroundColor = [UIColor clearColor];
    cueListTableView.separatorColor = [UIColor clearColor];
    cueListTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    cueListTableView.rowHeight = 50;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == sceneTableView) {
        return [scene count];
    }
    else if (tableView == cueListTableView) {
        if (cueListDelegate.currentScene == -1) {
            return 0;
        }
        else {
            return [[cueList objectAtIndex:cueListDelegate.currentScene] count];
        }
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"sceneCell";
    static NSString * cellIdentifier2 = @"cueListCell";
    UITableViewCell *cell;
    if (tableView == sceneTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
        cell.backgroundColor = [UIColor clearColor];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [self showScene:cell indexPath:indexPath];
        return cell;
    }
    else if (tableView == cueListTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier2 forIndexPath:indexPath];
        cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier2];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [self showCue:cell indexPath:indexPath];
        return cell;
    }
    return 0;
}

-(void)showScene:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UIButton * button1 = (UIButton *)[cell viewWithTag:1];
    UILabel * label1 = (UILabel *)(UIButton *)[cell viewWithTag:11];
    
    [button1 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    NSNumber * sceneID = [[scene objectAtIndex:indexPath.row] objectAtIndex:0];
    NSString * btnTitle = [NSString stringWithFormat:@"%@",sceneID];
    [button1 setTitle:btnTitle forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button1.titleLabel.textAlignment = NSTextAlignmentCenter;
    
    NSString * btnText = [[scene objectAtIndex:indexPath.row] objectAtIndex:1];
    label1.text = btnText;
    label1.textColor = [UIColor whiteColor];
    label1.textAlignment = NSTextAlignmentCenter;
}

-(void)showCue:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    if (cueListDelegate.currentScene != -1) {
        UILabel * number = (UILabel *)[cell viewWithTag:1];
        UITextField * name = (UITextField *)[cell viewWithTag:2];
        UIButton * trig = (UIButton *)[cell viewWithTag:3];
        UITextField * trigTime = (UITextField *)[cell viewWithTag:4];
        UITextField * fade = (UITextField *)[cell viewWithTag:5];
        UITextField * delay = (UITextField *)[cell viewWithTag:6];
        
        NSString * numberValue = [NSString stringWithFormat:@"%@",[[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:0]];
        NSString * nameValue = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:1];
        NSString * trigTitle = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:2];
        NSString * trigTimeValue = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:3];
        NSString * fadeValue = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:4];
        NSString * delayValue = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:5];
        
        number.text = numberValue;
        name.text = nameValue;
        [trig setTitle:trigTitle forState:UIControlStateNormal];
        trigTime.text = trigTimeValue;
        fade.text = fadeValue;
        delay.text = delayValue;
    }
}

-(IBAction)trigAlertView:(id)sender {
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:cueListTableView];
    NSIndexPath *indexPath = [cueListTableView indexPathForRowAtPoint:buttonPosition];
    NSLog(@"row=%ld, trigButtonTag:%ld",(long)indexPath.row, (long)((UIButton *)sender).tag);
}

-(IBAction)scene:(id)sender {
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:sceneTableView];
    NSIndexPath *indexPath = [sceneTableView indexPathForRowAtPoint:buttonPosition];
    cueListDelegate.currentScene = indexPath.row;
    NSLog(@"row=%ld currentScene=%d",(long)indexPath.row, cueListDelegate.currentScene);
    [cueListTableView reloadData];
}

// show alertView
-(IBAction)sceneShowAlertView:(id)sender {
    long tag = (long)((UIButton *)sender).tag;
    FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Name"
                                                          message:@"Insert Scene Name"
                                                         delegate:nil
                                                cancelButtonTitle:@"Cancel"
                                                otherButtonTitles:@"OK", nil];
    alertView.alertViewStyle = FUIAlertViewStylePlainTextInput;
    [@[[alertView textFieldAtIndex:0]] enumerateObjectsUsingBlock:^(FUITextField *textField, NSUInteger idx, BOOL *stop) {
        [textField setTextFieldColor:[UIColor cloudsColor]];
        [textField setBorderColor:[UIColor asbestosColor]];
        [textField setCornerRadius:4];
        [textField setFont:[UIFont flatFontOfSize:14]];
        [textField setTextColor:[UIColor midnightBlueColor]];
    }];
    [[alertView textFieldAtIndex:0] setPlaceholder:@"Text here!"];
    
    alertView.delegate = self;
    alertView.tag = tag;
    alertView.titleLabel.textColor = [UIColor cloudsColor];
    alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
    alertView.messageLabel.textColor = [UIColor cloudsColor];
    alertView.messageLabel.font = [UIFont flatFontOfSize:14];
    alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
    alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
    //alertView.alertContainer.layer.cornerRadius = cornerRadius;
    alertView.defaultButtonColor = [UIColor cloudsColor];
    alertView.defaultButtonShadowColor = [UIColor asbestosColor];
    alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
    alertView.defaultButtonTitleColor = [UIColor asbestosColor];
    [alertView show];
}

- (void)alertView:(FUIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString * savedSceneName = @"";
    NSMutableArray * tempObject = [[NSMutableArray alloc] init];
    if (buttonIndex==1) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        savedSceneName = textfield.text;      // scene name
        NSNumber * sceneNumber = [NSNumber numberWithLong:[scene count]+1];  // scene number
        [tempObject addObject:sceneNumber];
        [tempObject addObject:savedSceneName];
        [scene addObject:tempObject];
        NSMutableArray * temp = [[NSMutableArray alloc] init];
        [cueList addObject:temp];
        
        // create JSON form
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        [test setObject:[tempObject objectAtIndex:0] forKey:@"scene_id"];
        [test setObject:[tempObject objectAtIndex:1] forKey:@"scene_name"];
        
        // send JSON form
        [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"add_scene/"];
        
        [sceneTableView reloadData];
        cueListDelegate.currentScene = [sceneNumber intValue]-1;
        NSLog(@"scene=%@,cueList=%@, currentScene=%d",scene, cueList, cueListDelegate.currentScene);
        [cueListTableView reloadData];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

@end
