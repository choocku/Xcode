//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "LayoutViewController.h"

@interface LayoutViewController ()

@end

@implementation LayoutViewController {
    AppDelegate * layoutDelegate;
    NSMutableArray * layout;
    int x_drawDevices;
    int y_drawDevices;
    int width_drawDevices;
    int height_drawDevices;
    int checkDragged;
    bool loadComplete;
}

@synthesize headerView;
@synthesize dataView;
@synthesize headerLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    [super initControlBar];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    dataView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    headerLabel.text = @"LAYOUT";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    [self initVariables];
    
    if (!loadComplete) {
        //[self loadData];
        loadComplete = true;
    }
    
    [self initButtonFromPatching];
    
    if (layoutDelegate.selected.count!=0) {
        NSLog(@"layout again");
        for (int i=0; i<layoutDelegate.selected.count; i++) {
            int selectedButtonTag = [[layoutDelegate.selected objectAtIndex:i] intValue];
            NSLog(@"selectButtonTAG=%d",selectedButtonTag);
            [self setHasSelectedButton:selectedButtonTag];
            //NSLog(@"selected=%d",selectedButton);
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initVariables {
    layoutDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    layout = [[NSMutableArray alloc] init];
    
    // parameter of drawDevices
    x_drawDevices = dataView.bounds.size.width/2;
    y_drawDevices = 50;
    width_drawDevices = 44;
    height_drawDevices = 44;
    checkDragged = 0;
    
    loadComplete = false;
}

-(void)loadData {
    NSString * urlString = [NSString stringWithFormat:@"http://%@/lighttouch_api/layout.php",layoutDelegate.host];
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSData *jsonData = [NSData dataWithContentsOfURL:url];
    
    if(jsonData != nil)
    {
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        if (error == nil){
            for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
                NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
                NSMutableArray * temp = [[NSMutableArray alloc] init];
                
                [temp addObject:[response valueForKey:@"device_id"]];
                [temp addObject:[response valueForKey:@"type"]];
                [temp addObject:[response valueForKey:@"xLayoutPosition"]];
                [temp addObject:[response valueForKey:@"yLayoutPosition"]];
                
                [layout addObject:[temp mutableCopy]];
            }
            NSLog(@"layoutFromAPI - %@",layout);
        }
    }
}

- (void)button:(id)sender withEvent:(UIEvent *)event {
    ((UIButton *)sender).selected = !((UIButton *)sender).selected;
    if (!checkDragged) {
        if(((UIButton *)sender).selected) {
            //NSLog(@"save %d",((UIButton *)sender).tag);
            [layoutDelegate.selected addObject:[NSNumber numberWithInt:(int)((UIButton *)sender).tag]];
            [[((UIButton *)sender) layer] setBorderColor:[UIColor sunflowerColor].CGColor];
        }
        else {
            //NSLog(@"remove %d",((UIButton *)sender).tag);
            [layoutDelegate.selected removeObjectIdenticalTo:[NSNumber numberWithInt:(int)((UIButton *)sender).tag]];
            [[((UIButton *)sender) layer] setBorderColor:[UIColor blackColor].CGColor];
        }
        NSLog(@"layoutDelegate.selected=%@",layoutDelegate.selected);
    }
    else {
        checkDragged = 0;
    }
}

-(void)setHasSelectedButton:(int)tag {
    UIButton * hasSelected = (UIButton *)[dataView viewWithTag:tag];
    NSLog(@"setHasSelectedButton tag=%ld,name=%@", (long)hasSelected.tag, hasSelected.titleLabel.text);
    [hasSelected setSelected:YES];
    if(hasSelected.selected) {
        //NSLog(@"setColor %d",hasSelected.tag);
        [[hasSelected layer] setBorderColor:[UIColor sunflowerColor].CGColor];
    }
}

- (void)wasDragged:(UIButton *)button withEvent:(UIEvent *)event
{
    checkDragged = 1;
    // get the touch
    UITouch *touch = [[event touchesForView:button] anyObject];
    
    // get delta
    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;
    
    // move button
    if( button.frame.origin.x<0 || button.center.x+button.frame.size.width/2>dataView.bounds.size.width ||
       button.frame.origin.y<0 || button.center.y+button.frame.size.height/2>dataView.bounds.size.height ) {
        button.center = CGPointMake(x_drawDevices+button.bounds.size.width/2,
                                    y_drawDevices+button.bounds.size.height/2);
    }
    else {
        button.center = CGPointMake(button.center.x + delta_x,
                                    button.center.y + delta_y);
    }
    [[layout objectAtIndex:button.tag-1] replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:button.center.x]];
    [[layout objectAtIndex:button.tag-1] replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:button.center.y]];
    [self sendValToServer:button.tag];
}

-(void)sendValToServer:(long)tag {
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    [test setObject:[[layout objectAtIndex:tag-1] objectAtIndex:0] forKey:@"device_id"];
    [test setObject:[[layout objectAtIndex:tag-1] objectAtIndex:1] forKey:@"xLayoutPosition"];
    [test setObject:[[layout objectAtIndex:tag-1] objectAtIndex:2] forKey:@"yLayoutPosition"];
    // send JSON form
    [layoutDelegate toString:[test mutableCopy] thatView:@"layout" action:@"update_layout/"];
}

-(void)initButtonFromPatching {
    //[self createClearButton];
    for (int i=0; i<layout.count; i++) {
        int deviceID = [[[layout objectAtIndex:i] objectAtIndex:0] intValue];
        //NSString * get_type = [[layout objectAtIndex:i] objectAtIndex:1];
        float xLayoutPosition = [[[layout objectAtIndex:i] objectAtIndex:2] floatValue];
        float yLayoutPosition = [[[layout objectAtIndex:i] objectAtIndex:3] floatValue];
        UIButton * button = [[UIButton alloc] initWithFrame:
                             CGRectMake(xLayoutPosition-width_drawDevices/2,
                                        yLayoutPosition-height_drawDevices/2,
                                        width_drawDevices,
                                        height_drawDevices)];
        [button setBackgroundColor:[UIColor colorWithRed:0.631 green:0.78 blue:0.173 alpha:1]];
        button.tag = deviceID;
        NSString * title = [NSString stringWithFormat:@"%d",deviceID];
        [button setTitle:title forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [[button layer] setBorderWidth:4.0f];
        [[button layer] setBorderColor:[UIColor blackColor].CGColor];
        [button addTarget:self action:@selector(button:withEvent:)
         forControlEvents:UIControlEventTouchUpInside];
        [button addTarget:self action:@selector(wasDragged:withEvent:)
         forControlEvents:UIControlEventTouchDragInside];
        [dataView addSubview:button];
    }
    
}

@end
