//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "AllPresetViewController.h"

@interface AllPresetViewController ()

@end

@implementation AllPresetViewController {
    AppDelegate * allPresetDelegate;
    
    NSMutableArray * element;
    NSMutableArray * allPreset;
    
    // all preset
    UIView *allPresetView;
    UIScrollView *myScroll;
    int x_allPresetView;
    int y_allPresetView;
    int width_allPresetView;
    int height_allPresetView;
    
    bool loadComplete;
}

@synthesize headerView;
@synthesize headerLabel;
@synthesize showCurrentSceneButton;

- (void)viewDidLoad {
    [super viewDidLoad];
    [super initControlBar];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self configureView];
    [self initVariables];
    [self setGroupDeviceButton];
    
    if (!loadComplete) {
        //[self loadData];
        loadComplete = true;
    }
    
    if (allPreset.count!=0) {
        NSLog(@"viewdidload refresh");
        for (int i=0; i<[allPreset count]; i++) {
            int savedAllPresetTag = [[[allPreset objectAtIndex:i] objectAtIndex:0] intValue];
            [self refresh:savedAllPresetTag index:i];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)configureView {
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    headerLabel.text = @"ALL PRESET";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    //parameter for groupView
    x_allPresetView = 0;
    y_allPresetView = 56;
    width_allPresetView = 830;
    height_allPresetView = 611;
    
    // init allPresetView
    allPresetView = [[UIView alloc] initWithFrame:CGRectMake( x_allPresetView, y_allPresetView,width_allPresetView, height_allPresetView)];
    allPresetView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    allPresetView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    //groupView.layer.cornerRadius = cornerRadius;
    allPresetView.layer.masksToBounds = YES;
    [self.view addSubview:allPresetView];
    
    // init scroll view
    myScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, allPresetView.bounds.size.width, allPresetView.bounds.size.height)];
    myScroll.contentSize = CGSizeMake(allPresetView.bounds.size.width, 1000);   //scroll view size
    myScroll.backgroundColor = [UIColor clearColor];
    myScroll.showsVerticalScrollIndicator = NO;    // to hide scroll indicators!
    myScroll.showsHorizontalScrollIndicator = YES; //by default, it shows!
    myScroll.scrollEnabled = YES;                 //say "NO" to disable scroll
    [allPresetView addSubview:myScroll];               //adding to parent view!
}

-(void)initVariables {
    allPresetDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    element = [[NSMutableArray alloc] init];
    allPreset = [[NSMutableArray alloc] init];
    loadComplete = false;
    
    //NSLog(@"%d",allPresetDelegate.currentScene);
    NSString * text = [NSString stringWithFormat:@"Current Scene : %d",allPresetDelegate.currentScene];
    [showCurrentSceneButton setTitle:text forState:UIControlStateNormal];
}

-(void)loadData {
    NSString * urlString = [NSString stringWithFormat:@"http://%@/lighttouch_api/allpreset.php",allPresetDelegate.host];
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSData *jsonData = [NSData dataWithContentsOfURL:url];
    
    if(jsonData != nil)
    {
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
        //NSLog(@"json=%@",json);
        if (error == nil){
            for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
                NSMutableDictionary *response= [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
                NSMutableArray * temp = [[NSMutableArray alloc] init];
                
                [temp addObject:[response valueForKey:@"preset_id"]];
                [temp addObject:[response valueForKey:@"name"]];
                [temp addObject:[[response valueForKey:@"device"] mutableCopy]];
                //NSLog(@"%@",temp);
                [allPreset addObject:[temp mutableCopy]];
            }
            NSLog(@"allPresetFromAPI - %@",allPreset);
        }
    }
}

-(void)setGroupDeviceButton {
    int column = 7;
    int row = 8;
    int x_allPresetButton = 5;
    int y_allPresetButton = 5;
    int width_allPresetButton = 118-x_allPresetButton;
    int height_allPresetButton = 118-y_allPresetButton;
    for (int i=0; i<row; i++) {
        for (int j=0; j<column; j++) {
            [self createGroupButton:myScroll
                              title:@""
                                tag:(i*column)+j+1
                                  x:x_allPresetButton+((width_allPresetButton+x_allPresetButton)*j)
                                  y:y_allPresetButton+((height_allPresetButton+y_allPresetButton)*i)
                                  w:width_allPresetButton
                                  h:height_allPresetButton
                        buttonColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]
                        shadowColor:[UIColor colorWithRed:0.171 green:0.21 blue:0.237 alpha:1]
                       shadowHeight:3.0f
                         titleColor:[UIColor cloudsColor]
                           selector:NSStringFromSelector(@selector(showAlertView:))
                               font:[UIFont flatFontOfSize:16]];
        }
    }
}

// show alertView
-(void)showAlertView:(id)sender {
    long tag = (long)((FUIButton *)sender).tag;
    if (allPresetDelegate.storeState && allPresetDelegate.selected.count!=0) {
        FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Name"
                                                              message:@"Insert group name"
                                                             delegate:nil
                                                    cancelButtonTitle:@"Cancel"
                                                    otherButtonTitles:@"OK", nil];
        alertView.alertViewStyle = FUIAlertViewStylePlainTextInput;
        [@[[alertView textFieldAtIndex:0]] enumerateObjectsUsingBlock:^(FUITextField *textField, NSUInteger idx, BOOL *stop) {
            [textField setTextFieldColor:[UIColor cloudsColor]];
            [textField setBorderColor:[UIColor asbestosColor]];
            [textField setCornerRadius:4];
            [textField setFont:[UIFont flatFontOfSize:14]];
            [textField setTextColor:[UIColor midnightBlueColor]];
        }];
        [[alertView textFieldAtIndex:0] setPlaceholder:@"Text here!"];
        
        alertView.delegate = self;
        alertView.tag = tag;
        alertView.titleLabel.textColor = [UIColor cloudsColor];
        alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
        alertView.messageLabel.textColor = [UIColor cloudsColor];
        alertView.messageLabel.font = [UIFont flatFontOfSize:14];
        alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
        alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
        //alertView.alertContainer.layer.cornerRadius = cornerRadius;
        alertView.defaultButtonColor = [UIColor cloudsColor];
        alertView.defaultButtonShadowColor = [UIColor asbestosColor];
        alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
        alertView.defaultButtonTitleColor = [UIColor asbestosColor];
        [alertView show];
    }
    else if (!allPresetDelegate.storeState){
        if ([allPreset count]!=0) {
            
            if (allPresetDelegate.tagAllPreset!=tag) {
                allPresetDelegate.countPressAllPreset = 1;
                allPresetDelegate.tagAllPreset = tag;
                [allPresetDelegate.selected removeAllObjects];
                NSLog(@"press different button");
            }
            if (allPresetDelegate.countPressAllPreset==1 && allPresetDelegate.tagAllPreset==tag) {
                for (int i=0; i<[allPreset count]; i++) {
                    int numberAllPreset = [[[allPreset objectAtIndex:i] objectAtIndex:0] intValue];
                    if (tag==numberAllPreset) {
                        NSLog(@"tagAllPreset==tag, count=%d",allPresetDelegate.countPressAllPreset);
                        NSMutableArray * allPresetGroupOfDevice = [[NSMutableArray alloc] initWithArray:[[allPreset objectAtIndex:i] objectAtIndex:2]];
                        allPresetDelegate.selected = [allPresetGroupOfDevice mutableCopy];
                        NSLog(@"one press allpreset, selected=%@",allPresetDelegate.selected);
                        allPresetDelegate.countPressAllPreset = 2;
                        NSLog(@"ueet %d",allPresetDelegate.countPressAllPreset);
                        [self refresh:numberAllPreset index:i];
                    }
                    else {
                        [self refresh:numberAllPreset index:i];
                    }
                }
            }
            else if (allPresetDelegate.countPressAllPreset==2 && allPresetDelegate.tagAllPreset==tag) {
                long allPresetID = tag;
                // create JSON form
                NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
                [test setObject:[NSNumber numberWithLong:allPresetID] forKey:@"preset_id"];
                [allPresetDelegate toString:[test mutableCopy] thatView:@"allpreset" action:@"select_preset/"]; // send JSON form
                for (int i=0; i<[allPreset count]; i++) {
                    int savedAllPresetTag = [[[allPreset objectAtIndex:i] objectAtIndex:0] intValue];
                    [self refresh:savedAllPresetTag index:i];
                }
                allPresetDelegate.countPressAllPreset = 0;
                allPresetDelegate.tagAllPreset = 0;
            }
            else if (allPresetDelegate.countPressAllPreset==3 && allPresetDelegate.tagAllPreset==tag) {
                allPresetDelegate.countPressAllPreset = 0;
                allPresetDelegate.tagAllPreset = 0;
            }
        }
        else {
            NSLog(@"don't have data");
        }
    }
}

- (void)alertView:(FUIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString * savedAllPresetName = @"";
    if (buttonIndex==1) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        savedAllPresetName = textfield.text;      // name of all preset
        //NSLog(@"group name=%@",savedAllPresetName);
        bool same = false;
        int sameIndex = 0;
        [element addObject:[NSNumber numberWithLong:(long)alertView.tag]];
        [element addObject:savedAllPresetName];
        [element addObject:[allPresetDelegate.selected mutableCopy]];  // set value from device into element
        if ([allPreset count]!=0) {
            for (int i=0; i<[allPreset count]; i++) {
                int numberOfGroupDevice = [[[allPreset objectAtIndex:i] objectAtIndex:0] intValue];
                if (alertView.tag==numberOfGroupDevice) {
                    //NSLog(@"tag=%ld,already have=%d", tag,numberOfGroupDevice);
                    same = true;
                    sameIndex = i;
                }
            }
            if (!same) {
                [allPreset addObject:[element mutableCopy]];
                NSLog(@"ADD save group done %@",allPreset);
                same = false;
            }
            else {
                [allPreset replaceObjectAtIndex:sameIndex withObject:[element mutableCopy]];
                NSLog(@"REPLACE save group done %@",allPreset);
            }
        }
        else {
            [allPreset addObject:[element mutableCopy]];
            NSLog(@"EMPTY_ADD save group done %@",allPreset);
        }
        
        // create JSON form
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        NSMutableDictionary * dictEachDevice = [[NSMutableDictionary alloc] init];
        NSMutableArray *groupDevice = [[NSMutableArray alloc] init];
        [test setObject:[element objectAtIndex:0] forKey:@"preset_id"];
        [test setObject:[element objectAtIndex:1] forKey:@"preset_name"];
        for (int i=0; i<[[element objectAtIndex:2] count]; i++) {
            //int deviceIndex = [[[element objectAtIndex:2] objectAtIndex:i] intValue]-1;
            [dictEachDevice setObject:[[element objectAtIndex:2] objectAtIndex:i] forKey:@"device_id"];
            /*
            for (int j=3; j<[[allPresetDataClass.device objectAtIndex:deviceIndex] count]; j++) {
                NSNumber * value =[[allPresetDataClass.device objectAtIndex:deviceIndex] objectAtIndex:j];
                NSString * key = [allPresetDataClass.nameCH objectAtIndex:j];
                [dictEachDevice setObject:value forKey:key];
            }
            */
            [groupDevice addObject:[dictEachDevice mutableCopy]];
        }
        [test setObject:[groupDevice mutableCopy] forKey:@"device"];
        // send JSON form
        [allPresetDelegate toString:[test mutableCopy] thatView:@"allpreset" action:@"add_preset/"];
        
        [element removeAllObjects];
        [super store];
    }
    
    for (int i=0; i<[allPreset count]; i++) {
        int savedAllPresetTag = [[[allPreset objectAtIndex:i] objectAtIndex:0] intValue];
        [self refresh:savedAllPresetTag index:i];
    }
}

-(void)refresh:(long)tag index:(int)index {
    FUIButton *b = (FUIButton *)[myScroll viewWithTag:tag];
    UILabel *nameLabel_hasselect = (UILabel *)(FUIButton *)[myScroll viewWithTag:10000+tag];
    
    // set name
    NSString *text = @"";
    text = [[[allPreset objectAtIndex:index] objectAtIndex:1] mutableCopy];
    nameLabel_hasselect.text = text;
    text = @"";
    
//    NSMutableSet *common = [NSMutableSet setWithArray:allPresetDataClass.selected];
//    NSMutableArray * tempGroupSelected = [[NSMutableArray alloc] init];
//    tempGroupSelected = [[[allPresetDataClass.savedAllPreset objectAtIndex:index] objectAtIndex:2] mutableCopy];
//    NSMutableSet * a =[NSMutableSet setWithArray:tempGroupSelected];
//    [common intersectSet:a];
    if (allPresetDelegate.countPressAllPreset==1 && allPresetDelegate.tagAllPreset==tag) {
        b.shadowColor = [UIColor colorWithRed:0.431 green:0.58 blue:0 alpha:1];
    }
    else if (allPresetDelegate.countPressAllPreset==2 && allPresetDelegate.tagAllPreset==tag) {
        b.buttonColor = [UIColor colorWithRed:0.631 green:0.78 blue:0.173 alpha:1];
    }
    else {
        b.buttonColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        b.shadowColor = [UIColor colorWithRed:0.171 green:0.21 blue:0.237 alpha:1];
    }
    
    /*
    // change buttonColor
    NSMutableSet *common = [NSMutableSet setWithArray:allPresetDataClass.selected];
    NSMutableArray * tempGroupSelected = [[NSMutableArray alloc] init];
    tempGroupSelected = [[[allPresetDataClass.savedAllPreset objectAtIndex:index] objectAtIndex:1] mutableCopy];
    NSLog(@"copy to tempGroupSelected ");
    NSMutableSet * a =[NSMutableSet setWithArray:tempGroupSelected];
    [common intersectSet:a];
    NSLog(@"tempCOUNT=%d",tempGroupSelected.count);
    NSLog(@"commonCOUNT=%d",common.count);
    if (common.count == tempGroupSelected.count) {
        b.buttonColor = [UIColor colorWithRed:0.631 green:0.78 blue:0.173 alpha:1];
        b.shadowColor = [UIColor colorWithRed:0.431 green:0.58 blue:0 alpha:1];
    }
    else {
        b.buttonColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        b.shadowColor = [UIColor colorWithRed:0.171 green:0.21 blue:0.237 alpha:1];
    }
     */
}

-(void)createGroupButton:(UIView *)view
                   title:(NSString *)title
                     tag:(int)tag
                       x:(int)x
                       y:(int)y
                       w:(int)w
                       h:(int)h
             buttonColor:(UIColor *)buttonColor
             shadowColor:(UIColor *)shadowColor
            shadowHeight:(float)shadowHeight
              titleColor:(UIColor *)titleColor
                selector:(NSString *)selector
                    font:(UIFont *)font {
    FUIButton *button = [[FUIButton alloc] initWithFrame:CGRectMake(x, y, w, h)];
    [button setTitle:title forState:UIControlStateNormal];
    button.tag = tag;
    button.buttonColor = buttonColor;
    button.shadowColor = shadowColor;
    button.shadowHeight = shadowHeight;
    //button.cornerRadius = 9.0f;
    NSString * btnName = [NSString stringWithFormat:@"%ld",(long)button.tag];
    [button setTitle:btnName forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = font;
    
    button.contentEdgeInsets = UIEdgeInsetsMake(5, 0, 0, 5);
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    button.contentVerticalAlignment = UIControlContentVerticalAlignmentTop;
    
    [button setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
    [button addTarget:self action:NSSelectorFromString(selector) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    
    UILabel * name = [[UILabel alloc] initWithFrame:CGRectMake(5, h/2-(25/2), w-5, 20)];
    name.text = @"";
    name.font = [UIFont flatFontOfSize:16];
    name.textColor = [UIColor cloudsColor];
    name.tag = 10000+tag;
    name.textAlignment = NSTextAlignmentCenter;
    [button addSubview:name];
}

@end
