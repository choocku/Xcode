//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "LayoutViewController.h"

@interface LayoutViewController ()

@end

@implementation LayoutViewController {
    int x_drawDevices;
    int y_drawDevices;
    int width_drawDevices;
    int height_drawDevices;
    DataClass *layoutClass;
    int checkDragged;
}

@synthesize headerView;
@synthesize dataView;
@synthesize headerLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    [super initControlBar];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    dataView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    headerLabel.text = @"LAYOUT";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    layoutClass = [DataClass sharedGlobalData];
    
    checkDragged = 0;
    
    [self initVariables];
    [self initButtonFromPatching];
    
    if (layoutClass.selected.count!=0) {
        NSLog(@"layout again");
        for (int i=0; i<layoutClass.selected.count; i++) {
            int selectedButtonTag = [[layoutClass.selected objectAtIndex:i] intValue];
            NSLog(@"selectButtonTAG=%d",selectedButtonTag);
            [self setHasSelectedButton:selectedButtonTag];
            //NSLog(@"selected=%d",selectedButton);
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initVariables {
    // parameter of drawDevices
    x_drawDevices = dataView.bounds.size.width/2;
    y_drawDevices = 50;
    width_drawDevices = 44;
    height_drawDevices = 44;
}

- (void)button:(id)sender withEvent:(UIEvent *)event {
    ((UIButton *)sender).selected = !((UIButton *)sender).selected;
    if (!checkDragged) {
        if(((UIButton *)sender).selected) {
            //NSLog(@"save %d",((UIButton *)sender).tag);
            [layoutClass.selected addObject:[NSNumber numberWithInt:(int)((UIButton *)sender).tag]];
            [[((UIButton *)sender) layer] setBorderColor:[UIColor sunflowerColor].CGColor];
        }
        else {
            //NSLog(@"remove %d",((UIButton *)sender).tag);
            [layoutClass.selected removeObjectIdenticalTo:[NSNumber numberWithInt:(int)((UIButton *)sender).tag]];
            [[((UIButton *)sender) layer] setBorderColor:[UIColor blackColor].CGColor];
        }
        NSLog(@"layoutClass.selected=%@",layoutClass.selected);
    }
    else {
        checkDragged = 0;
    }
}

-(void)setHasSelectedButton:(int)tag {
    UIButton * hasSelected = (UIButton *)[dataView viewWithTag:tag];
    NSLog(@"setHasSelectedButton tag=%ld,name=%@", (long)hasSelected.tag, hasSelected.titleLabel.text);
    [hasSelected setSelected:YES];
    if(hasSelected.selected) {
        //NSLog(@"setColor %d",hasSelected.tag);
        [[hasSelected layer] setBorderColor:[UIColor sunflowerColor].CGColor];
    }
}

- (void)wasDragged:(UIButton *)button withEvent:(UIEvent *)event
{
    checkDragged = 1;
    // get the touch
    UITouch *touch = [[event touchesForView:button] anyObject];
    
    // get delta
    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;
    
    // move button
    if( button.frame.origin.x<0 || button.center.x+button.frame.size.width/2>dataView.bounds.size.width ||
       button.frame.origin.y<0 || button.center.y+button.frame.size.height/2>dataView.bounds.size.height ) {
        button.center = CGPointMake(x_drawDevices+button.bounds.size.width/2,
                                    y_drawDevices+button.bounds.size.height/2);
    }
    else {
        button.center = CGPointMake(button.center.x + delta_x,
                                    button.center.y + delta_y);
    }
    [[layoutClass.layout objectAtIndex:button.tag-1] replaceObjectAtIndex:1 withObject:[NSNumber numberWithFloat:button.center.x]];
    [[layoutClass.layout objectAtIndex:button.tag-1] replaceObjectAtIndex:2 withObject:[NSNumber numberWithFloat:button.center.y]];
    [self sendValToServer:button.tag];
}

-(void)sendValToServer:(long)tag {
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    [test setObject:[[layoutClass.layout objectAtIndex:tag-1] objectAtIndex:0] forKey:@"device_id"];
    [test setObject:[[layoutClass.layout objectAtIndex:tag-1] objectAtIndex:1] forKey:@"xLayoutPosition"];
    [test setObject:[[layoutClass.layout objectAtIndex:tag-1] objectAtIndex:2] forKey:@"yLayoutPosition"];
    // send JSON form
    [layoutClass toString:[test mutableCopy] thatView:@"layout" action:@"update_layout/"];
}

-(void)initButtonFromPatching {
    //[self createClearButton];
    for (int i=0; i<layoutClass.device.count; i++) {
        NSString * get_id = [[layoutClass.device objectAtIndex:i] objectAtIndex:0];
        int deviceID = [get_id intValue];
        NSLog(@"initButtonFromPatching=%d,%@",deviceID,layoutClass.layout);
        //CGRect frame;
        NSString * get_type = [[layoutClass.device objectAtIndex:i] objectAtIndex:2];
        int xLayoutPosition = [[[layoutClass.layout objectAtIndex:i] objectAtIndex:1] intValue];
        int yLayoutPosition = [[[layoutClass.layout objectAtIndex:i] objectAtIndex:2] intValue];
        UIButton * button = [[UIButton alloc] initWithFrame:CGRectMake(xLayoutPosition-width_drawDevices/2, yLayoutPosition-height_drawDevices/2, width_drawDevices, height_drawDevices)];
        if ([get_type isEqual:[layoutClass.typeOfLight objectAtIndex:0]]) {
            [button setBackgroundColor:[UIColor colorWithRed:0.631 green:0.78 blue:0.173 alpha:1]];
        }
        else if ([get_type isEqual:[layoutClass.typeOfLight objectAtIndex:1]]) {
            [button setBackgroundColor:[UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1]];
        }
        else if ([get_type isEqual:[layoutClass.typeOfLight objectAtIndex:2]]) {
            [button setBackgroundColor:[UIColor colorWithRed:1 green:0.29 blue:0.165 alpha:1]];
        }
        //button.layer.cornerRadius = cornerRadius;
        //button.layer.masksToBounds = YES;
        button.tag = deviceID;
        NSString * title = [NSString stringWithFormat:@"%d",deviceID];
        [button setTitle:title forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [[button layer] setBorderWidth:4.0f];
        [[button layer] setBorderColor:[UIColor blackColor].CGColor];
        [button addTarget:self action:@selector(button:withEvent:)
         forControlEvents:UIControlEventTouchUpInside];
        [button addTarget:self action:@selector(wasDragged:withEvent:)
         forControlEvents:UIControlEventTouchDragInside];
        [dataView addSubview:button];
    }
}

@end
