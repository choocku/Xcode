//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "CueListViewController.h"

@interface CueListViewController ()

@end

@implementation CueListViewController

@synthesize headerView;
@synthesize sceneView;
@synthesize cueListView;
@synthesize controlView;

@synthesize headerLabel;
@synthesize sceneHeaderLabel;
@synthesize numberLabel;
@synthesize nameLabel;
@synthesize trigLabel;
@synthesize trigTimeLabel;
@synthesize fadeLabel;
@synthesize delayLabel;

@synthesize addSceneButton;

@synthesize sceneTableView;
@synthesize cueListTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setPerformance];
}

-(void)viewDidAppear:(BOOL)animated {
    [sceneTableView reloadData];
    [cueListTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setPerformance {
    // set view background
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    sceneView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    cueListView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    controlView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    // set header
    headerLabel.text = @"CUE LIST";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    // set scene header
    sceneHeaderLabel.text = @"SCENE";
    sceneHeaderLabel.textColor = [UIColor whiteColor];
    
    // set cue list header
    numberLabel.text = @"NUMBER";
    numberLabel.textColor = [UIColor whiteColor];
    nameLabel.text = @"NAME";
    nameLabel.textColor = [UIColor whiteColor];
    trigLabel.text = @"TRIG";
    trigLabel.textColor = [UIColor whiteColor];
    trigTimeLabel.text = @"TRIG TIME";
    trigTimeLabel.textColor = [UIColor whiteColor];
    fadeLabel.text = @"FADE";
    fadeLabel.textColor = [UIColor whiteColor];
    delayLabel.text = @"DELAY";
    delayLabel.textColor = [UIColor whiteColor];
    
    // set table style
    sceneTableView.backgroundColor = [UIColor clearColor];
    sceneTableView.separatorColor = [UIColor clearColor];
    sceneTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    sceneTableView.rowHeight = 96;
    
    // set cuelist table style
    cueListTableView.backgroundColor = [UIColor clearColor];
    cueListTableView.separatorColor = [UIColor clearColor];
    cueListTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    cueListTableView.rowHeight = 50;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == sceneTableView) {
        return 3;
    }
    else if (tableView == cueListTableView) {
        return 1;
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"sceneCell";
    static NSString * cellIdentifier2 = @"cueListCell";
    UITableViewCell *cell;
    if (tableView == sceneTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
        cell.backgroundColor = [UIColor clearColor];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [self showScene:cell indexPath:indexPath];
        return cell;
    }
    else if (tableView == cueListTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier2 forIndexPath:indexPath];
        cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier2];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [self showData:cell indexPath:indexPath];
        return cell;
    }
    return 0;
}

-(void)showScene:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UIButton * button1 = (UIButton *)[cell viewWithTag:1];
    UILabel * label1 = (UILabel *)(UIButton *)[cell viewWithTag:11];
    
    [button1 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    [button1 setTitle:[NSString stringWithFormat:@"%ld",(long)indexPath.row] forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button1.titleLabel.textAlignment = NSTextAlignmentCenter;
    
    label1.text = @"Name";
    label1.textColor = [UIColor whiteColor];
    label1.textAlignment = NSTextAlignmentCenter;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    
}

@end
