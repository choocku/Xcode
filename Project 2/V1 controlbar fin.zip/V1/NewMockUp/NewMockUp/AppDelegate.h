//
//  AppDelegate.h
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncUdpSocket.h"
#import "DataClass.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate> {
    long tag;
    AsyncUdpSocket *udpSocket;
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) NSString * page;

-(void)sendUDP:(NSString *)msg;

@end

