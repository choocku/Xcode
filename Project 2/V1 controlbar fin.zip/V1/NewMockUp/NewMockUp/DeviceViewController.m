//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "DeviceViewController.h"

@interface DeviceViewController ()

@end

@implementation DeviceViewController {
    DataClass *deviceClass;
}

@synthesize headerView;
@synthesize dataView;
@synthesize headerLabel;
@synthesize deviceTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    [super initControlBar];
    // Do any additional setup after loading the view, typically from a nib.
    deviceClass = [DataClass sharedGlobalData];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    dataView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    headerLabel.text = @"DEVICE";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    // set table style
    deviceTableView.backgroundColor = [UIColor clearColor];
    deviceTableView.separatorColor = [UIColor clearColor];
    deviceTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
}

-(void)viewDidAppear:(BOOL)animated {
    [deviceTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 5;
}

/*
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}
*/

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"MyCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    cell.backgroundColor = [UIColor clearColor];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    [self showData:cell indexPath:indexPath];
    
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    //** set BG color **//
    UIButton * button1 = (UIButton *)[cell viewWithTag:1];
    UIButton * button2 = (UIButton *)[cell viewWithTag:2];
    UIButton * button3 = (UIButton *)[cell viewWithTag:3];
    UIButton * button4 = (UIButton *)[cell viewWithTag:4];
    UIButton * button5 = (UIButton *)[cell viewWithTag:5];
    UIButton * button6 = (UIButton *)[cell viewWithTag:6];
    
    [button1 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    [button2 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    [button3 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    [button4 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    [button5 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    [button6 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];

    [button1 setTitle:[NSString stringWithFormat:@"%ld%ld",(long)indexPath.row,(long)button1.tag] forState:UIControlStateNormal];
    [button2 setTitle:[NSString stringWithFormat:@"%ld%ld",(long)indexPath.row,(long)button2.tag] forState:UIControlStateNormal];
    [button3 setTitle:[NSString stringWithFormat:@"%ld%ld",(long)indexPath.row,(long)button3.tag] forState:UIControlStateNormal];
    [button4 setTitle:[NSString stringWithFormat:@"%ld%ld",(long)indexPath.row,(long)button4.tag] forState:UIControlStateNormal];
    [button5 setTitle:[NSString stringWithFormat:@"%ld%ld",(long)indexPath.row,(long)button5.tag] forState:UIControlStateNormal];
    [button6 setTitle:[NSString stringWithFormat:@"%ld%ld",(long)indexPath.row,(long)button6.tag] forState:UIControlStateNormal];
}

@end
