//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "CueListViewController.h"

@interface CueListViewController ()

@end

@implementation CueListViewController {
    AppDelegate * cueListDelegate;
    NSMutableArray * cueList;
    NSMutableArray * scene;
    UILongPressGestureRecognizer * longPress;
    long sceneIndexPathRow;
    long cueIndexPathRow;
    NSString * oldCueNumber;
}

@synthesize headerView;
@synthesize sceneView;
@synthesize cueListView;
@synthesize controlView;

@synthesize headerLabel;
@synthesize sceneHeaderLabel;
@synthesize numberLabel;
@synthesize nameLabel;
@synthesize trigLabel;
@synthesize trigTimeLabel;
@synthesize fadeLabel;
@synthesize delayLabel;

@synthesize addSceneButton;

@synthesize sceneTableView;
@synthesize cueListTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setVariable];
    [self setPerformance];
    [sceneTableView reloadData];
    [cueListTableView reloadData];
    if (cueListDelegate.addingCue) {
        [self addCue];
    }
}

-(void)viewDidAppear:(BOOL)animated {
    //[self viewDidLoad];
    //[sceneTableView reloadData];
    //[cueListTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setVariable {
    cueListDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    cueList = [[NSMutableArray alloc] init];
    scene = [[NSMutableArray alloc] init];
    NSMutableArray * scene1 = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:1],@"check", nil];
    [scene addObject:scene1];
    NSMutableArray * cue = [[NSMutableArray alloc] init];
    NSMutableArray * data = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:0],[NSNumber numberWithInt:1], @"", @"GO", @"", @"", @"", nil];
    [cue addObject:data];
    [cueList addObject:cue];
    [sceneTableView reloadData];
    [cueListTableView reloadData];
    //NSLog(@"cueList=%@",cueList);
}

-(void)setPerformance {
    // set view background
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    sceneView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    cueListView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    controlView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    // set header
    headerLabel.text = @"CUE LIST";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    // set scene header
    sceneHeaderLabel.text = @"SCENE";
    sceneHeaderLabel.textColor = [UIColor whiteColor];
    
    // set cue list header
    numberLabel.text = @"NUMBER";
    numberLabel.textColor = [UIColor whiteColor];
    nameLabel.text = @"NAME";
    nameLabel.textColor = [UIColor whiteColor];
    trigLabel.text = @"TRIG";
    trigLabel.textColor = [UIColor whiteColor];
    trigTimeLabel.text = @"TRIG TIME";
    trigTimeLabel.textColor = [UIColor whiteColor];
    fadeLabel.text = @"FADE";
    fadeLabel.textColor = [UIColor whiteColor];
    delayLabel.text = @"DELAY";
    delayLabel.textColor = [UIColor whiteColor];
    
    // set table style
    sceneTableView.backgroundColor = [UIColor clearColor];
    sceneTableView.separatorColor = [UIColor clearColor];
    sceneTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    sceneTableView.rowHeight = 96;
    
    // set cuelist table style
    cueListTableView.backgroundColor = [UIColor clearColor];
    cueListTableView.separatorColor = [UIColor clearColor];
    cueListTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    cueListTableView.rowHeight = 50;
}

-(void)addCue {
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Cue"
                          message:@"Insert cue number"
                          delegate:self
                          cancelButtonTitle:@"Cancel"
                          otherButtonTitles:@"OK",nil];
    alert.tag = 1000;
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField* tf = [alert textFieldAtIndex:0];
    tf.text = [NSString stringWithFormat:@"%d",[[cueList objectAtIndex:cueListDelegate.currentScene] count]+1];
    tf.keyboardType = UIKeyboardTypeNumberPad;
    [alert show];
    cueListDelegate.addingCue = false;
}

-(IBAction)scene:(id)sender {
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:sceneTableView];
    NSIndexPath *indexPath = [sceneTableView indexPathForRowAtPoint:buttonPosition];
    cueListDelegate.currentScene = indexPath.row;
    NSLog(@"row=%ld currentScene=%d",(long)indexPath.row, cueListDelegate.currentScene);
    [cueListTableView reloadData];
}

// show alertView
-(IBAction)sceneShowAlertView:(id)sender {
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:sceneTableView];
    NSIndexPath *indexPath = [sceneTableView indexPathForRowAtPoint:buttonPosition];
    sceneIndexPathRow = indexPath.row;
    
    // add data to array
    NSMutableArray * tempData = [[NSMutableArray alloc] init];
    NSNumber * sceneNumber = [NSNumber numberWithLong:[scene count]+1];  // scene number
    [tempData addObject:sceneNumber];
    [tempData addObject:@"Empty"];
    [scene addObject:tempData];
    NSMutableArray * temp = [[NSMutableArray alloc] init];
    [cueList addObject:temp];
    
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    [test setObject:[tempData objectAtIndex:0] forKey:@"scene_id"];
    [test setObject:[tempData objectAtIndex:1] forKey:@"scene_name"];
    
    // send JSON form
    [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"add_scene/"];
    
    [sceneTableView reloadData];
    //cueListDelegate.currentScene = [sceneNumber intValue]-1;
    NSLog(@"scene=%@,cueList=%@, currentScene=%d",scene, cueList, cueListDelegate.currentScene);
    [cueListTableView reloadData];
}

- (void)handleLongPressGestures:(UILongPressGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateBegan)
    {
        FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Name"
                                                              message:@"Insert Scene Name"
                                                             delegate:nil
                                                    cancelButtonTitle:@"Cancel"
                                                    otherButtonTitles:@"OK", nil];
        alertView.alertViewStyle = FUIAlertViewStylePlainTextInput;
        [@[[alertView textFieldAtIndex:0]] enumerateObjectsUsingBlock:^(FUITextField *textField, NSUInteger idx, BOOL *stop) {
            [textField setTextFieldColor:[UIColor cloudsColor]];
            [textField setBorderColor:[UIColor asbestosColor]];
            [textField setCornerRadius:4];
            [textField setFont:[UIFont flatFontOfSize:14]];
            [textField setTextColor:[UIColor midnightBlueColor]];
        }];
        [[alertView textFieldAtIndex:0] setPlaceholder:@"Text here!"];
        
        alertView.delegate = self;
        alertView.tag = 2000;
        alertView.titleLabel.textColor = [UIColor cloudsColor];
        alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
        alertView.messageLabel.textColor = [UIColor cloudsColor];
        alertView.messageLabel.font = [UIFont flatFontOfSize:14];
        alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
        alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
        //alertView.alertContainer.layer.cornerRadius = cornerRadius;
        alertView.defaultButtonColor = [UIColor cloudsColor];
        alertView.defaultButtonShadowColor = [UIColor asbestosColor];
        alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
        alertView.defaultButtonTitleColor = [UIColor asbestosColor];
        [alertView show];
        
        NSLog(@"show alert");
    }
}

- (void)alertView:(FUIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    // adding cue
    if (alertView.tag == 1000) {
        if (buttonIndex==1) {
            UITextField *textfield = [alertView textFieldAtIndex:0];
            cueListDelegate.cueNumber = [textfield.text floatValue];
            NSLog(@"%f",cueListDelegate.cueNumber);
            
            NSMutableArray * temp = [[NSMutableArray alloc] init];
            NSNumber * cueNumber = [NSNumber numberWithFloat:cueListDelegate.cueNumber];  // scene number
            [temp addObject:cueNumber]; // cueNumber
            [temp addObject:@""];       // name
            [temp addObject:@"GO"];     // Trig
            [temp addObject:@""];       // TrigTime
            [temp addObject:@""];       // Fade
            [temp addObject:@""];       // Delay
            [[cueList objectAtIndex:sceneIndexPathRow] addObject:temp];
            
            // create JSON form
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            [test setObject:[temp objectAtIndex:0] forKey:@"cue_number"];
            [test setObject:[temp objectAtIndex:1] forKey:@"cue_name"];
            [test setObject:[temp objectAtIndex:2] forKey:@"cue_Trig"];
            [test setObject:[temp objectAtIndex:3] forKey:@"cue_TrigTime"];
            [test setObject:[temp objectAtIndex:4] forKey:@"cue_fade"];
            [test setObject:[temp objectAtIndex:5] forKey:@"cue_delay"];
            
            // send JSON form
            [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"add_cue/"];
            
            [sceneTableView reloadData];
            [cueListTableView reloadData];
            NSLog(@"scene=%@,cueList=%@, currentScene=%d",scene, cueList, cueListDelegate.currentScene);
            
            cueListDelegate.countPressAllPreset = 2;
            //NSLog(@"countPressAllPreset=%d",cueListDelegate.countPressAllPreset);
        }
    }
    // set Scene Name
    else if (alertView.tag == 2000) {
        if (buttonIndex == 1) {
            NSString * savedSceneName = @"";
            UITextField *textfield = [alertView textFieldAtIndex:0];
            savedSceneName = textfield.text;      // scene name
            [[scene objectAtIndex:sceneIndexPathRow] replaceObjectAtIndex:1 withObject:savedSceneName];
            
            // create JSON form
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            [test setObject:[NSNumber numberWithInt:sceneIndexPathRow] forKey:@"scene_id"];
            [test setObject:savedSceneName forKey:@"scene_name"];
            
            // send JSON form
            [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"set_sceneName/"];
            
            [sceneTableView reloadData];
            //NSLog(@"scene=%@,cueList=%@, currentScene=%d",scene, cueList, cueListDelegate.currentScene);
            [cueListTableView reloadData];
        }
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == sceneTableView) {
        return [scene count];
    }
    else if (tableView == cueListTableView) {
        if (cueListDelegate.currentScene == -1) {
            return 0;
        }
        else {
            return [[cueList objectAtIndex:cueListDelegate.currentScene] count];
        }
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"sceneCell";
    static NSString * cellIdentifier2 = @"cueListCell";
    UITableViewCell *cell;
    if (tableView == sceneTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
        cell.backgroundColor = [UIColor clearColor];
        
        // add longPress to cell
        longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressGestures:)];
        longPress.minimumPressDuration = 1.0f;
        longPress.allowableMovement = 100.0f;
        [cell addGestureRecognizer:longPress];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [self showScene:cell indexPath:indexPath];
        return cell;
    }
    else if (tableView == cueListTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier2 forIndexPath:indexPath];
        cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier2];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [self showCue:cell indexPath:indexPath];
        return cell;
    }
    return 0;
}

-(void)showScene:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UIButton * button1 = (UIButton *)[cell viewWithTag:1];
    UILabel * label1 = (UILabel *)(UIButton *)[cell viewWithTag:11];
    
    [button1 setBackgroundColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]];
    NSNumber * sceneID = [[scene objectAtIndex:indexPath.row] objectAtIndex:0];
    NSString * btnTitle = [NSString stringWithFormat:@"%@",sceneID];
    [button1 setTitle:btnTitle forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button1.titleLabel.textAlignment = NSTextAlignmentCenter;
    
    NSString * btnText = [[scene objectAtIndex:indexPath.row] objectAtIndex:1];
    label1.text = btnText;
    label1.textColor = [UIColor whiteColor];
    label1.textAlignment = NSTextAlignmentCenter;
}

-(void)showCue:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    if (cueListDelegate.currentScene != -1) {
        UITextField * number = (UITextField *)[cell viewWithTag:1];
        UITextField * name = (UITextField *)[cell viewWithTag:2];
        UIButton * trig = (UIButton *)[cell viewWithTag:3];
        UITextField * trigTime = (UITextField *)[cell viewWithTag:4];
        UITextField * fade = (UITextField *)[cell viewWithTag:5];
        UITextField * delay = (UITextField *)[cell viewWithTag:6];
        
        NSString * numberValue = [NSString stringWithFormat:@"%@",[[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:0]];
        NSString * nameValue = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:1];
        NSString * trigTitle = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:2];
        NSString * trigTimeValue = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:3];
        NSString * fadeValue = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:4];
        NSString * delayValue = [[[cueList objectAtIndex:cueListDelegate.currentScene] objectAtIndex:indexPath.row] objectAtIndex:5];
        
        number.text = numberValue;
        name.text = nameValue;
        [trig setTitle:trigTitle forState:UIControlStateNormal];
        trigTime.text = trigTimeValue;
        fade.text = fadeValue;
        delay.text = delayValue;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

-(IBAction)testTF:(id)sender {
    UITextField * myTextField = (UITextField *)sender;
    NSString * text = myTextField.text;
    NSString * key = @"";
    
    // create JSON form
    NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
    if (myTextField.tag == 1) {
        key = @"set_cue_number";
        [test setObject:text forKey:@"old_number"];
    }
    else if (myTextField.tag == 2) {
        key = @"set_cue_name";
    }
    else if (myTextField.tag == 4) {
        key = @"set_cue_trigTime";
    }
    else if (myTextField.tag == 5) {
        key = @"set_cue_fade";
    }
    else if (myTextField.tag == 6) {
        key = @"set_cue_delay";
    }
    
    [test setObject:text forKey:key];
    
    // send JSON form
    [cueListDelegate toString:[test mutableCopy] thatView:@"cuelist" action:@"set_cue_attribute/"];
}

-(IBAction)trigAlertView:(id)sender {
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:cueListTableView];
    NSIndexPath *indexPath = [cueListTableView indexPathForRowAtPoint:buttonPosition];
    NSLog(@"row=%ld, trigButtonTag:%ld",(long)indexPath.row, (long)((UIButton *)sender).tag);
}

-(IBAction)sss:(id)sender {
    UITextField * myTextField = (UITextField *)sender;
    if (myTextField.tag==1) {
        oldCueNumber = myTextField.text;
        NSLog(@"oldCueNumber =%@",oldCueNumber);
    }
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:cueListTableView];
    NSIndexPath *indexPath = [cueListTableView indexPathForRowAtPoint:buttonPosition];
    cueIndexPathRow = indexPath.row;
    NSLog(@"row=%ld, myTextFieldTag:%ld",(long)indexPath.row, (long)myTextField.tag);
}

@end
