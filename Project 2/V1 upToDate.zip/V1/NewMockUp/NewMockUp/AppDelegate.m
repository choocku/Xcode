//
//  AppDelegate.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@synthesize host;
@synthesize selected;
@synthesize storeState;
@synthesize tagAllPreset;
@synthesize countPressAllPreset;
@synthesize clearState;
@synthesize arrayForControlBar;
@synthesize port;
@synthesize typeOfLight;
@synthesize numberChOfLight;
@synthesize currentScene;
@synthesize cueNumber;
@synthesize addingCue;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    host = @"192.168.106.53";
    port = 1024;
    selected = [[NSMutableArray alloc] init];
    storeState = false;
    addingCue = false;
    tagAllPreset = 0;      // all preset button tag
    countPressAllPreset = 1;   // status all preset
    clearState = 0;        // clear button status
    arrayForControlBar = [[NSMutableArray alloc] initWithObjects:
                          @"0",     // dim
                          @"127",   // pan
                          @"127",   // tilt
                          @"0",     // gobo
                          @"White", // color
                          @"0",     // iris
                          @"0",     // shutter
                          @"0",     // focus
                          @"0",     // zoom
                          @"0",     // effect
                          nil];
    typeOfLight = [[NSArray alloc] initWithObjects:@"Studio250", @"Cyberlight", @"Xspot", nil];    // light library
    numberChOfLight = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:18],[NSNumber numberWithInt:20],[NSNumber numberWithInt:38],nil];   // channel quantity
    currentScene = 0;
    cueNumber = 1;
    
    // Override point for customization after application launch.
    udpSocket = [[AsyncUdpSocket alloc] initWithDelegate:self];
    NSError *error = nil;
    if (![udpSocket bindToPort:0 error:&error])
    {
        NSLog(@"Error binding: %@", error);
        //return;
    }
    [udpSocket receiveWithTimeout:-1 tag:0];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

-(void)sendUDP:(NSString *)msg{
    if ([host length] == 0)
    {
        NSLog(@"Address required");
        return;
    }
    
    if (port <= 0 || port > 65535)
    {
        NSLog(@"Valid port required");
        return;
    }
    
    if ([msg length] == 0)
    {
        NSLog(@"Message required");
        return;
    }
    NSData *data = [msg dataUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"msg=%@",msg);
    [udpSocket sendData:data toHost:host port:port withTimeout:-1 tag:tag];
    tag++;
}

-(void)toString:(NSMutableArray *)theArray
       thatView:(NSString *)thatView
         action:(NSString *)action {
    AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
    //NSMutableDictionary *theBigDictionary = [[NSMutableDictionary alloc] init];
    //theBigDictionary = [NSMutableDictionary dictionaryWithObject:theArray forKey:thatView];
    
    //NSLog(@"theBigDictionary=%@",theBigDictionary);
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:theArray
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        NSString *jsonString=@"";
        NSString *jsonString2 = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        jsonString = [jsonString stringByAppendingFormat:@"%@%@",action,jsonString2];
        //NSLog(@"jsonString=%@",jsonString);
        [delegate sendUDP:jsonString];
    }
}

-(void)toStringDelete:(NSMutableDictionary *)toDel
             thatView:(NSString *)thatView
               action:(NSString *)action {
    AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
    //NSMutableDictionary *theBigDictionary = [[NSMutableDictionary alloc] init];
    //theBigDictionary = [NSMutableDictionary dictionaryWithObject:stringToDel forKey:thatView];
    
    //NSLog(@"theBigDictionary=%@",theBigDictionary);
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:toDel
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        NSString *jsonString=@"";
        NSString *jsonString2 = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        jsonString = [jsonString stringByAppendingFormat:@"%@%@",action,jsonString2];
        //NSLog(@"jsonString=%@",jsonString);
        [delegate sendUDP:jsonString];
    }
}

-(void)setData:(int)index
            ch:(int)ch
           obj:(NSString *)obj{
    //NSMutableArray * temp = [[NSMutableArray alloc] init];
    //temp = [arrayForControlBar mutableCopy];
    [arrayForControlBar replaceObjectAtIndex:ch withObject:obj];
    //arrayForControlBar = [temp mutableCopy];
    //[temp removeAllObjects];
}

-(void)updatedAndSent:(int)ch
            parameter:(NSString *)parameter
                  val:(NSString *)val {
    for (int i=0; i<[selected count]; i++) {
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        int deviceIndex = [[selected objectAtIndex:i] intValue]-1;
        //int patchIndex = [[[arrayForControlBar objectAtIndex:deviceIndex] objectAtIndex:0] intValue]-1;
        
         //if( deviceIndex==patchIndex ) {
         NSNumber * deviceID = [NSNumber numberWithInt:deviceIndex+1];
         //NSNumber * value = [NSNumber numberWithInt:[val intValue]];
         [test setObject:deviceID forKey:@"device_id"];
         [test setObject:parameter forKey:@"parameter"];
         [test setObject:val forKey:@"value"];
    
         [self setData:deviceIndex ch:ch obj:val];
         //}
        
        [self toString:[test mutableCopy] thatView:@"controlbar" action:@"control/"];
    }
}

@end
