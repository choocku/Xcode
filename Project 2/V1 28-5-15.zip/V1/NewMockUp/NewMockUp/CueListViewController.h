//
//  ViewController.h
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "FlatUIKit.h"

@interface CueListViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,FUIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *headerView;
@property (weak, nonatomic) IBOutlet UIView *sceneView;
@property (weak, nonatomic) IBOutlet UIView *cueListView;

@property (weak, nonatomic) IBOutlet UIView *controlView;
@property (weak, nonatomic) IBOutlet UILabel *cueLabel;
@property (weak, nonatomic) IBOutlet UIButton *addCueButton;
@property (weak, nonatomic) IBOutlet UIScrollView *cueScrollView;
@property (weak, nonatomic) IBOutlet UIView *cueView;

@property (weak, nonatomic) IBOutlet UILabel *headerLabel;
@property (weak, nonatomic) IBOutlet UILabel *sceneHeaderLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *trigLabel;
@property (weak, nonatomic) IBOutlet UILabel *trigTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *fadeLabel;
@property (weak, nonatomic) IBOutlet UILabel *delayLabel;

@property (weak, nonatomic) IBOutlet UIButton *addSceneButton;

@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UIButton *playButton;
@property (weak, nonatomic) IBOutlet UIButton *stopButton;
@property (weak, nonatomic) IBOutlet UIButton *forwardButton;

@property (weak, nonatomic) IBOutlet UITableView *sceneTableView;
@property (weak, nonatomic) IBOutlet UITableView *sequenceTableView;

-(IBAction)addSceneButton:(id)sender;
-(IBAction)trigAlertView:(id)sender;

-(IBAction)changeTextEnded:(id)sender;
-(IBAction)changeTextBegin:(id)sender;
-(IBAction)addCueButton:(id)sender;

-(IBAction)playButton:(id)sender;
-(IBAction)backButton:(id)sender;
-(IBAction)stopButton:(id)sender;
-(IBAction)forwardButton:(id)sender;
-(IBAction)pauseButton:(id)sender;

@end

