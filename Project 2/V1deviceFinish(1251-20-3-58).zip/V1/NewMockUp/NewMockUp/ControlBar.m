//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "ControlBar.h"


@interface ControlBar () {
    UIPopoverController *popOverController;
}

@end

@implementation ControlBar {
    // create device data
    NSMutableArray *temp;
    NSString * message;
    
    // control bar view
    UIView *containerView;
    float cornerRadius;
    
    // dimmer button
    TBCircularSlider *dimmer;
    UITextField * dimmerTextField;
    
    // position button
    UIView * positionView;
    FUIButton *panTiltButton;
    UIBezierPath *path;
    UIBezierPath *path2;
    UITextField * pan_text;
    UITextField * tilt_text;
    
    // focus button
    TBCircularSlider *focusSlider;
    TBCircularSlider *zoomSlider;
    UITextField * focusTextField;
    UITextField * zoomTextField;
    
    AppDelegate * delegateInControlBar;
    
    DataClass *controlBarClass;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    delegateInControlBar = [[UIApplication sharedApplication] delegate];
    cornerRadius = 9.0f;
    message = @"";
    temp = [[NSMutableArray alloc] init];
    
    controlBarClass = [DataClass sharedGlobalData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initControlBar {
    // init container View
    containerView = [[UIView alloc] initWithFrame:CGRectMake( 0, 667, 830, 53)];
    containerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    containerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    containerView.layer.masksToBounds = YES;
    [self.view addSubview:containerView];
    [self controlButton];
}

-(void)controlButton {
    int x_controlButton = 0;
    int y_controlButton = 0;
    int width_controlButton = 82;
    int height_controlButton = 53;
    
    UIColor * storeButtonColor = [[UIColor alloc] init];
    UIColor * storeButtonShadowColor = [[UIColor alloc] init];
    
    [self createButton:containerView
                 title:@"Dimmer"
                   tag:1000
                     x:x_controlButton+((width_controlButton+1)*0)
                     y:y_controlButton
                     w:width_controlButton
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(showPopover:))
                  font:[UIFont boldFlatFontOfSize:16]];
    [self createButton:containerView
                 title:@"Position"
                   tag:1001
                     x:x_controlButton+((width_controlButton+1)*1)
                     y:y_controlButton
                     w:width_controlButton
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(showPopover:))
                  font:[UIFont boldFlatFontOfSize:16]];
    [self createButton:containerView
                 title:@"Gobo"
                   tag:1002
                     x:x_controlButton+((width_controlButton+1)*2)
                     y:y_controlButton
                     w:width_controlButton
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(showPopover:))
                  font:[UIFont boldFlatFontOfSize:16]];
    [self createButton:containerView
                 title:@"Color"
                   tag:1003
                     x:x_controlButton+((width_controlButton+1)*3)
                     y:y_controlButton
                     w:width_controlButton
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(showPopover:))
                  font:[UIFont boldFlatFontOfSize:16]];
    [self createButton:containerView
                 title:@"Beam"
                   tag:1004
                     x:x_controlButton+((width_controlButton+1)*4)
                     y:y_controlButton
                     w:width_controlButton
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(showPopover:))
                  font:[UIFont boldFlatFontOfSize:16]];
    [self createButton:containerView
                 title:@"Focus"
                   tag:1005
                     x:x_controlButton+((width_controlButton+1)*5)
                     y:y_controlButton
                     w:width_controlButton
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(showPopover:))
                  font:[UIFont boldFlatFontOfSize:16]];
    [self createButton:containerView
                 title:@"Effect"
                   tag:1006
                     x:x_controlButton+((width_controlButton+1)*6)
                     y:y_controlButton
                     w:width_controlButton
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(showPopover:))
                  font:[UIFont boldFlatFontOfSize:16]];
    
    if (controlBarClass.storeState) {
        storeButtonColor = [UIColor sunflowerColor];
        storeButtonShadowColor = [UIColor orangeColor];
    }
    else {
        storeButtonColor = [UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1];
        storeButtonShadowColor = [UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1];
    }
    [self createButton:containerView
                 title:@"Store"
                   tag:1007
                     x:x_controlButton+((width_controlButton+1)*7)+16
                     y:y_controlButton
                     w:width_controlButton-5
                     h:height_controlButton
           buttonColor:storeButtonColor
           shadowColor:storeButtonShadowColor
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(store))
                  font:[UIFont boldFlatFontOfSize:16]];
    
    [self createButton:containerView
                 title:@"Clear"
                   tag:1008
                     x:x_controlButton+((width_controlButton+1)*8)+11
                     y:y_controlButton
                     w:width_controlButton-5
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]  //MING
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(clear:))
                  font:[UIFont boldFlatFontOfSize:16]];
    [self createButton:containerView
                 title:@"Undo"
                   tag:1009
                     x:x_controlButton+((width_controlButton+1)*9)+6
                     y:y_controlButton
                     w:width_controlButton-5
                     h:height_controlButton
           buttonColor:[UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1]  //MING
           shadowColor:[UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1]
          shadowHeight:4.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(undo:))
                  font:[UIFont boldFlatFontOfSize:16]];
}

- (void)showPopover:(id)sender {
    FUIButton *button = (FUIButton *)sender;
    long highlight = (long)((FUIButton *)sender).tag;
    
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view.backgroundColor = [UIColor clearColor];
    
    //vc.title = ((UIButton *)sender).titleLabel.text;
    
    popOverController = [[UIPopoverController alloc] initWithContentViewController:vc];
    [popOverController configureFlatPopoverWithBackgroundColor:[UIColor colorWithRed:0.737 green:0.776 blue:0.8 alpha:0.8] cornerRadius:9.0];
    popOverController.delegate = self;
    
    [popOverController presentPopoverFromRect:button.frame inView:containerView permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    
    @try {
        for (int i=1000; i<1007; i++) {
            FUIButton * hl = (FUIButton *)[((FUIButton *)sender).superview viewWithTag:i];
            if (highlight==hl.tag) {
                hl.shadowColor = [UIColor sunflowerColor];
                [hl setSelected:YES];
            }
            else {
                hl.shadowColor = [UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1];
                [hl setSelected:NO];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"you're not control anything");
    }
    
    if ([((FUIButton *)sender).titleLabel.text isEqualToString:@"Dimmer"]) {
        vc.preferredContentSize = CGSizeMake(240, 250);     //fit for one TB
        [self initDimmer:vc];
    }
    else if ([((FUIButton *)sender).titleLabel.text isEqualToString:@"Position"]) {
        vc.preferredContentSize = CGSizeMake(400, 345);
        [self initPanTilt:vc];
    }
    else if ([((FUIButton *)sender).titleLabel.text isEqualToString:@"Gobo"]) {
        vc.preferredContentSize = CGSizeMake(320, 200);
        [self gobo:vc];
    }
    else if ([((FUIButton *)sender).titleLabel.text isEqualToString:@"Color"]) {
        vc.preferredContentSize = CGSizeMake(540, 120);
        [self initLightColor:vc];
    }
    else if ([((FUIButton *)sender).titleLabel.text isEqualToString:@"Beam"]) {
        vc.preferredContentSize = CGSizeMake(540, 120);
        [self initIris:vc];
        [self initShutter:vc];
    }
    else if ([((FUIButton *)sender).titleLabel.text isEqualToString:@"Focus"]) {
        vc.preferredContentSize = CGSizeMake(480, 240);
        [self initFocus:vc];
        [self initZoom:vc];
    }
    else if ([((FUIButton *)sender).titleLabel.text isEqualToString:@"Effect"]) {
        vc.preferredContentSize = CGSizeMake(320, 240);
        [self effectOffset:vc];
    }
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(vc.preferredContentSize.width/2-40, 0, 80, 80)];
    title.text = ((FUIButton *)sender).titleLabel.text;
    title.textAlignment = NSTextAlignmentCenter;
    title.font = [UIFont boldFlatFontOfSize:20.0];
    [vc.view addSubview:title];
    
    
    FUIButton * clearButton = [[FUIButton alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [clearButton addTarget:self action:@selector(clearColor:) forControlEvents:UIControlEventTouchUpInside];
    clearButton.backgroundColor = [UIColor clearColor];
    [self.view addSubview:clearButton];
}

-(void)clearColor:(id)sender {
    NSLog(@"clearButton %ld",(long)((FUIButton *)sender).tag);
    [((FUIButton *)sender) removeFromSuperview];
    @try {
        for (int i=1000; i<1007; i++) {
            FUIButton * hl = (FUIButton *)[containerView viewWithTag:i];
            hl.shadowColor = [UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"you're not control anything");
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////// Dimmer //////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

-(void)initDimmer:(UIViewController *)vc {
    //Create the Circular Slider
    dimmer = [TBCircularSlider alloc];
    dimmer.val = [[controlBarClass.arrayForControlBar objectAtIndex:0] intValue];
    dimmer = [dimmer initWithFrame:CGRectMake(0, 10, TB_SLIDER_SIZE, TB_SLIDER_SIZE)];
    //dimmer = [[TBCircularSlider alloc] initWithFrame:CGRectMake(0, 10, TB_SLIDER_SIZE, TB_SLIDER_SIZE)];
    
    //Define Target-Action behaviour
    [dimmer addTarget:self action:@selector(dimValue:) forControlEvents:UIControlEventValueChanged];
    [vc.view addSubview:dimmer];
    
    //Define the Font
    UIFont *font = [UIFont fontWithName:@"Lato-Bold" size:TB_FONTSIZE];
    NSDictionary *attributes = @{NSFontAttributeName:font};
    //Calculate font size needed to display 3 numbers
    NSString *str = @"000";
    CGSize fontSize = [str sizeWithAttributes:attributes];
    
    //Using a TextField area we can easily modify the control to get user input from this field
    dimmerTextField = [[UITextField alloc]initWithFrame:CGRectMake((dimmer.frame.size.width  - fontSize.width)/2, (dimmer.frame.size.height - fontSize.height) /2, fontSize.width, fontSize.height)];
    dimmerTextField.backgroundColor = [UIColor clearColor];
    dimmerTextField.textColor = [UIColor cloudsColor];
    dimmerTextField.textAlignment = NSTextAlignmentCenter;
    dimmerTextField.font = font;
    dimmerTextField.text = [NSString stringWithFormat:@"%d",255*dimmer.angle/360];
    [dimmerTextField addTarget:self action:@selector(dimTextField) forControlEvents:UIControlEventEditingChanged];
    dimmerTextField.enabled = YES;
    [dimmer addSubview:dimmerTextField];
    
    UILabel *onoff_label = [[UILabel alloc] initWithFrame:CGRectMake(40, 210, 80, 35)];
    onoff_label.text = @"Light";
    onoff_label.textColor = [UIColor midnightBlueColor];
    onoff_label.font = [UIFont boldFlatFontOfSize:18];
    onoff_label.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:onoff_label];
    
    FUISwitch *onoff = [[FUISwitch alloc] initWithFrame: CGRectMake(120, 210, 80, 35)];
    if ([[controlBarClass.arrayForControlBar objectAtIndex:1] isEqualToString:@"on"]) {
        onoff.on = YES;
    }
    else {
        onoff.on = NO;
    }
    onoff.onColor = [UIColor peterRiverColor];
    onoff.offColor = [UIColor cloudsColor];
    onoff.onBackgroundColor = [UIColor midnightBlueColor];
    onoff.offBackgroundColor = [UIColor silverColor];
    onoff.offLabel.font = [UIFont boldFlatFontOfSize:14];
    onoff.onLabel.font = [UIFont boldFlatFontOfSize:14];
    [onoff addTarget: self action: @selector(changeSwitch:) forControlEvents:UIControlEventValueChanged];
    [vc.view addSubview:onoff];
}

/** This function is called when Circular slider value changes **/
-(void)dimValue:(TBCircularSlider*)slider{
    //NSLog(@"Slider Value %d",255*slider.angle/360);
    NSString * val = [NSString stringWithFormat:@"%d",255*slider.angle/360];
    dimmerTextField.text = val;
    [controlBarClass updatedAndSent:3 val:val];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:0 withObject:val]; // update arrayForControlBar
    NSLog(@"dimmer=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

-(void) dimTextField {
    int angleFromTextField = [dimmerTextField.text intValue];
    dimmer.angle = 360*(angleFromTextField+1)/255;
    [dimmer setNeedsDisplay];
    [controlBarClass updatedAndSent:3 val:dimmerTextField.text];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:0 withObject:dimmerTextField.text]; // update arrayForControlBar
    NSLog(@"dimmer=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

- (void)changeSwitch:(id)sender{
    if([sender isOn]){
        // Execute any code when the switch is ON
        NSLog(@"Switch is ON");
        NSString * val = [NSString stringWithFormat:@"%d",255];
        [controlBarClass updatedAndSent:3 val:val];
        [controlBarClass.arrayForControlBar replaceObjectAtIndex:1 withObject:@"on"];   // update arrayForControlBar
        NSLog(@"LightON=%@",controlBarClass.device);
    } else{
        // Execute any code when the switch is OFF
        NSLog(@"Switch is OFF");
        NSString * val = [NSString stringWithFormat:@"%d",0];
        [controlBarClass updatedAndSent:3 val:val];
        [controlBarClass.arrayForControlBar replaceObjectAtIndex:1 withObject:@"off"];  // update arrayForControlBar
        NSLog(@"LightOFF=%@",controlBarClass.device);
    }
    NSLog(@"light=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////// Pan Tilt ////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

-(void)initPanTilt:(UIViewController *)vc {
    positionView = [[UIView alloc] initWithFrame:CGRectMake(20, 60, 255, 255)];
    positionView.backgroundColor = [UIColor colorWithRed:0.498 green:0.549 blue:0.553 alpha:1];
    positionView.layer.borderWidth = 2.0f;
    positionView.layer.borderColor = [UIColor colorWithRed:0.741 green:0.765 blue:0.78 alpha:1].CGColor;
    [vc.view addSubview:positionView];
    
    UILabel *pan = [[UILabel alloc] initWithFrame:CGRectMake(300, 60, 80, 20)];
    pan.text = @"Pan";
    pan.textColor = [UIColor midnightBlueColor];
    pan.font = [UIFont fontWithName:@"Lato-Bold" size:16];
    pan.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:pan];
    
    pan_text = [[UITextField alloc] initWithFrame:CGRectMake(300+15, 85, 50, 30)];
    pan_text.backgroundColor = [UIColor whiteColor];
    pan_text.layer.cornerRadius = cornerRadius;
    pan_text.placeholder = @"Pan";
    pan_text.text = [NSString stringWithFormat:@"%@",[controlBarClass.arrayForControlBar objectAtIndex:2]];
    pan_text.font = [UIFont fontWithName:@"Lato-Regular" size:14];
    pan_text.textAlignment = NSTextAlignmentCenter;
    [pan_text addTarget:self
                 action:@selector(panTextField)
       forControlEvents:UIControlEventEditingChanged];
    [vc.view addSubview:pan_text];
    
    
    UILabel *tilt = [[UILabel alloc] initWithFrame:CGRectMake(300, 120, 80, 20)];
    tilt.text = @"Tilt";
    tilt.textColor = [UIColor midnightBlueColor];
    tilt.font = [UIFont fontWithName:@"Lato-Bold" size:16];
    tilt.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:tilt];
    
    tilt_text = [[UITextField alloc] initWithFrame:CGRectMake(300+15, 145, 50, 30)];
    tilt_text.backgroundColor = [UIColor whiteColor];
    tilt_text.placeholder = @"Tilt";
    tilt_text.text = [NSString stringWithFormat:@"%@",[controlBarClass.arrayForControlBar objectAtIndex:3]];
    tilt_text.layer.cornerRadius = cornerRadius;
    tilt_text.font = [UIFont fontWithName:@"Lato-Regular" size:14];
    tilt_text.textAlignment = NSTextAlignmentCenter;
    [tilt_text addTarget:self
                  action:@selector(tiltTextField)
        forControlEvents:UIControlEventEditingChanged];
    [vc.view addSubview:tilt_text];
    
    [self createButton:vc.view
                 title:@"0,0"
                   tag:201
                     x:300
                     y:200
                     w:80
                     h:30
           buttonColor:[UIColor concreteColor]
           shadowColor:[UIColor asbestosColor]
          shadowHeight:3.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setZero:))
                  font:[UIFont boldFlatFontOfSize:16]];
    
    [self createButton:vc.view
                 title:@"127,127"
                   tag:202
                     x:300
                     y:240
                     w:80
                     h:30
           buttonColor:[UIColor concreteColor]
           shadowColor:[UIColor asbestosColor]
          shadowHeight:3.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setMid:))
                  font:[UIFont boldFlatFontOfSize:16]];
    
    [self createButton:vc.view
                 title:@"255,255"
                   tag:203
                     x:300
                     y:280
                     w:80
                     h:30
           buttonColor:[UIColor concreteColor]
           shadowColor:[UIColor asbestosColor]
          shadowHeight:3.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setFull:))
                  font:[UIFont boldFlatFontOfSize:16]];
    
    path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(positionView.bounds.size.width/2, 0)];
    [path addLineToPoint:CGPointMake(positionView.bounds.size.width/2, positionView.bounds.size.height)];
    
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = [path CGPath];
    shapeLayer.strokeColor = [[UIColor colorWithRed:0.741 green:0.765 blue:0.78 alpha:1] CGColor];
    shapeLayer.lineWidth = 1.0;
    shapeLayer.fillColor = [[UIColor clearColor] CGColor];
    
    [positionView.layer addSublayer:shapeLayer];
    
    path2 = [UIBezierPath bezierPath];
    [path2 moveToPoint:CGPointMake(0, positionView.bounds.size.height/2)];
    [path2 addLineToPoint:CGPointMake(positionView.bounds.size.width, positionView.bounds.size.height/2)];
    
    CAShapeLayer *shapeLayer2 = [CAShapeLayer layer];
    shapeLayer2.path = [path2 CGPath];
    shapeLayer2.strokeColor = [[UIColor colorWithRed:0.741 green:0.765 blue:0.78 alpha:1] CGColor];
    shapeLayer2.lineWidth = 1.0;
    shapeLayer2.fillColor = [[UIColor clearColor] CGColor];
    
    [positionView.layer addSublayer:shapeLayer2];
    
    panTiltButton = [[FUIButton alloc] initWithFrame:CGRectMake(127, 127, 20, 20)];
    panTiltButton.center = CGPointMake([[controlBarClass.arrayForControlBar objectAtIndex:2] intValue], [[controlBarClass.arrayForControlBar objectAtIndex:3] intValue]);
    panTiltButton.backgroundColor = [UIColor colorWithRed:0.945 green:0.769 blue:0.059 alpha:1];
    panTiltButton.layer.cornerRadius = 10.0f;
    [positionView addSubview:panTiltButton];
    
    
    UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(moveViewWithGestureRecognizer:)];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapScreen:)];
    [positionView addGestureRecognizer:panGestureRecognizer];
    [positionView addGestureRecognizer:tapGestureRecognizer];
}

-(void)moveViewWithGestureRecognizer:(UIPanGestureRecognizer *)panGestureRecognizer{
    CGPoint touchLocation = [panGestureRecognizer locationInView:positionView];
    panTiltButton.center = touchLocation;
    [path addLineToPoint:CGPointMake(positionView.bounds.size.width, positionView.bounds.size.height)];
    if (touchLocation.x<0 ) {
        panTiltButton.center = CGPointMake(0.0, touchLocation.y);
        if (touchLocation.y<0) {
            NSLog(@"move %f, %f",0.0, 0.0);
            panTiltButton.center = CGPointMake(0.0, 0.0);
        }
        else if (touchLocation.y>positionView.bounds.size.height) {
            NSLog(@"move %f, %f",0.0, positionView.bounds.size.height);
            panTiltButton.center = CGPointMake(0.0, positionView.bounds.size.height);
        }
    }
    else if (touchLocation.x>positionView.bounds.size.width) {
        panTiltButton.center = CGPointMake(positionView.bounds.size.width, touchLocation.y);
        if (touchLocation.y<0) {
            NSLog(@"move %f, %f",positionView.bounds.size.width, 0.0);
            panTiltButton.center = CGPointMake(positionView.bounds.size.width, 0.0);
        }
        else if (touchLocation.y>positionView.bounds.size.height) {
            NSLog(@"move %f, %f",positionView.bounds.size.width, positionView.bounds.size.height);
            panTiltButton.center = CGPointMake(positionView.bounds.size.width, positionView.bounds.size.height);
        }
    }
    else if (touchLocation.y<0 ) {
        panTiltButton.center = CGPointMake(touchLocation.x, 0.0);
        if (touchLocation.x<0) {
            NSLog(@"move %f, %f",0.0, 0.0);
            panTiltButton.center = CGPointMake(0.0, 0.0);
        }
        else if (touchLocation.x>positionView.bounds.size.width) {
            NSLog(@"move %f, %f",positionView.bounds.size.width, 0.0);
            panTiltButton.center = CGPointMake(positionView.bounds.size.width, 0.0);
        }
    }
    else if (touchLocation.y>positionView.bounds.size.height) {
        panTiltButton.center = CGPointMake(touchLocation.x, positionView.bounds.size.height);
        if (touchLocation.x<0) {
            NSLog(@"move %f, %f",0.0, positionView.bounds.size.height);
            panTiltButton.center = CGPointMake(0.0, positionView.bounds.size.height);
        }
        else if (touchLocation.x>positionView.bounds.size.width) {
            NSLog(@"move %f, %f",positionView.bounds.size.width, positionView.bounds.size.height);
            panTiltButton.center = CGPointMake(positionView.bounds.size.width, positionView.bounds.size.height);
        }
    }
    else {
        NSLog(@"move %f, %f",touchLocation.x,touchLocation.y);
        panTiltButton.center = CGPointMake(touchLocation.x, touchLocation.y);
    }
    pan_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.x];
    tilt_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.y];
    [self setPan];
    [self setTilt];
}

-(void)tapScreen:(UITapGestureRecognizer *)tapGestureRecognizer {
    CGPoint touchLocation = [tapGestureRecognizer locationInView:positionView];
    NSLog(@"tapScreen %f, %f",touchLocation.x,touchLocation.y);
    panTiltButton.center = touchLocation;
    pan_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.x];
    tilt_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.y];
    [self setPan];
    [self setTilt];
}

-(void)setMid:(id)sender {
    panTiltButton.center = CGPointMake(positionView.bounds.size.width/2, positionView.bounds.size.height/2);
    NSLog(@"setCenter %f,%f",panTiltButton.center.x,panTiltButton.center.y);
    pan_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.x];
    tilt_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.y];
    [self setPan];
    [self setTilt];
}

-(void)setFull:(id)sender {
    panTiltButton.center = CGPointMake(positionView.bounds.size.width, positionView.bounds.size.height);
    NSLog(@"setFull %f,%f",panTiltButton.center.x,panTiltButton.center.y);
    pan_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.x];
    tilt_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.y];
    [self setPan];
    [self setTilt];
}

-(void)setZero:(id)sender {
    panTiltButton.center = CGPointMake(0, 0);
    NSLog(@"setZero %f,%f",panTiltButton.center.x,panTiltButton.center.y);
    pan_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.x];
    tilt_text.text = [NSString stringWithFormat:@"%d",(int)panTiltButton.center.y];
    [self setPan];
    [self setTilt];
}

-(void) panTextField {
    int newX = [pan_text.text intValue];
    panTiltButton.center = CGPointMake(newX, panTiltButton.center.y);
    NSLog(@"panTextField %f,%f",panTiltButton.center.x,panTiltButton.center.y);
    [self setPan];
}

-(void) tiltTextField {
    int newY = [tilt_text.text intValue];
    panTiltButton.center = CGPointMake(panTiltButton.center.x, newY);
    NSLog(@"tiltTextField %f,%f",panTiltButton.center.x,panTiltButton.center.y);
    [self setTilt];
}

- (void)setPan {
    NSString * val = [NSString stringWithFormat:@"%@",pan_text.text];
    [controlBarClass updatedAndSent:4 val:val];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:2 withObject:pan_text.text];  // update arrayForControlBar
    NSLog(@"pan=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

- (void)setTilt {
    NSString * val = [NSString stringWithFormat:@"%@",tilt_text.text];
    [controlBarClass updatedAndSent:5 val:val];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:3 withObject:tilt_text.text];  // update arrayForControlBar
    NSLog(@"tilt=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////// Gobo /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

-(void)gobo:(UIViewController *)vc {
    
}


/////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////// Light Color //////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

-(void)initLightColor:(UIViewController *)vc {
    UILabel *colorLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 70, 60, 20)];
    colorLabel.text = @"Color";
    colorLabel.textColor = [UIColor midnightBlueColor];
    colorLabel.font = [UIFont fontWithName:@"Lato-Bold" size:16];
    colorLabel.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:colorLabel];
    
    [self createButton:vc.view
                 title:@""
                   tag:401
                     x:100
                     y:60
                     w:50
                     h:45
           buttonColor:[UIColor whiteColor]
           shadowColor:[UIColor silverColor]
          shadowHeight:5.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setLightColor:))
                  font:[UIFont boldFlatFontOfSize:16]];    // white
    
    [self createButton:vc.view
                 title:@""
                   tag:402
                     x:170
                     y:60
                     w:50
                     h:45
           buttonColor:[UIColor colorWithRed:0.812 green:0 blue:0.059 alpha:1]
           shadowColor:[UIColor colorWithRed:0.588 green:0.157 blue:0.106 alpha:1]
          shadowHeight:5.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setLightColor:))
                  font:[UIFont boldFlatFontOfSize:16]];    // red
    
    [self createButton:vc.view
                 title:@""
                   tag:403
                     x:240
                     y:60
                     w:50
                     h:45
           buttonColor:[UIColor orangeColor]
           shadowColor:[UIColor pumpkinColor]
          shadowHeight:5.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setLightColor:))
                  font:[UIFont boldFlatFontOfSize:16]];    // orange
    
    [self createButton:vc.view
                 title:@""
                   tag:404
                     x:310
                     y:60
                     w:50
                     h:45
           buttonColor:[UIColor yellowColor]
           shadowColor:[UIColor sunflowerColor]
          shadowHeight:5.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setLightColor:))
                  font:[UIFont boldFlatFontOfSize:16]];    // yellow
    
    [self createButton:vc.view
                 title:@""
                   tag:405
                     x:380
                     y:60
                     w:50
                     h:45
           buttonColor:[UIColor greenColor]
           shadowColor:[UIColor nephritisColor]
          shadowHeight:5.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setLightColor:))
                  font:[UIFont boldFlatFontOfSize:16]];    // green
    
    [self createButton:vc.view
                 title:@""
                   tag:406
                     x:450
                     y:60
                     w:50
                     h:45
           buttonColor:[UIColor colorWithRed:0.294 green:0.467 blue:0.745 alpha:1]
           shadowColor:[UIColor wetAsphaltColor]
          shadowHeight:5.0f
            titleColor:[UIColor cloudsColor]
              selector:NSStringFromSelector(@selector(setLightColor:))
                  font:[UIFont boldFlatFontOfSize:16]];    // blue
    
    int savedTag = [[controlBarClass.arrayForControlBar objectAtIndex:5] intValue];
    NSLog(@"savedTag=%d",savedTag);
    [self setHasSelectedButton:vc.view tag:savedTag];
}

-(void)setLightColor:(id)sender {
    NSLog(@"%ld",(long)((FUIButton *)sender).tag);
    NSString * val = @"";
    int highlight = 0;
    if (((FUIButton *)sender).tag==401) {
        highlight = 401;
        val = [NSString stringWithFormat:@"%d",0];
    }
    else if (((FUIButton *)sender).tag==402) {
        highlight = 402;
        for (int i=0; i<controlBarClass.selected.count; i++) {
            int deviceIndex = [[controlBarClass.selected objectAtIndex:i] intValue]-1;
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Xspot"])
                val = [NSString stringWithFormat:@"%d",200];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Studio250"])
                val = [NSString stringWithFormat:@"%d",83];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"CyberLight"])
                val = [NSString stringWithFormat:@"%d",0];
        }
    }
    else if (((FUIButton *)sender).tag==403) {
        highlight = 403;
        for (int i=0; i<controlBarClass.selected.count; i++) {
            int deviceIndex = [[controlBarClass.selected objectAtIndex:i] intValue]-1;
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Xspot"])
                val = [NSString stringWithFormat:@"%d",90];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Studio250"])
                val = [NSString stringWithFormat:@"%d",100];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"CyberLight"])
                val = [NSString stringWithFormat:@"%d",0];
        }
    }
    else if (((FUIButton *)sender).tag==404) {
        highlight = 404;
        for (int i=0; i<controlBarClass.selected.count; i++) {
            int deviceIndex = [[controlBarClass.selected objectAtIndex:i] intValue]-1;
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Xspot"])
                val = [NSString stringWithFormat:@"%d",160];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Studio250"])
                val = [NSString stringWithFormat:@"%d",69];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"CyberLight"])
                val = [NSString stringWithFormat:@"%d",0];
        }
    }
    else if (((FUIButton *)sender).tag==405) {
        highlight = 405;
        for (int i=0; i<controlBarClass.selected.count; i++) {
            int deviceIndex = [[controlBarClass.selected objectAtIndex:i] intValue]-1;
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Xspot"])
                val = [NSString stringWithFormat:@"%d",120];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Studio250"])
                val = [NSString stringWithFormat:@"%d",50];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"CyberLight"])
                val = [NSString stringWithFormat:@"%d",0];
        }
    }
    else if (((FUIButton *)sender).tag==406) {
        highlight = 406;
        for (int i=0; i<controlBarClass.selected.count; i++) {
            int deviceIndex = [[controlBarClass.selected objectAtIndex:i] intValue]-1;
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Xspot"])
                val = [NSString stringWithFormat:@"%d",52];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"Studio250"])
                val = [NSString stringWithFormat:@"%d",108];
            if([[ [ controlBarClass.device objectAtIndex:deviceIndex ] objectAtIndex:2 ] isEqual:@"CyberLight"])
                val = [NSString stringWithFormat:@"%d",0];
        }
    }
    for (int i=401; i<407; i++) {
        FUIButton * hl = (FUIButton *)[((FUIButton *)sender).superview viewWithTag:i];
        if (highlight==hl.tag && ![hl isSelected]) {
            [[hl layer] setBorderColor:[UIColor blackColor].CGColor];
            [hl setSelected:YES];
        }
        else {
            [[hl layer] setBorderColor:[UIColor clearColor].CGColor];
            [hl setSelected:NO];
        }
    }
    [controlBarClass updatedAndSent:7 val:val];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:5 withObject:[NSString stringWithFormat:@"%d",highlight]];  // update arrayForControlBar
    NSLog(@"color=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////   Beam      //////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

-(void)initIris:(UIViewController *)vc {
    UILabel *irisLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 50, 60, 20)];
    irisLabel.text = @"Iris";
    irisLabel.textColor = [UIColor midnightBlueColor];
    irisLabel.font = [UIFont fontWithName:@"Lato-Bold" size:16];
    irisLabel.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:irisLabel];
    
    NSArray *itemArray = [NSArray arrayWithObjects: @"Open", @"Close", nil];
    FUISegmentedControl *irisSegmentedControl = [[FUISegmentedControl alloc] initWithItems:itemArray];
    irisSegmentedControl.frame = CGRectMake(100, 60, 130, 30);
    irisSegmentedControl.selectedFont = [UIFont boldFlatFontOfSize:16];
    irisSegmentedControl.selectedFontColor = [UIColor cloudsColor];
    irisSegmentedControl.deselectedFont = [UIFont flatFontOfSize:16];
    irisSegmentedControl.deselectedFontColor = [UIColor cloudsColor];
    irisSegmentedControl.selectedColor = [UIColor pumpkinColor];
    irisSegmentedControl.deselectedColor = [UIColor silverColor];
    irisSegmentedControl.disabledColor = [UIColor silverColor];
    irisSegmentedControl.dividerColor = [UIColor silverColor];
    [irisSegmentedControl addTarget:self action:@selector(irisSegmentControlAction:) forControlEvents: UIControlEventValueChanged];
    if ([[controlBarClass.arrayForControlBar objectAtIndex:6] isEqualToString:@"0"]) {
        irisSegmentedControl.selectedSegmentIndex = 1;
    }
    else {
        irisSegmentedControl.selectedSegmentIndex = 0;
    }
    [vc.view addSubview:irisSegmentedControl];
}

- (void)irisSegmentControlAction:(UISegmentedControl *)segment
{
    NSString * val = @"";
    if(segment.selectedSegmentIndex == 0)
    {
        NSLog(@"iris open");
        val = [NSString stringWithFormat:@"%d",255];
    }
    else if(segment.selectedSegmentIndex == 1)
    {
        NSLog(@"iris close");
        val = [NSString stringWithFormat:@"%d",0];
    }
    [controlBarClass updatedAndSent:8 val:val];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:6 withObject:val];  // update arrayForControlBar
    NSLog(@"color=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

-(void)initShutter:(UIViewController *)vc {
    UILabel *shutterLabel = [[UILabel alloc] initWithFrame:CGRectMake(280, 50, 60, 20)];
    shutterLabel.text = @"Shutter";
    shutterLabel.textColor = [UIColor midnightBlueColor];
    shutterLabel.font = [UIFont fontWithName:@"Lato-Bold" size:16];
    shutterLabel.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:shutterLabel];
    
    NSArray *itemArray = [NSArray arrayWithObjects: @"Open", @"Close", nil];
    FUISegmentedControl *shutterSegmentedControl = [[FUISegmentedControl alloc] initWithItems:itemArray];
    shutterSegmentedControl.frame = CGRectMake(360, 60, 130, 30);
    shutterSegmentedControl.selectedFont = [UIFont boldFlatFontOfSize:16];
    shutterSegmentedControl.selectedFontColor = [UIColor cloudsColor];
    shutterSegmentedControl.deselectedFont = [UIFont flatFontOfSize:16];
    shutterSegmentedControl.deselectedFontColor = [UIColor cloudsColor];
    shutterSegmentedControl.selectedColor = [UIColor pumpkinColor];
    shutterSegmentedControl.deselectedColor = [UIColor silverColor];
    shutterSegmentedControl.disabledColor = [UIColor silverColor];
    shutterSegmentedControl.dividerColor = [UIColor silverColor];
    [shutterSegmentedControl addTarget:self action:@selector(shutterSegmentControlAction:) forControlEvents: UIControlEventValueChanged];
    if ([[controlBarClass.arrayForControlBar objectAtIndex:7] isEqualToString:@"0"]) {
        shutterSegmentedControl.selectedSegmentIndex = 1;
    }
    else {
        shutterSegmentedControl.selectedSegmentIndex = 0;
    }
    [vc.view addSubview:shutterSegmentedControl];
}

- (void)shutterSegmentControlAction:(UISegmentedControl *)segment
{
    NSString * val = @"";
    if(segment.selectedSegmentIndex == 0)
    {
        NSLog(@"shutter open");
        val = [NSString stringWithFormat:@"%d",255];
    }
    else if(segment.selectedSegmentIndex == 1)
    {
        NSLog(@"shutter close");
        val = [NSString stringWithFormat:@"%d",0];
    }
    [controlBarClass updatedAndSent:9 val:val];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:7 withObject:val];  // update arrayForControlBar
    NSLog(@"color=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////// Focus & Zoom /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

-(void)initFocus:(UIViewController *)vc {
    UILabel *shutterLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 50, 60, 20)];
    shutterLabel.text = @"Focus";
    shutterLabel.textColor = [UIColor midnightBlueColor];
    shutterLabel.font = [UIFont fontWithName:@"Lato-Bold" size:16];
    shutterLabel.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:shutterLabel];
    
    //Create the Circular Slider
    focusSlider = [TBCircularSlider alloc];
    focusSlider.val = [[controlBarClass.arrayForControlBar objectAtIndex:8] intValue];
    focusSlider = [focusSlider initWithFrame:CGRectMake(0, 30, TB_SLIDER_SIZE, TB_SLIDER_SIZE)];
    
    //Define Target-Action behaviour
    [focusSlider addTarget:self action:@selector(focusValue:) forControlEvents:UIControlEventValueChanged];
    [vc.view addSubview:focusSlider];
    
    //Define the Font
    UIFont *font = [UIFont fontWithName:@"Lato-Bold" size:TB_FONTSIZE];
    NSDictionary *attributes = @{NSFontAttributeName:font};
    //Calculate font size needed to display 3 numbers
    NSString *str = @"000";
    CGSize fontSize = [str sizeWithAttributes:attributes];
    
    //Using a TextField area we can easily modify the control to get user input from this field
    focusTextField = [[UITextField alloc]initWithFrame:CGRectMake((focusSlider.frame.size.width  - fontSize.width)/2, (focusSlider.frame.size.height - fontSize.height) /2, fontSize.width, fontSize.height)];
    focusTextField.backgroundColor = [UIColor clearColor];
    focusTextField.textColor = [UIColor cloudsColor];
    focusTextField.textAlignment = NSTextAlignmentCenter;
    focusTextField.font = font;
    focusTextField.text = [NSString stringWithFormat:@"%d",255*focusSlider.angle/360];
    [focusTextField addTarget:self action:@selector(focusTextField) forControlEvents:UIControlEventEditingChanged];
    focusTextField.enabled = YES;
    [focusSlider addSubview:focusTextField];
}

-(void)focusValue:(TBCircularSlider *)slider {
    //NSLog(@"Slider Value %d",255*slider.angle/360);
    NSString * val = [NSString stringWithFormat:@"%d",255*slider.angle/360];
    focusTextField.text = val;
    [controlBarClass updatedAndSent:10 val:val];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:8 withObject:val]; // update arrayForControlBar
    NSLog(@"focus=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

-(void) focusTextField {
    int angleFromTextField = [focusTextField.text intValue];
    focusSlider.angle = 360*(angleFromTextField+1)/255;
    [focusSlider setNeedsDisplay];
    [controlBarClass updatedAndSent:10 val:focusTextField.text];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:8 withObject:focusTextField.text]; // update arrayForControlBar
    NSLog(@"focus=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

-(void)initZoom:(UIViewController *)vc {
    UILabel *shutterLabel = [[UILabel alloc] initWithFrame:CGRectMake(250, 50, 60, 20)];
    shutterLabel.text = @"Zoom";
    shutterLabel.textColor = [UIColor midnightBlueColor];
    shutterLabel.font = [UIFont fontWithName:@"Lato-Bold" size:16];
    shutterLabel.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:shutterLabel];
    
    //Create the Circular Slider
    zoomSlider = [TBCircularSlider alloc];
    zoomSlider.val = [[controlBarClass.arrayForControlBar objectAtIndex:9] intValue];
    zoomSlider = [zoomSlider initWithFrame:CGRectMake(250, 30, TB_SLIDER_SIZE, TB_SLIDER_SIZE)];
    
    //Define Target-Action behaviour
    [zoomSlider addTarget:self action:@selector(zoomValue:) forControlEvents:UIControlEventValueChanged];
    [vc.view addSubview:zoomSlider];
    
    //Define the Font
    UIFont *font = [UIFont fontWithName:@"Lato-Bold" size:TB_FONTSIZE];
    NSDictionary *attributes = @{NSFontAttributeName:font};
    //Calculate font size needed to display 3 numbers
    NSString *str = @"000";
    CGSize fontSize = [str sizeWithAttributes:attributes];
    
    //Using a TextField area we can easily modify the control to get user input from this field
    zoomTextField = [[UITextField alloc]initWithFrame:CGRectMake((zoomSlider.frame.size.width  - fontSize.width)/2, (zoomSlider.frame.size.height - fontSize.height) /2, fontSize.width, fontSize.height)];
    zoomTextField.backgroundColor = [UIColor clearColor];
    zoomTextField.textColor = [UIColor cloudsColor];
    zoomTextField.textAlignment = NSTextAlignmentCenter;
    zoomTextField.font = font;
    zoomTextField.text = [NSString stringWithFormat:@"%d",255*zoomSlider.angle/360];
    [zoomTextField addTarget:self action:@selector(zoomTextField) forControlEvents:UIControlEventEditingChanged];
    zoomTextField.enabled = YES;
    [zoomSlider addSubview:zoomTextField];
}

-(void)zoomValue:(TBCircularSlider *)slider {
    //NSLog(@"Slider Value %d",255*slider.angle/360);
    
    NSString * val = [NSString stringWithFormat:@"%d",255*slider.angle/360];
    zoomTextField.text = val;
    [controlBarClass updatedAndSent:11 val:val];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:9 withObject:val]; // update arrayForControlBar
    NSLog(@"zoom=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

-(void) zoomTextField {
    int angleFromTextField = [zoomTextField.text intValue];
    zoomSlider.angle = 360*(angleFromTextField+1)/255;
    [zoomSlider setNeedsDisplay];
    [controlBarClass updatedAndSent:11 val:zoomTextField.text];
    [controlBarClass.arrayForControlBar replaceObjectAtIndex:9 withObject:zoomTextField.text]; // update arrayForControlBar
    NSLog(@"zoom=%@,\ncontrolBar=%@",controlBarClass.device,controlBarClass.arrayForControlBar);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////// effect   ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////


-(void)effectOffset:(UIViewController *)vc {
    
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////// store and clear ////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

-(void)store {
    FUIButton * storeButton = (FUIButton *)[containerView viewWithTag:1007];
    NSLog(@"stored%@", controlBarClass.selected);
    if (controlBarClass.storeState) {
        controlBarClass.storeState = false;
        storeButton.buttonColor = [UIColor colorWithRed:0.161 green:0.161 blue:0.161 alpha:1];
        storeButton.shadowColor = [UIColor colorWithRed:0.118 green:0.118 blue:0.118 alpha:1];
        NSLog(@"state=false");
    }
    else {
        controlBarClass.storeState = true;
        storeButton.buttonColor = [UIColor sunflowerColor];
        storeButton.shadowColor = [UIColor orangeColor];
        NSLog(@"state=true");
    }
}

-(void)clear:(id)sender {
    controlBarClass.clearState++;
    NSLog(@"clear %ld, clearState=%d",(long)((FUIButton *)sender).tag, controlBarClass.clearState);
    NSString * val = [NSString stringWithFormat:@"%d",0];
    if (controlBarClass.clearState == 1) {
        for (int i=0; i<controlBarClass.selected.count; i++) {
            int selectedButton = [[controlBarClass.selected objectAtIndex:i] intValue]-1;
            for (int j=3; j<[[controlBarClass.device objectAtIndex:selectedButton] count]; j++) {
                [controlBarClass setData:selectedButton
                                      ch:j
                                     obj:val];
            }
        }
        NSLog(@"clear.. device=%@",controlBarClass.device);
    }
    else if (controlBarClass.clearState == 2) {
        [controlBarClass.selected removeAllObjects];
        if ([delegateInControlBar.page isEqual:@"LayoutViewController"]) {
            [self viewDidLoad];
        } else if ([delegateInControlBar.page isEqual:@"DeviceViewController"] ||
                   [delegateInControlBar.page isEqual:@"AllPresetViewController"]) {
            [self viewDidAppear:NO];
        }
        controlBarClass.clearState = 0;
        NSLog(@"clear.. selected=%@",controlBarClass.selected);
    }
}

-(void)undo:(id)sender {
    NSLog(@"undo %ld",(long)((FUIButton *)sender).tag);
}

-(void)setHasSelectedButton:(UIView *)inView tag:(int)tag {
    FUIButton * hasSelected = (FUIButton *)[inView viewWithTag:tag];
    NSLog(@"setHasSelectedButton tag=%ld", (long)hasSelected.tag);
    [hasSelected setSelected:YES];
    if(hasSelected.selected) {
        [[hasSelected layer] setBorderColor:[UIColor blackColor].CGColor];
    }
    else {
        [[hasSelected layer] setBorderColor:[UIColor clearColor].CGColor];
    }
}

-(void)createButton:(UIView *)view
              title:(NSString *)title
                tag:(int)tag
                  x:(int)x
                  y:(int)y
                  w:(int)w
                  h:(int)h
        buttonColor:(UIColor *)buttonColor
        shadowColor:(UIColor *)shadowColor
       shadowHeight:(float)shadowHeight
         titleColor:(UIColor *)titleColor
           selector:(NSString *)selector
               font:(UIFont *)font {
    FUIButton *button = [[FUIButton alloc] initWithFrame:CGRectMake(x, y, w, h)];
    [button setTitle:title forState:UIControlStateNormal];
    button.tag = tag;
    button.buttonColor = buttonColor;
    button.shadowColor = shadowColor;
    button.shadowHeight = shadowHeight;
    //button.cornerRadius = 9.0f;
    button.titleLabel.font = font;
    [button setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
    [[button layer] setBorderWidth:2.0f];
    [[button layer] setBorderColor:[UIColor clearColor].CGColor];
    [button addTarget:self action:NSSelectorFromString(selector) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
}

@end
