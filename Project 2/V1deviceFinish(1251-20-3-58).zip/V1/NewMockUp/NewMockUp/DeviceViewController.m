//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "DeviceViewController.h"

@interface DeviceViewController ()

@end

@implementation DeviceViewController {
    // group device
    UIView *groupView;
    UIScrollView *myScroll;
    int x_groupView;
    int y_groupView;
    int width_groupView;
    int height_groupView;
    
    DataClass *deviceClass;
    NSMutableArray * element;
}

@synthesize headerView;
@synthesize headerLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    [super initControlBar];
    // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
    [self initVariables];
    [self setGroupDeviceButton];
    
    if (deviceClass.saveGroupDevice.count!=0) {
        NSLog(@"viewdidload refresh");
        for (int i=0; i<[deviceClass.saveGroupDevice count]; i++) {
            int savedGroupDeviceTag = [[[deviceClass.saveGroupDevice objectAtIndex:i] objectAtIndex:0] intValue];
            [self refresh:savedGroupDeviceTag index:i];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated {
    if (deviceClass.saveGroupDevice.count!=0) {
        NSLog(@"viewdidappear refresh");
        for (int i=0; i<[deviceClass.saveGroupDevice count]; i++) {
            int savedGroupDeviceTag = [[[deviceClass.saveGroupDevice objectAtIndex:i] objectAtIndex:0] intValue];
            [self refresh:savedGroupDeviceTag index:i];
        }
    }
}

-(void)configureView {
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    
    headerLabel.text = @"DEVICE";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    //parameter for groupView
    x_groupView = 0;
    y_groupView = 56;
    width_groupView = 830;
    height_groupView = 611;
    
    // init groupView
    groupView = [[UIView alloc] initWithFrame:CGRectMake( x_groupView, y_groupView,width_groupView, height_groupView)];
    groupView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    groupView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    //groupView.layer.cornerRadius = cornerRadius;
    groupView.layer.masksToBounds = YES;
    [self.view addSubview:groupView];
    
    // init scroll view
    myScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, groupView.bounds.size.width, groupView.bounds.size.height)];
    myScroll.contentSize = CGSizeMake(groupView.bounds.size.width, 1000);   //scroll view size
    myScroll.backgroundColor = [UIColor clearColor];
    myScroll.showsVerticalScrollIndicator = NO;    // to hide scroll indicators!
    myScroll.showsHorizontalScrollIndicator = YES; //by default, it shows!
    myScroll.scrollEnabled = YES;                 //say "NO" to disable scroll
    [groupView addSubview:myScroll];               //adding to parent view!
}

-(void)initVariables {
    deviceClass = [DataClass sharedGlobalData];
    element = [[NSMutableArray alloc] init];
}

-(void)setGroupDeviceButton {
    int column = 7;
    int row = 8;
    int x_groupDeviceButton = 5;
    int y_groupDeviceButton = 5;
    int width_groupDeviceButton = 118-x_groupDeviceButton;
    int height_groupDeviceButton = 118-y_groupDeviceButton;
    for (int i=0; i<row; i++) {
        for (int j=0; j<column; j++) {
            [self createGroupButton:myScroll
                              title:@""
                                tag:(i*column)+j+1
                                  x:x_groupDeviceButton+((width_groupDeviceButton+x_groupDeviceButton)*j)
                                  y:y_groupDeviceButton+((height_groupDeviceButton+y_groupDeviceButton)*i)
                                  w:width_groupDeviceButton
                                  h:height_groupDeviceButton
                        buttonColor:[UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1]
                        shadowColor:[UIColor colorWithRed:0.171 green:0.21 blue:0.237 alpha:1]
                       shadowHeight:3.0f
                         titleColor:[UIColor cloudsColor]
                           selector:NSStringFromSelector(@selector(showAlertView:))
                               font:[UIFont flatFontOfSize:16]];
        }
    }
}

-(void)showAlertView:(id)sender {
    long tag = (long)((UIButton *)sender).tag;
    if (deviceClass.storeState && deviceClass.selected.count!=0) {
        FUIAlertView *alertView = [[FUIAlertView alloc] initWithTitle:@"Name"
                                                              message:@"Insert group name"
                                                             delegate:nil
                                                    cancelButtonTitle:@"Cancel"
                                                    otherButtonTitles:@"OK", nil];
        alertView.alertViewStyle = FUIAlertViewStylePlainTextInput;
        [@[[alertView textFieldAtIndex:0]] enumerateObjectsUsingBlock:^(FUITextField *textField, NSUInteger idx, BOOL *stop) {
            [textField setTextFieldColor:[UIColor cloudsColor]];
            [textField setBorderColor:[UIColor asbestosColor]];
            [textField setCornerRadius:4];
            [textField setFont:[UIFont flatFontOfSize:14]];
            [textField setTextColor:[UIColor midnightBlueColor]];
        }];
        [[alertView textFieldAtIndex:0] setPlaceholder:@"Text here!"];
        
        alertView.delegate = self;
        alertView.tag = tag;
        alertView.titleLabel.textColor = [UIColor cloudsColor];
        alertView.titleLabel.font = [UIFont boldFlatFontOfSize:16];
        alertView.messageLabel.textColor = [UIColor cloudsColor];
        alertView.messageLabel.font = [UIFont flatFontOfSize:14];
        alertView.backgroundOverlay.backgroundColor = [[UIColor cloudsColor] colorWithAlphaComponent:0.8];
        alertView.alertContainer.backgroundColor = [UIColor midnightBlueColor];
        //alertView.alertContainer.layer.cornerRadius = cornerRadius;
        alertView.defaultButtonColor = [UIColor cloudsColor];
        alertView.defaultButtonShadowColor = [UIColor asbestosColor];
        alertView.defaultButtonFont = [UIFont boldFlatFontOfSize:16];
        alertView.defaultButtonTitleColor = [UIColor asbestosColor];
        [alertView show];
    }
    else if (!deviceClass.storeState){
        if ([deviceClass.saveGroupDevice count]!=0) {
            for (int i=0; i<[deviceClass.saveGroupDevice count]; i++) {
                int numberOfGroupDevice = [[[deviceClass.saveGroupDevice objectAtIndex:i] objectAtIndex:0] intValue];
                if (tag==numberOfGroupDevice) {
                    deviceClass.selected = [[[deviceClass.saveGroupDevice objectAtIndex:i]
                                             objectAtIndex:1] mutableCopy];
                    NSLog(@"select group device, selected=%@",deviceClass.selected);
                }
            }
        }
        for (int i=0; i<[deviceClass.saveGroupDevice count]; i++) {
            int savedGroupDeviceTag = [[[deviceClass.saveGroupDevice objectAtIndex:i] objectAtIndex:0] intValue];
            [self refresh:savedGroupDeviceTag index:i];
        }
    }
}

- (void)alertView:(FUIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString * saveNameGroup = @"";
    if (buttonIndex==1) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        saveNameGroup = textfield.text;      // name of group device
        NSLog(@"group name=%@",saveNameGroup);
        bool same = false;
        int sameIndex = 0;
        [element addObject:[NSString stringWithFormat:@"%ld",(long)alertView.tag]];
        [element addObject:[deviceClass.selected mutableCopy]];
        [element addObject:saveNameGroup];
        if ([deviceClass.saveGroupDevice count]!=0) {
            for (int i=0; i<[deviceClass.saveGroupDevice count]; i++) {
                int numberOfGroupDevice = [[[deviceClass.saveGroupDevice objectAtIndex:i] objectAtIndex:0] intValue];
                if (alertView.tag==numberOfGroupDevice) {
                    //NSLog(@"tag=%ld,already have=%d", tag,numberOfGroupDevice);
                    same = true;
                    sameIndex = i;
                }
            }
            if (!same) {
                [deviceClass.saveGroupDevice addObject:[element mutableCopy]];
                NSLog(@"ADD save group done %@",deviceClass.saveGroupDevice);
                same = false;
            }
            else {
                [deviceClass.saveGroupDevice replaceObjectAtIndex:sameIndex withObject:[element mutableCopy]];
                NSLog(@"REPLACE save group done %@",deviceClass.saveGroupDevice);
            }
        }
        else {
            [deviceClass.saveGroupDevice addObject:[element mutableCopy]];
            NSLog(@"EMPTY_ADD save group done %@",deviceClass.saveGroupDevice);
        }
        /* create JSON form */
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        NSMutableArray *theArrayTest = [[NSMutableArray alloc] init];
        NSString * deviceString = @"";
        [test setObject:[element objectAtIndex:0] forKey:@"group_id"];
        for (int i=0; i<[[element objectAtIndex:1] count]; i++) {
            NSString * tempString = @"";
            if (i==[[element objectAtIndex:1]  count]-1) {
                tempString = [NSString stringWithFormat:@"%@",[[element objectAtIndex:1] objectAtIndex:i]];
                deviceString = [deviceString stringByAppendingString:tempString];
            }
            else {
                tempString = [NSString stringWithFormat:@"%@,",[[element objectAtIndex:1] objectAtIndex:i]];
                deviceString = [deviceString stringByAppendingString:tempString];
            }
        }
        [test setObject:[deviceString mutableCopy] forKey:@"device"];
        [test setObject:[element objectAtIndex:2] forKey:@"name"];
        [theArrayTest addObject:[test mutableCopy]];
        
        /* send JSON form */
        [deviceClass toString:[theArrayTest mutableCopy] thatView:@"groupdevice" action:@"add_groupdevice/"];
        
        [element removeAllObjects];
        
        [super store];
    }
    for (int i=0; i<[deviceClass.saveGroupDevice count]; i++) {
        int savedGroupDeviceTag = [[[deviceClass.saveGroupDevice objectAtIndex:i] objectAtIndex:0] intValue];
        [self refresh:savedGroupDeviceTag index:i];
    }
}

-(void)refresh:(long)tag index:(int)index {
    FUIButton *b = (FUIButton *)[myScroll viewWithTag:tag];
    UILabel *nameLabel_hasselect = (UILabel *)(FUIButton *)[myScroll viewWithTag:10000+tag];
    UILabel *groupLabel_hasselect = (UILabel *)(FUIButton *)[myScroll viewWithTag:100000+tag];
    
    // set name
    NSString *text = @"";
    text = [[[deviceClass.saveGroupDevice objectAtIndex:index] objectAtIndex:2] mutableCopy];
    nameLabel_hasselect.text = text;
    text = @"";
    
    // set group
    NSMutableArray *temp = [[NSMutableArray alloc] init];
    temp = [[[deviceClass.saveGroupDevice objectAtIndex:index] objectAtIndex:1] mutableCopy];
    for (int j=0; j<[temp count]; j++) {
        if(j==[temp count]-1)
            text= [text stringByAppendingString:[NSString stringWithFormat:@"%@",[temp objectAtIndex:j]]];
        else
            text= [text stringByAppendingString:[NSString stringWithFormat:@"%@,",[temp objectAtIndex:j]]];
    }
    groupLabel_hasselect.text = text;
    
    // change buttonColor
    NSMutableSet *common = [NSMutableSet setWithArray:deviceClass.selected];
    NSMutableArray * tempGroupSelected = [[NSMutableArray alloc] init];
    tempGroupSelected = [[[deviceClass.saveGroupDevice objectAtIndex:index] objectAtIndex:1] mutableCopy];
    NSMutableSet * a =[NSMutableSet setWithArray:tempGroupSelected];
    [common intersectSet:a];
    NSLog(@"commonCOUNT=%lu",(unsigned long)common.count);
    if (common.count == tempGroupSelected.count) {
        b.buttonColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
        b.shadowColor = [UIColor colorWithRed:0.157 green:0.507 blue:0.7 alpha:1];
    }
    else {
        b.buttonColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
        b.shadowColor = [UIColor colorWithRed:0.171 green:0.21 blue:0.237 alpha:1];
    }
}

-(void)createGroupButton:(UIView *)view
                   title:(NSString *)title
                     tag:(int)tag
                       x:(int)x
                       y:(int)y
                       w:(int)w
                       h:(int)h
             buttonColor:(UIColor *)buttonColor
             shadowColor:(UIColor *)shadowColor
            shadowHeight:(float)shadowHeight
              titleColor:(UIColor *)titleColor
                selector:(NSString *)selector
                    font:(UIFont *)font {
    FUIButton *button = [[FUIButton alloc] initWithFrame:CGRectMake(x, y, w, h)];
    [button setTitle:title forState:UIControlStateNormal];
    button.tag = tag;
    button.buttonColor = buttonColor;
    button.shadowColor = shadowColor;
    button.shadowHeight = shadowHeight;
    //button.cornerRadius = 9.0f;
    button.titleLabel.font = font;
    [button setTitleColor:[UIColor cloudsColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor cloudsColor] forState:UIControlStateHighlighted];
    [button addTarget:self action:NSSelectorFromString(selector) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    
    UILabel * number = [[UILabel alloc] initWithFrame:CGRectMake(w-35, 5, 30, 20)];
    number.text = [NSString stringWithFormat:@"%d",tag];
    number.font = [UIFont flatFontOfSize:15];
    number.textColor = [UIColor cloudsColor];
    number.tag = 1000+tag;
    number.textAlignment = NSTextAlignmentRight;
    [button addSubview:number];
    
    UILabel * name = [[UILabel alloc] initWithFrame:CGRectMake(5, h/2-(25/2), w-5, 20)];
    name.text = @"";
    name.font = [UIFont flatFontOfSize:16];
    name.textColor = [UIColor cloudsColor];
    name.tag = 10000+tag;
    name.textAlignment = NSTextAlignmentCenter;
    [button addSubview:name];
    
    UILabel * group = [[UILabel alloc] initWithFrame:CGRectMake(5, h-25, w-5, 20)];
    group.text = @"";
    group.font = [UIFont flatFontOfSize:16];
    group.textColor = [UIColor cloudsColor];
    group.tag = 100000+tag;
    group.textAlignment = NSTextAlignmentCenter;
    [button addSubview:group];
}

@end
