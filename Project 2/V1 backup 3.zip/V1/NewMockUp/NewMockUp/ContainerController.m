//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "ContainerController.h"

@interface ContainerController ()

@end

@implementation ContainerController {
    AppDelegate * ad;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSLog(@"%@",ad.page);
    if ( [ad.page isEqualToString:@"PatchingViewController"]) {
        UIStoryboard * storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        PatchingViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"PatchingViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"LayoutViewController"]) {
        UIStoryboard * storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        LayoutViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"LayoutViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"DeviceViewController"]) {
        UIStoryboard * storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        DeviceViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"DeviceViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"AllPresetViewController"]) {
        UIStoryboard * storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        AllPresetViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"AllPresetViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
    else if ( [ad.page isEqualToString:@"CueListViewController"]) {
        UIStoryboard * storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        CueListViewController * news = [storyboard instantiateViewControllerWithIdentifier:@"CueListViewController"];
        [self.view addSubview:news.view];
        [self addChildViewController:news];
        [news didMoveToParentViewController:self];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
