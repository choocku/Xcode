//
//  ViewController.m
//  NewMockUp
//
//  Created by Peeranon Wattanapong on 1/21/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "PatchingViewController.h"

@interface PatchingViewController ()

@end

@implementation PatchingViewController{
    NSMutableArray * data;
    DataClass *patchingClass;
    int row;
    NSString * name;
    NSString * type;
    NSMutableArray * createData;
    int x_drawDevices;
    int y_drawDevices;
    NSMutableArray * temp;
}

@synthesize headerView;
@synthesize dataView;
@synthesize headerLabel;
@synthesize idLabel;
@synthesize nameLabel;
@synthesize typeLabel;
@synthesize patchingTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    headerView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    dataView.backgroundColor = [UIColor colorWithRed:0.212 green:0.247 blue:0.271 alpha:1];
    patchingTableView.backgroundColor = [UIColor clearColor];
    
    headerLabel.text = @"PATCHING";
    headerLabel.textColor = [UIColor colorWithRed:0.357 green:0.706 blue:0.902 alpha:1];
    
    idLabel.text = @"DEVICE ID";
    
    nameLabel.text = @"NAME";
    
    typeLabel.text = @"TYPE";
    
    // set table style
    patchingTableView.backgroundColor = [UIColor clearColor];
    patchingTableView.separatorColor = [UIColor clearColor];
    patchingTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    data = [[NSMutableArray alloc] init];
    patchingClass = [DataClass sharedGlobalData];
    
    row = 0;
    name = @"";
    type = @"";
    
    createData = [[NSMutableArray alloc] initWithObjects:@"0",@"0",@"0",@"0",@"0",@"0",@"0",@"0",@"0",nil];
    
    // parameter of drawDevices
    x_drawDevices = 400;
    y_drawDevices = 50;
    
    temp = [[NSMutableArray alloc] init];
}

-(void)viewDidAppear:(BOOL)animated {
    [patchingTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return patchingClass.device.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"MyCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    cell.backgroundColor = [UIColor colorWithRed:0.271 green:0.31 blue:0.337 alpha:1];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self showData:cell indexPath:indexPath];
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * label1 = (UILabel *)[cell viewWithTag:1];
    UILabel * label2 = (UILabel *)[cell viewWithTag:2];
    UILabel * label3 = (UILabel *)[cell viewWithTag:3];
    
    label1.text = [NSString stringWithFormat:@"%@",[[patchingClass.device objectAtIndex:indexPath.row] objectAtIndex:0]];
    label1.textColor = [UIColor whiteColor];
    label2.text = [NSString stringWithFormat:@"%@",[[patchingClass.device objectAtIndex:indexPath.row] objectAtIndex:1]];
    label2.textColor = [UIColor whiteColor];
    label3.text = [NSString stringWithFormat:@"%@",[[patchingClass.device objectAtIndex:indexPath.row] objectAtIndex:2]];
    label3.textColor = [UIColor whiteColor];
}

- (IBAction)addButton:(id)sender {
    NSLog(@"add");
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Amount"
                          message:@"Insert amount of device"
                          delegate:self
                          cancelButtonTitle:@"Cancel"
                          otherButtonTitles:@"OK",nil];
    alert.tag = 1;
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField* tf = [alert textFieldAtIndex:0];
    tf.keyboardType = UIKeyboardTypeNumberPad;
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1 && alertView.tag == 1) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        row = [textfield.text intValue];    // row is amount of device
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Name"
                              message:@"Insert device name"
                              delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"OK",nil];
        alert.tag = 2;
        alert.alertViewStyle = UIAlertViewStylePlainTextInput;
        [alert show];
    }
    else if (buttonIndex == 1 && alertView.tag == 2) {
        UITextField *textfield = [alertView textFieldAtIndex:0];
        name = textfield.text;      // name of device
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Type"
                              message:@"Select device type"
                              delegate:self
                              cancelButtonTitle:nil
                              otherButtonTitles:nil];
        alert.tag = 3;
        [alert addButtonWithTitle:[patchingClass.typeOfLight objectAtIndex:0]];
        [alert addButtonWithTitle:[patchingClass.typeOfLight objectAtIndex:1]];
        [alert addButtonWithTitle:[patchingClass.typeOfLight objectAtIndex:2]];
        alert.cancelButtonIndex = [alert addButtonWithTitle:@"Cancel"];
        [alert show];
    }
    else if (alertView.tag == 3) {
        // set type of device
        if (buttonIndex==0)         type = [patchingClass.typeOfLight objectAtIndex:0];
        else if (buttonIndex==1)    type = [patchingClass.typeOfLight objectAtIndex:1];
        else if (buttonIndex==2)    type = [patchingClass.typeOfLight objectAtIndex:2];
        
        // add data to Device Array(in Dataclass)
        for (int i=0; i<row; i++) {
            [data addObject:[NSNumber numberWithInt:patchingClass.device.count+1]]; // set device id
            [data addObject:[name stringByAppendingString:[NSString stringWithFormat:@"%d",i+1]]]; // set name
            [data addObject:type];  // set type
            // set object to use in Control Bar
            for (int i=0; i<[createData count]; i++) {
                [data addObject:[[createData objectAtIndex:i] mutableCopy]];
            }
            
            // create JSON form
            NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
            NSMutableArray *theArrayTest = [[NSMutableArray alloc] init];
            for (int j=0; j<3; j++) {
                [test setObject:[data objectAtIndex:j] forKey:[NSString stringWithFormat:@"%@",[patchingClass.nameCH objectAtIndex:j]]];
            }
            [theArrayTest addObject:[test mutableCopy]];
            [patchingClass toString:[theArrayTest mutableCopy] thatView:@"patching" action:@"add_device/"];     // send JSON form
            
            [patchingClass.device addObject:[data mutableCopy]];
            //NSLog(@"device = %@",patchingClass.device);
            
            [temp addObject:[data objectAtIndex:0]];
            if ([[data objectAtIndex:2] isEqual:[patchingClass.typeOfLight objectAtIndex:0]]) {
                [temp addObject:[NSNumber numberWithInt:x_drawDevices-250]];
                [temp addObject:[NSNumber numberWithInt:y_drawDevices]];
            }
            else if ([[data objectAtIndex:2] isEqual:[patchingClass.typeOfLight objectAtIndex:1]]) {
                [temp addObject:[NSNumber numberWithInt:x_drawDevices]];
                [temp addObject:[NSNumber numberWithInt:y_drawDevices]];
            }
            else if ([[data objectAtIndex:2] isEqual:[patchingClass.typeOfLight objectAtIndex:2]]) {
                [temp addObject:[NSNumber numberWithInt:x_drawDevices+250]];
                [temp addObject:[NSNumber numberWithInt:y_drawDevices]];
            }
            [patchingClass.layout addObject:[temp mutableCopy]];
            [temp removeAllObjects];
            [data removeAllObjects];
        }
        NSLog(@"add to device=%@",patchingClass.device);
        //NSLog(@"layout=%@",patchingClass.layout);
        [patchingTableView reloadData];
    }
}

-(void)resetDeviceID {
    int newRow = [patchingClass.device count];
    for (int i=0; i<newRow; i++) {
        [[patchingClass.device objectAtIndex:i] replaceObjectAtIndex:0 withObject:[NSNumber numberWithInt:i+1]];
        [[patchingClass.layout objectAtIndex:i] replaceObjectAtIndex:0 withObject:[NSNumber numberWithInt:i+1]];
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //remove the deleted object from your data source.
        //If your data source is an NSMutableArray, do this
        NSLog(@"delete=%@",[[patchingClass.device objectAtIndex:indexPath.row] objectAtIndex:0]);
        
        /* create JSON form */
        NSMutableDictionary * test = [[NSMutableDictionary alloc] init];
        
        [test setObject:[[patchingClass.device objectAtIndex:indexPath.row] objectAtIndex:0]
                 forKey:[NSString stringWithFormat:@"%@",[patchingClass.nameCH objectAtIndex:0]]];
        
        /* send JSON form */
        [patchingClass toStringDelete:[test mutableCopy] thatView:@"patching" action:@"delete_device/"];
        
        [patchingClass.layout removeObjectAtIndex:indexPath.row];
        [patchingClass.selected removeObjectIdenticalTo:[NSNumber numberWithInt:(int)indexPath.row+1]];
        [patchingClass.device removeObjectAtIndex:indexPath.row];     // delete data from array
        [self resetDeviceID];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        [tableView reloadData]; // tell table to refresh now
        NSLog(@"selectedNEW=%@",patchingClass.selected);
        //NSLog(@"deviceNEW=%@",patchingClass.device);
        //NSLog(@"layoutNEW=%@",patchingClass.layout);
    }
}

@end
