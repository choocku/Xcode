//
//  AppDelegate.m
//  Nightingale'sCall
//
//  Created by oh on 5/23/2558 BE.
//  Copyright (c) 2558 kmutnb. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@synthesize data;
@synthesize profile;
@synthesize tabBarViewController;
@synthesize wardName;
@synthesize userID;
@synthesize host;
@synthesize port;
@synthesize login;
@synthesize fakeEvent;
@synthesize loadFinished;
@synthesize wardID;
//@synthesize connect;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self configureTabBarAndNavigationBar];
    [self initVariables];
    
/* push notification */
    // Populate AirshipConfig.plist with your app's info from https://go.urbanairship.com
    // or set runtime properties here.
    UAConfig *config = [UAConfig defaultConfig];
    
    // You can also programmatically override the plist values:
    // config.developmentAppKey = @"YourKey";
    // etc.
    
    // Call takeOff (which creates the UAirship singleton)
    [UAirship takeOff:config];
    
    // Set the notification types required for the app (optional). This value defaults
    // to badge, alert and sound, so it's only necessary to set it if you want
    // to add or remove types.
    [UAirship push].userNotificationTypes = (UIUserNotificationTypeAlert |
                                             UIUserNotificationTypeBadge |
                                             UIUserNotificationTypeSound);
    
    // User notifications will not be enabled until userPushNotificationsEnabled is
    // set YES on UAPush. Once enabled, the setting will be persisted and the user
    // will be prompted to allow notifications. Normally, you should wait for a more appropriate
    // time to enable push to increase the likelihood that the user will accept
    // notifications.
    [UAirship push].userPushNotificationsEnabled = YES;
    
    // Open the system settings app directly to this application (on iOS 8+)
    //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    [[UAirship push] updateRegistration];
    
    
    return YES;
}

- (BOOL)connected {
    return [AFNetworkReachabilityManager sharedManager].reachable;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

-(void)configureTabBarAndNavigationBar {
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"tabBarBackground.png"] forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    
    // Assign tab bar item with titles
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateSelected];
    // Change the tab bar background
    UIImage* tabBarBackground = [UIImage imageNamed:@"tabBarBackground.png"];
    [[UITabBar appearance] setBackgroundImage:tabBarBackground];
    [[UITabBar appearance] setTintColor:[UIColor whiteColor]];
}

-(void)listenEvent {
    if (fakeEvent) {
        [data removeAllObjects];
        NSLog(@"event come");
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/event.php", host];
        [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
            NSError *error = nil;
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                 options:NSJSONReadingMutableContainers
                                                                   error:&error];
            if (error) {
                NSLog(@"Error serializing %@", error);
            }
            //NSLog(@"Dictionary %@", [json valueForKey:@"data"]);
            
            for (int i=0; i<[[json valueForKey:@"data"] count]; i++) {
                NSMutableDictionary * response = [[[json valueForKey:@"data"] objectAtIndex:i] mutableCopy];
                
                NSMutableDictionary * temp = [[NSMutableDictionary alloc] init];
                [temp setObject:[response valueForKey:@"room"] forKey:@"room"];
                [temp setObject:[response valueForKey:@"event"] forKey:@"event"];
                [temp setObject:[response valueForKey:@"ward"] forKey:@"ward"];
                [temp setObject:[response valueForKey:@"position_x"] forKey:@"position_x"];
                [temp setObject:[response valueForKey:@"position_y"] forKey:@"position_y"];
                [temp setObject:[response valueForKey:@"datetime"] forKey:@"datetime"];
                [data addObject:[temp mutableCopy]];
            }
            NSLog(@"data=%@",data);
            fakeEvent = 0;
            loadFinished = 1;
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
            UIAlertView *alert = [[UIAlertView alloc]
                                  initWithTitle:@"Connection Failed"
                                  message:@"Please Check Your Server IP"
                                  delegate:self
                                  cancelButtonTitle:nil
                                  otherButtonTitles:@"OK",nil];
            alert.tag = 2;
            [alert show];
        }];
    }
}

-(void)initVariables {
    host = @"192.168.1.33";
    port = 1024;
    data = [[NSMutableArray alloc] init];
    profile = [[NSMutableDictionary alloc] init];
    wardName = @"";
    userID=0;
    wardID = 0;
    login = 0;
    fakeEvent = 0;
    loadFinished = 0;
//    connect = 0;
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    UA_LINFO(@"Application received remote notification: %@", userInfo);
    [[UAirship push] appReceivedRemoteNotification:userInfo applicationState:application.applicationState];
    
}

-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    UA_LINFO(@"UIBackgroundFetchResult OHHH Application received remote notification: %@", userInfo);
    [[UAirship push] appReceivedRemoteNotification:userInfo applicationState:application.applicationState fetchCompletionHandler:completionHandler];
    
    
}


@end
