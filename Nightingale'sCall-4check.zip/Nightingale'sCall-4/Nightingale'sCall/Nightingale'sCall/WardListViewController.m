//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "WardListViewController.h"
#import "AppDelegate.h"

@interface WardListViewController ()

@end

@implementation WardListViewController {
    NSMutableArray * wardList;
    AppDelegate * ad;
    int hospitalID;
}

@synthesize wardListTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBarHidden=NO;
    self.navigationController.navigationBar.topItem.title = @"Ward List";
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    wardList = [[NSMutableArray alloc] init];
    
    hospitalID = 1;
    if(ad.login) {
        [self getWardList];
        [self getUserProfile];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [wardList count];
}

- (CGFloat)tableView:(UITableView *)tableView
estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView
heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"WardListDataCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self showData:cell indexPath:indexPath];
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * wardName = (UILabel *)[cell viewWithTag:1];
    
    wardName.text =[NSString stringWithFormat:@"%@",[[wardList objectAtIndex:indexPath.row] objectForKey:@"name"]];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    UILabel *str = (UILabel *)[cell viewWithTag:1];
    NSLog(@"select %@",str.text);
    ad.wardID = [[[wardList objectAtIndex:indexPath.row] objectForKey:@"id"] intValue];
    ad.wardName = str.text;
    
    self.navigationController.navigationBarHidden=YES;
    UITabBarController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"tabBar"];
    [self.navigationController pushViewController:controller animated:YES];
}

-(void)getWardList {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:[NSNumber numberWithInt:hospitalID] forKey:@"id"];
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/wardlist.php", ad.host];
    [manager POST:url parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        //NSLog(@"Dictionary %@", json);
        for (int i=0; i<[json count]; i++) {
            NSMutableDictionary * temp = [[NSMutableDictionary alloc] init];
            [temp setObject:[[json objectAtIndex:i] valueForKey:@"id"] forKey:@"id"];
            [temp setObject:[[json objectAtIndex:i] valueForKey:@"name"] forKey:@"name"];
            [wardList addObject:[temp mutableCopy]];
        }
        //NSLog(@"wardlist = %@",wardList);
        [wardListTableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Connection Failed"
                              message:@"Please Check Your Server IP"
                              delegate:self
                              cancelButtonTitle:nil
                              otherButtonTitles:@"OK",nil];
        alert.tag = 2;
        [alert show];
    }];
}

-(void)getUserProfile {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * parameters = [[NSMutableDictionary alloc] init];
    [parameters setObject:[NSNumber numberWithInt:ad.userID] forKey:@"id"];
    NSString * url = [NSString stringWithFormat:@"http://%@/nursecall/user_detail.php", ad.host];
    [manager POST:url parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"JSON: %@", responseObject);
        NSError *error = nil;
        NSMutableArray *json = [NSJSONSerialization JSONObjectWithData:responseObject
                                                               options:NSJSONReadingMutableContainers
                                                                 error:&error];
        if (error) {
            NSLog(@"Error serializing %@", error);
        }
        //NSLog(@"Dictionary %@", json);
        [ad.profile setObject:[json valueForKey:@"id"] forKey:@"id"];
        [ad.profile setObject:[json valueForKey:@"username"] forKey:@"username"];
        [ad.profile setObject:[json valueForKey:@"name"] forKey:@"name"];
        [ad.profile setObject:[json valueForKey:@"picture"] forKey:@"picture"];
        NSLog(@"profile = %@",ad.profile);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

@end
