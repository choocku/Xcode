//
//  ViewController.h
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface NurseListViewController : UITableViewController <UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *nurseOnCallTableView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activity;

@end

