//
//  ViewController.m
//  CareCall
//
//  Created by Peeranon Wattanapong on 4/29/2558 BE.
//  Copyright (c) 2558 Choock. All rights reserved.
//

#import "WaitingListViewController.h"
#import "AppDelegate.h"
@interface WaitingListViewController ()

@end

@implementation WaitingListViewController {
    AppDelegate * ad;
}

@synthesize activity;
@synthesize waitingListTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"waiting list");
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    [self initVariables];
    
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(event) userInfo:nil repeats:NO];
}

-(void)event {
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(load) userInfo:nil repeats:NO];
    [activity startAnimating];
    ad.fakeEvent = 1;
    [ad listenEvent];
}

-(void)load {
    if (ad.loadFinished) {
        //NSLog(@"stop");
        [activity stopAnimating];
        [self update];
        ad.loadFinished=0;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initVariables {
    ad = (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

-(void)update {
    // grouping
    for (int i=0; i<[ad.data count]; i++) {
        NSString * e = [[ad.data objectAtIndex:i] objectForKey:@"event"];
        for (int j=i+1; j<[ad.data count]; j++) {
            NSString * e2 = [[ad.data objectAtIndex:j] objectForKey:@"event"];
            if ([e isEqual:@"General"] && [e2 isEqual:@"Emergency"]) {
                [ad.data exchangeObjectAtIndex:i withObjectAtIndex:j];
            }
        }
    }
    
    // ordering by time
    for (int i=0; i<[ad.data count]; i++) {
        NSString * e = [[ad.data objectAtIndex:i] objectForKey:@"event"];
        NSString *dateStr1 = [[ad.data objectAtIndex:i] objectForKey:@"datetime"];
        for (int j=i+1; j<[ad.data count]; j++) {
            NSString * e2 = [[ad.data objectAtIndex:j] objectForKey:@"event"];
            NSString *dateStr2 = [[ad.data objectAtIndex:j] objectForKey:@"datetime"];
            
            // Convert string to date object
            NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
            [dateFormat setDateFormat:@"MM/dd/yy HH:mm:ss"];
            NSDate *date1= [dateFormat dateFromString:dateStr1];
            NSDate *date2 = [dateFormat dateFromString:dateStr2];
            
            NSComparisonResult result = [date1 compare:date2];
            
            if ([e isEqual:e2] && result == NSOrderedAscending) {
                [ad.data exchangeObjectAtIndex:i withObjectAtIndex:j];
            }
        }
    }
    [waitingListTableView reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [ad.data count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellIdentifier = @"WaitingListDataCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    
    // set cell backgroundcolor
    if ([[[ad.data objectAtIndex:indexPath.row] objectForKey:@"event"] isEqual:@"Emergency"]) {
        cell.backgroundColor = [UIColor colorWithRed:0.906 green:0.298 blue:0.235 alpha:1]; // arizarin
    } else {
        cell.backgroundColor = [UIColor colorWithRed:0.18 green:0.8 blue:0.443 alpha:1];    // emerald
    }
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [self showData:cell indexPath:indexPath];
    return cell;
}

-(void)showData:(UITableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    UILabel * room = (UILabel *)[cell viewWithTag:1];
    UILabel * event = (UILabel *)[cell viewWithTag:2];
    UILabel * time = (UILabel *)[cell viewWithTag:3];
    
    room.text =[NSString stringWithFormat:@"%@",[[ad.data objectAtIndex:indexPath.row] objectForKey:@"room"]];
    event.text =[NSString stringWithFormat:@"%@",[[ad.data objectAtIndex:indexPath.row] objectForKey:@"event"]];
    time.text =[NSString stringWithFormat:@"%@",[[ad.data objectAtIndex:indexPath.row] objectForKey:@"datetime"]];
}

@end
