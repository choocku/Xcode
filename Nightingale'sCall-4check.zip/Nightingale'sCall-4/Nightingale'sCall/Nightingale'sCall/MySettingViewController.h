//
//  MySettingViewController.h
//  Nightingale'sCall
//
//  Created by Peeranon Wattanapong on 5/29/2558 BE.
//  Copyright (c) 2558 kmutnb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"

@interface MySettingViewController : UITableViewController <UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *serverIPTextField;
@property (weak, nonatomic) IBOutlet UIImageView *profileImgView;
@property (weak, nonatomic) IBOutlet UILabel *usernameLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UITableView *settingsTableView;
@property (weak, nonatomic) IBOutlet UITableViewCell *logOutCell;

-(IBAction)serverIPTextField:(id)sender;

@end


