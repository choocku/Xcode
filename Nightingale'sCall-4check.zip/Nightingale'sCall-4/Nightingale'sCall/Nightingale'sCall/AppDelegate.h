//
//  AppDelegate.h
//  Nightingale'sCall
//
//  Created by oh on 5/23/2558 BE.
//  Copyright (c) 2558 kmutnb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UAirship.h"
#import "UAConfig.h"
#import "UAPush.h"
#import "AFNetworking.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) NSMutableArray * data;
@property (nonatomic, retain) NSMutableDictionary * profile;
@property (strong, nonatomic) UITabBarController * tabBarViewController;
@property (strong, nonatomic) NSString * wardName;
@property (strong, nonatomic) NSString * host;
@property (nonatomic) int port;
@property (nonatomic) int wardID;
@property (nonatomic) int userID;
@property (nonatomic) int login;
@property (nonatomic) int fakeEvent;
@property (nonatomic) int loadFinished;
//@property (nonatomic) int connect;

-(void)listenEvent;
-(void)initVariables;
- (BOOL)connected;

@end

